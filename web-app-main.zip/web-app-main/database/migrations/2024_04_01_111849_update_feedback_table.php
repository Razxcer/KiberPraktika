<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('feedback', function (Blueprint $table) {
            Schema::whenTableHasColumn($table->getTable(), 'comment', function (Blueprint $table) {
                $table->text('comment')->change();
            });
        });
    }

    public function down(): void
    {
        Schema::table('feedback', function (Blueprint $table) {
            Schema::whenTableHasColumn($table->getTable(), 'comment', function (Blueprint $table) {
                $table->string('comment')->change();
            });
        });
    }
};
