<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->dropUnique('projects_order_unique');
            $table->dropUnique('projects_home_order_unique');
        });
    }

    public function down(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->unique('order', 'projects_order_unique');
            $table->unique('home_order', 'projects_home_order_unique');
        });
    }
};
