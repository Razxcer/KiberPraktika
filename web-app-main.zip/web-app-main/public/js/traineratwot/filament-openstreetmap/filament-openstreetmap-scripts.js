var Qg = Object.create;
var ys = Object.defineProperty;
var tm = Object.getOwnPropertyDescriptor;
var em = Object.getOwnPropertyNames;
var im = Object.getPrototypeOf, nm = Object.prototype.hasOwnProperty;
var v = (n, t) => () => (n && (t = n(n = 0)), t);
var Rc = (n, t) => () => (t || n((t = {exports: {}}).exports, t), t.exports), Fi = (n, t) => {
    for (var e in t) ys(n, e, {get: t[e], enumerable: !0})
}, Sc = (n, t, e, i) => {
    if (t && typeof t == "object" || typeof t == "function") for (let r of em(t)) !nm.call(n, r) && r !== e && ys(n, r, {
        get: () => t[r],
        enumerable: !(i = tm(t, r)) || i.enumerable
    });
    return n
};
var Ic = (n, t, e) => (e = n != null ? Qg(im(n)) : {}, Sc(t || !n || !n.__esModule ? ys(e, "default", {
    value: n,
    enumerable: !0
}) : e, n)), Di = n => Sc(ys({}, "__esModule", {value: !0}), n);
var Wo, Ft, je = v(() => {
    Wo = class {
        constructor(t) {
            this.propagationStopped, this.defaultPrevented, this.type = t, this.target = null
        }

        preventDefault() {
            this.defaultPrevented = !0
        }

        stopPropagation() {
            this.propagationStopped = !0
        }
    }, Ft = Wo
});
var Ae, Fn = v(() => {
    Ae = {PROPERTYCHANGE: "propertychange"}
});
var zo, Dn, xs = v(() => {
    zo = class {
        constructor() {
            this.disposed = !1
        }

        dispose() {
            this.disposed || (this.disposed = !0, this.disposeInternal())
        }

        disposeInternal() {
        }
    }, Dn = zo
});

function Lc(n, t, e) {
    let i, r;
    e = e || de;
    let s = 0, o = n.length, a = !1;
    for (; s < o;) i = s + (o - s >> 1), r = +e(n[i], t), r < 0 ? s = i + 1 : (o = i, a = !r);
    return a ? s : ~s
}

function de(n, t) {
    return n > t ? 1 : n < t ? -1 : 0
}

function kn(n, t, e) {
    if (n[0] <= t) return 0;
    let i = n.length;
    if (t <= n[i - 1]) return i - 1;
    if (typeof e == "function") {
        for (let r = 1; r < i; ++r) {
            let s = n[r];
            if (s === t) return r;
            if (s < t) return e(t, n[r - 1], s) > 0 ? r - 1 : r
        }
        return i - 1
    }
    if (e > 0) {
        for (let r = 1; r < i; ++r) if (n[r] < t) return r - 1;
        return i - 1
    }
    if (e < 0) {
        for (let r = 1; r < i; ++r) if (n[r] <= t) return r;
        return i - 1
    }
    for (let r = 1; r < i; ++r) {
        if (n[r] == t) return r;
        if (n[r] < t) return n[r - 1] - t < t - n[r] ? r - 1 : r
    }
    return i - 1
}

function bc(n, t, e) {
    for (; t < e;) {
        let i = n[t];
        n[t] = n[e], n[e] = i, ++t, --e
    }
}

function Nn(n, t) {
    let e = Array.isArray(t) ? t : [t], i = e.length;
    for (let r = 0; r < i; r++) n[n.length] = e[r]
}

function Vt(n, t) {
    let e = n.length;
    if (e !== t.length) return !1;
    for (let i = 0; i < e; i++) if (n[i] !== t[i]) return !1;
    return !0
}

function Ac(n, t, e) {
    let i = t || de;
    return n.every(function (r, s) {
        if (s === 0) return !0;
        let o = i(n[s - 1], r);
        return !(o > 0 || e && o === 0)
    })
}

var Ct = v(() => {
});

function li() {
    return !0
}

function hi() {
    return !1
}

function Me() {
}

function Es(n) {
    let t = !1, e, i, r;
    return function () {
        let s = Array.prototype.slice.call(arguments);
        return (!t || this !== r || !Vt(s, i)) && (t = !0, r = this, i = s, e = n.apply(this, arguments)), e
    }
}

var Ht = v(() => {
    Ct()
});

function Be(n) {
    for (let t in n) delete n[t]
}

function Pe(n) {
    let t;
    for (t in n) return !1;
    return !t
}

var Oe = v(() => {
});
var Yo, ki, Lr = v(() => {
    xs();
    je();
    Ht();
    Oe();
    Yo = class extends Dn {
        constructor(t) {
            super(), this.eventTarget_ = t, this.pendingRemovals_ = null, this.dispatching_ = null, this.listeners_ = null
        }

        addEventListener(t, e) {
            if (!t || !e) return;
            let i = this.listeners_ || (this.listeners_ = {}), r = i[t] || (i[t] = []);
            r.includes(e) || r.push(e)
        }

        dispatchEvent(t) {
            let e = typeof t == "string", i = e ? t : t.type, r = this.listeners_ && this.listeners_[i];
            if (!r) return;
            let s = e ? new Ft(t) : t;
            s.target || (s.target = this.eventTarget_ || this);
            let o = this.dispatching_ || (this.dispatching_ = {}),
                a = this.pendingRemovals_ || (this.pendingRemovals_ = {});
            i in o || (o[i] = 0, a[i] = 0), ++o[i];
            let l;
            for (let h = 0, c = r.length; h < c; ++h) if ("handleEvent" in r[h] ? l = r[h].handleEvent(s) : l = r[h].call(this, s), l === !1 || s.propagationStopped) {
                l = !1;
                break
            }
            if (--o[i] === 0) {
                let h = a[i];
                for (delete a[i]; h--;) this.removeEventListener(i, Me);
                delete o[i]
            }
            return l
        }

        disposeInternal() {
            this.listeners_ && Be(this.listeners_)
        }

        getListeners(t) {
            return this.listeners_ && this.listeners_[t] || void 0
        }

        hasListener(t) {
            return this.listeners_ ? t ? t in this.listeners_ : Object.keys(this.listeners_).length > 0 : !1
        }

        removeEventListener(t, e) {
            if (!this.listeners_) return;
            let i = this.listeners_[t];
            if (!i) return;
            let r = i.indexOf(e);
            r !== -1 && (this.pendingRemovals_ && t in this.pendingRemovals_ ? (i[r] = Me, ++this.pendingRemovals_[t]) : (i.splice(r, 1), i.length === 0 && delete this.listeners_[t]))
        }
    }, ki = Yo
});
var D, pt = v(() => {
    D = {
        CHANGE: "change",
        ERROR: "error",
        BLUR: "blur",
        CLEAR: "clear",
        CONTEXTMENU: "contextmenu",
        CLICK: "click",
        DBLCLICK: "dblclick",
        DRAGENTER: "dragenter",
        DRAGOVER: "dragover",
        DROP: "drop",
        FOCUS: "focus",
        KEYDOWN: "keydown",
        KEYPRESS: "keypress",
        LOAD: "load",
        RESIZE: "resize",
        TOUCHMOVE: "touchmove",
        WHEEL: "wheel"
    }
});

function U(n, t, e, i, r) {
    if (i && i !== n && (e = e.bind(i)), r) {
        let o = e;
        e = function () {
            n.removeEventListener(t, e), o.apply(this, arguments)
        }
    }
    let s = {target: n, type: t, listener: e};
    return n.addEventListener(t, e), s
}

function Gn(n, t, e, i) {
    return U(n, t, e, i, !0)
}

function et(n) {
    n && n.target && (n.target.removeEventListener(n.type, n.listener), Be(n))
}

var fe = v(() => {
    Oe()
});

function rm(n) {
    if (Array.isArray(n)) for (let t = 0, e = n.length; t < e; ++t) et(n[t]); else et(n)
}

var Xn, Cs, Uo = v(() => {
    Lr();
    pt();
    fe();
    Xn = class extends ki {
        constructor() {
            super(), this.on = this.onInternal, this.once = this.onceInternal, this.un = this.unInternal, this.revision_ = 0
        }

        changed() {
            ++this.revision_, this.dispatchEvent(D.CHANGE)
        }

        getRevision() {
            return this.revision_
        }

        onInternal(t, e) {
            if (Array.isArray(t)) {
                let i = t.length, r = new Array(i);
                for (let s = 0; s < i; ++s) r[s] = U(this, t[s], e);
                return r
            }
            return U(this, t, e)
        }

        onceInternal(t, e) {
            let i;
            if (Array.isArray(t)) {
                let r = t.length;
                i = new Array(r);
                for (let s = 0; s < r; ++s) i[s] = Gn(this, t[s], e)
            } else i = Gn(this, t, e);
            return e.ol_key = i, i
        }

        unInternal(t, e) {
            let i = e.ol_key;
            if (i) rm(i); else if (Array.isArray(t)) for (let r = 0, s = t.length; r < s; ++r) this.removeEventListener(t[r], e); else this.removeEventListener(t, e)
        }
    };
    Xn.prototype.on;
    Xn.prototype.once;
    Xn.prototype.un;
    Cs = Xn
});

function H() {
    throw new Error("Unimplemented abstract method.")
}

function K(n) {
    return n.ol_uid || (n.ol_uid = String(++sm))
}

var sm, wt = v(() => {
    sm = 0
});
var ws, jo, St, Fe = v(() => {
    je();
    Fn();
    Uo();
    wt();
    Oe();
    ws = class extends Ft {
        constructor(t, e, i) {
            super(t), this.key = e, this.oldValue = i
        }
    }, jo = class extends Cs {
        constructor(t) {
            super(), this.on, this.once, this.un, K(this), this.values_ = null, t !== void 0 && this.setProperties(t)
        }

        get(t) {
            let e;
            return this.values_ && this.values_.hasOwnProperty(t) && (e = this.values_[t]), e
        }

        getKeys() {
            return this.values_ && Object.keys(this.values_) || []
        }

        getProperties() {
            return this.values_ && Object.assign({}, this.values_) || {}
        }

        getPropertiesInternal() {
            return this.values_
        }

        hasProperties() {
            return !!this.values_
        }

        notify(t, e) {
            let i;
            i = `change:${t}`, this.hasListener(i) && this.dispatchEvent(new ws(i, t, e)), i = Ae.PROPERTYCHANGE, this.hasListener(i) && this.dispatchEvent(new ws(i, t, e))
        }

        addChangeListener(t, e) {
            this.addEventListener(`change:${t}`, e)
        }

        removeChangeListener(t, e) {
            this.removeEventListener(`change:${t}`, e)
        }

        set(t, e, i) {
            let r = this.values_ || (this.values_ = {});
            if (i) r[t] = e; else {
                let s = r[t];
                r[t] = e, s !== e && this.notify(t, s)
            }
        }

        setProperties(t, e) {
            for (let i in t) this.set(i, t[i], e)
        }

        applyProperties(t) {
            t.values_ && Object.assign(this.values_ || (this.values_ = {}), t.values_)
        }

        unset(t, e) {
            if (this.values_ && t in this.values_) {
                let i = this.values_[t];
                delete this.values_[t], Pe(this.values_) && (this.values_ = null), e || this.notify(t, i)
            }
        }
    }, St = jo
});
var Dt, br = v(() => {
    Dt = {ADD: "add", REMOVE: "remove"}
});
var Mc, Wn, Bo, $t, zn = v(() => {
    Fe();
    br();
    je();
    Mc = {LENGTH: "length"}, Wn = class extends Ft {
        constructor(t, e, i) {
            super(t), this.element = e, this.index = i
        }
    }, Bo = class extends St {
        constructor(t, e) {
            if (super(), this.on, this.once, this.un, e = e || {}, this.unique_ = !!e.unique, this.array_ = t || [], this.unique_) for (let i = 0, r = this.array_.length; i < r; ++i) this.assertUnique_(this.array_[i], i);
            this.updateLength_()
        }

        clear() {
            for (; this.getLength() > 0;) this.pop()
        }

        extend(t) {
            for (let e = 0, i = t.length; e < i; ++e) this.push(t[e]);
            return this
        }

        forEach(t) {
            let e = this.array_;
            for (let i = 0, r = e.length; i < r; ++i) t(e[i], i, e)
        }

        getArray() {
            return this.array_
        }

        item(t) {
            return this.array_[t]
        }

        getLength() {
            return this.get(Mc.LENGTH)
        }

        insertAt(t, e) {
            if (t < 0 || t > this.getLength()) throw new Error("Index out of bounds: " + t);
            this.unique_ && this.assertUnique_(e), this.array_.splice(t, 0, e), this.updateLength_(), this.dispatchEvent(new Wn(Dt.ADD, e, t))
        }

        pop() {
            return this.removeAt(this.getLength() - 1)
        }

        push(t) {
            this.unique_ && this.assertUnique_(t);
            let e = this.getLength();
            return this.insertAt(e, t), this.getLength()
        }

        remove(t) {
            let e = this.array_;
            for (let i = 0, r = e.length; i < r; ++i) if (e[i] === t) return this.removeAt(i)
        }

        removeAt(t) {
            if (t < 0 || t >= this.getLength()) return;
            let e = this.array_[t];
            return this.array_.splice(t, 1), this.updateLength_(), this.dispatchEvent(new Wn(Dt.REMOVE, e, t)), e
        }

        setAt(t, e) {
            let i = this.getLength();
            if (t >= i) {
                this.insertAt(t, e);
                return
            }
            if (t < 0) throw new Error("Index out of bounds: " + t);
            this.unique_ && this.assertUnique_(e, t);
            let r = this.array_[t];
            this.array_[t] = e, this.dispatchEvent(new Wn(Dt.REMOVE, r, t)), this.dispatchEvent(new Wn(Dt.ADD, e, t))
        }

        updateLength_() {
            this.set(Mc.LENGTH, this.array_.length)
        }

        assertUnique_(t, e) {
            for (let i = 0, r = this.array_.length; i < r; ++i) if (this.array_[i] === t && i !== e) throw new Error("Duplicate item added to a unique collection")
        }
    }, $t = Bo
});
var Ni, Pc, om, F_, Oc, Ko, Ts, Yn, Vo, vs, ci = v(() => {
    Ni = typeof navigator < "u" && typeof navigator.userAgent < "u" ? navigator.userAgent.toLowerCase() : "", Pc = Ni.includes("firefox"), om = Ni.includes("safari") && !Ni.includes("chrom"), F_ = om && (Ni.includes("version/15.4") || /cpu (os|iphone os) 15_4 like mac os x/.test(Ni)), Oc = Ni.includes("webkit") && !Ni.includes("edge"), Ko = Ni.includes("macintosh"), Ts = typeof devicePixelRatio < "u" ? devicePixelRatio : 1, Yn = typeof WorkerGlobalScope < "u" && typeof OffscreenCanvas < "u" && self instanceof WorkerGlobalScope, Vo = typeof Image < "u" && Image.prototype.decode, vs = function () {
        let n = !1;
        try {
            let t = Object.defineProperty({}, "passive", {
                get: function () {
                    n = !0
                }
            });
            window.addEventListener("_", null, t), window.removeEventListener("_", null, t)
        } catch {
        }
        return n
    }()
});

function z(n, t) {
    if (!n) throw new Error(t)
}

var Zt = v(() => {
});

function kt() {
    return [1, 0, 0, 1, 0, 0]
}

function am(n, t, e, i, r, s, o) {
    return n[0] = t, n[1] = e, n[2] = i, n[3] = r, n[4] = s, n[5] = o, n
}

function Dc(n, t) {
    return n[0] = t[0], n[1] = t[1], n[2] = t[2], n[3] = t[3], n[4] = t[4], n[5] = t[5], n
}

function _t(n, t) {
    let e = t[0], i = t[1];
    return t[0] = n[0] * e + n[2] * i + n[4], t[1] = n[1] * e + n[3] * i + n[5], t
}

function kc(n, t, e) {
    return am(n, t, 0, 0, e, 0, 0)
}

function zt(n, t, e, i, r, s, o, a) {
    let l = Math.sin(s), h = Math.cos(s);
    return n[0] = i * h, n[1] = r * l, n[2] = -i * l, n[3] = r * h, n[4] = o * i * h - a * i * l + t, n[5] = o * r * l + a * r * h + e, n
}

function Un(n, t) {
    let e = lm(t);
    z(e !== 0, "Transformation matrix cannot be inverted");
    let i = t[0], r = t[1], s = t[2], o = t[3], a = t[4], l = t[5];
    return n[0] = o / e, n[1] = -r / e, n[2] = -s / e, n[3] = i / e, n[4] = (s * l - o * a) / e, n[5] = -(i * l - r * a) / e, n
}

function lm(n) {
    return n[0] * n[3] - n[1] * n[2]
}

function Rs(n) {
    let t = "matrix(" + n.join(", ") + ")";
    if (Yn) return t;
    let e = Fc || (Fc = document.createElement("div"));
    return e.style.transform = t, e.style.transform
}

var X_, Fc, De = v(() => {
    ci();
    Zt();
    X_ = new Array(6)
});
var It, Zo = v(() => {
    It = {UNKNOWN: 0, INTERSECTING: 1, ABOVE: 2, RIGHT: 4, BELOW: 8, LEFT: 16}
});

function qo(n) {
    let t = Tt();
    for (let e = 0, i = n.length; e < i; ++e) cn(t, n[e]);
    return t
}

function hm(n, t, e) {
    let i = Math.min.apply(null, n), r = Math.min.apply(null, t), s = Math.max.apply(null, n),
        o = Math.max.apply(null, t);
    return ge(i, r, s, o, e)
}

function jn(n, t, e) {
    return e ? (e[0] = n[0] - t, e[1] = n[1] - t, e[2] = n[2] + t, e[3] = n[3] + t, e) : [n[0] - t, n[1] - t, n[2] + t, n[3] + t]
}

function Is(n, t) {
    return t ? (t[0] = n[0], t[1] = n[1], t[2] = n[2], t[3] = n[3], t) : n.slice()
}

function Ls(n, t, e) {
    let i, r;
    return t < n[0] ? i = n[0] - t : n[2] < t ? i = t - n[2] : i = 0, e < n[1] ? r = n[1] - e : n[3] < e ? r = e - n[3] : r = 0, i * i + r * r
}

function Gi(n, t) {
    return Ho(n, t[0], t[1])
}

function ui(n, t) {
    return n[0] <= t[0] && t[2] <= n[2] && n[1] <= t[1] && t[3] <= n[3]
}

function Ho(n, t, e) {
    return n[0] <= t && t <= n[2] && n[1] <= e && e <= n[3]
}

function Ss(n, t) {
    let e = n[0], i = n[1], r = n[2], s = n[3], o = t[0], a = t[1], l = It.UNKNOWN;
    return o < e ? l = l | It.LEFT : o > r && (l = l | It.RIGHT), a < i ? l = l | It.BELOW : a > s && (l = l | It.ABOVE), l === It.UNKNOWN && (l = It.INTERSECTING), l
}

function Tt() {
    return [1 / 0, 1 / 0, -1 / 0, -1 / 0]
}

function ge(n, t, e, i, r) {
    return r ? (r[0] = n, r[1] = t, r[2] = e, r[3] = i, r) : [n, t, e, i]
}

function hn(n) {
    return ge(1 / 0, 1 / 0, -1 / 0, -1 / 0, n)
}

function bs(n, t) {
    let e = n[0], i = n[1];
    return ge(e, i, e, i, t)
}

function Bn(n, t, e, i, r) {
    let s = hn(r);
    return $o(s, n, t, e, i)
}

function di(n, t) {
    return n[0] == t[0] && n[2] == t[2] && n[1] == t[1] && n[3] == t[3]
}

function Nc(n, t) {
    return t[0] < n[0] && (n[0] = t[0]), t[2] > n[2] && (n[2] = t[2]), t[1] < n[1] && (n[1] = t[1]), t[3] > n[3] && (n[3] = t[3]), n
}

function cn(n, t) {
    t[0] < n[0] && (n[0] = t[0]), t[0] > n[2] && (n[2] = t[0]), t[1] < n[1] && (n[1] = t[1]), t[1] > n[3] && (n[3] = t[1])
}

function $o(n, t, e, i, r) {
    for (; e < i; e += r) cm(n, t[e], t[e + 1]);
    return n
}

function cm(n, t, e) {
    n[0] = Math.min(n[0], t), n[1] = Math.min(n[1], e), n[2] = Math.max(n[2], t), n[3] = Math.max(n[3], e)
}

function As(n, t) {
    let e;
    return e = t(Kn(n)), e || (e = t(Vn(n)), e) || (e = t(Zn(n)), e) || (e = t(Ce(n)), e) ? e : !1
}

function Ar(n) {
    let t = 0;
    return Wi(n) || (t = $(n) * Lt(n)), t
}

function Kn(n) {
    return [n[0], n[1]]
}

function Vn(n) {
    return [n[2], n[1]]
}

function Ee(n) {
    return [(n[0] + n[2]) / 2, (n[1] + n[3]) / 2]
}

function Gc(n, t) {
    let e;
    if (t === "bottom-left") e = Kn(n); else if (t === "bottom-right") e = Vn(n); else if (t === "top-left") e = Ce(n); else if (t === "top-right") e = Zn(n); else throw new Error("Invalid corner");
    return e
}

function Mr(n, t, e, i, r) {
    let [s, o, a, l, h, c, u, d] = Ms(n, t, e, i);
    return ge(Math.min(s, a, h, u), Math.min(o, l, c, d), Math.max(s, a, h, u), Math.max(o, l, c, d), r)
}

function Ms(n, t, e, i) {
    let r = t * i[0] / 2, s = t * i[1] / 2, o = Math.cos(e), a = Math.sin(e), l = r * o, h = r * a, c = s * o,
        u = s * a, d = n[0], f = n[1];
    return [d - l + u, f - h - c, d - l - u, f - h + c, d + l - u, f + h + c, d + l + u, f + h - c, d - l + u, f - h - c]
}

function Lt(n) {
    return n[3] - n[1]
}

function Xi(n, t, e) {
    let i = e || Tt();
    return yt(n, t) ? (n[0] > t[0] ? i[0] = n[0] : i[0] = t[0], n[1] > t[1] ? i[1] = n[1] : i[1] = t[1], n[2] < t[2] ? i[2] = n[2] : i[2] = t[2], n[3] < t[3] ? i[3] = n[3] : i[3] = t[3]) : hn(i), i
}

function Ce(n) {
    return [n[0], n[3]]
}

function Zn(n) {
    return [n[2], n[3]]
}

function $(n) {
    return n[2] - n[0]
}

function yt(n, t) {
    return n[0] <= t[2] && n[2] >= t[0] && n[1] <= t[3] && n[3] >= t[1]
}

function Wi(n) {
    return n[2] < n[0] || n[3] < n[1]
}

function Xc(n, t) {
    return t ? (t[0] = n[0], t[1] = n[1], t[2] = n[2], t[3] = n[3], t) : n
}

function Wc(n, t, e) {
    let i = !1, r = Ss(n, t), s = Ss(n, e);
    if (r === It.INTERSECTING || s === It.INTERSECTING) i = !0; else {
        let o = n[0], a = n[1], l = n[2], h = n[3], c = t[0], u = t[1], d = e[0], f = e[1], g = (f - u) / (d - c), m, p;
        s & It.ABOVE && !(r & It.ABOVE) && (m = d - (f - h) / g, i = m >= o && m <= l), !i && s & It.RIGHT && !(r & It.RIGHT) && (p = f - (d - l) * g, i = p >= a && p <= h), !i && s & It.BELOW && !(r & It.BELOW) && (m = d - (f - a) / g, i = m >= o && m <= l), !i && s & It.LEFT && !(r & It.LEFT) && (p = f - (d - o) * g, i = p >= a && p <= h)
    }
    return i
}

function zc(n, t, e, i) {
    if (Wi(n)) return hn(e);
    let r = [];
    if (i > 1) {
        let a = n[2] - n[0], l = n[3] - n[1];
        for (let h = 0; h < i; ++h) r.push(n[0] + a * h / i, n[1], n[2], n[1] + l * h / i, n[2] - a * h / i, n[3], n[0], n[3] - l * h / i)
    } else r = [n[0], n[1], n[2], n[1], n[2], n[3], n[0], n[3]];
    t(r, r, 2);
    let s = [], o = [];
    for (let a = 0, l = r.length; a < l; a += 2) s.push(r[a]), o.push(r[a + 1]);
    return hm(s, o, e)
}

function Jo(n, t) {
    let e = t.getExtent(), i = Ee(n);
    if (t.canWrapX() && (i[0] < e[0] || i[0] >= e[2])) {
        let r = $(e), o = Math.floor((i[0] - e[0]) / r) * r;
        n[0] -= o, n[2] -= o
    }
    return n
}

function Yc(n, t) {
    if (t.canWrapX()) {
        let e = t.getExtent();
        if (!isFinite(n[0]) || !isFinite(n[2])) return [[e[0], n[1], e[2], n[3]]];
        Jo(n, t);
        let i = $(e);
        if ($(n) > i) return [[e[0], n[1], e[2], n[3]]];
        if (n[0] < e[0]) return [[n[0] + i, n[1], e[2], n[3]], [e[0], n[1], n[2], n[3]]];
        if (n[2] > e[2]) return [[n[0], n[1], e[2], n[3]], [e[0], n[1], n[2] - i, n[3]]]
    }
    return [n]
}

var rt = v(() => {
    Zo()
});
var fi, Pr = v(() => {
    fi = {name: "rgb", min: [0, 0, 0], max: [255, 255, 255], channel: ["red", "green", "blue"], alias: ["RGB"]}
});
var un, ne, Ps = v(() => {
    Pr();
    un = {name: "xyz", min: [0, 0, 0], channel: ["X", "Y", "Z"], alias: ["XYZ", "ciexyz", "cie1931"]};
    un.whitepoint = {
        2: {
            A: [109.85, 100, 35.585],
            C: [98.074, 100, 118.232],
            D50: [96.422, 100, 82.521],
            D55: [95.682, 100, 92.149],
            D65: [95.045592705167, 100, 108.9057750759878],
            D75: [94.972, 100, 122.638],
            F2: [99.187, 100, 67.395],
            F7: [95.044, 100, 108.755],
            F11: [100.966, 100, 64.37],
            E: [100, 100, 100]
        },
        10: {
            A: [111.144, 100, 35.2],
            C: [97.285, 100, 116.145],
            D50: [96.72, 100, 81.427],
            D55: [95.799, 100, 90.926],
            D65: [94.811, 100, 107.304],
            D75: [94.416, 100, 120.641],
            F2: [103.28, 100, 69.026],
            F7: [95.792, 100, 107.687],
            F11: [103.866, 100, 65.627],
            E: [100, 100, 100]
        }
    };
    un.max = un.whitepoint[2].D65;
    un.rgb = function (n, t) {
        t = t || un.whitepoint[2].E;
        var e = n[0] / t[0], i = n[1] / t[1], r = n[2] / t[2], s, o, a;
        return s = e * 3.240969941904521 + i * -1.537383177570093 + r * -.498610760293, o = e * -.96924363628087 + i * 1.87596750150772 + r * .041555057407175, a = e * .055630079696993 + i * -.20397695888897 + r * 1.056971514242878, s = s > .0031308 ? 1.055 * Math.pow(s, 1 / 2.4) - .055 : s = s * 12.92, o = o > .0031308 ? 1.055 * Math.pow(o, 1 / 2.4) - .055 : o = o * 12.92, a = a > .0031308 ? 1.055 * Math.pow(a, 1 / 2.4) - .055 : a = a * 12.92, s = Math.min(Math.max(0, s), 1), o = Math.min(Math.max(0, o), 1), a = Math.min(Math.max(0, a), 1), [s * 255, o * 255, a * 255]
    };
    fi.xyz = function (n, t) {
        var e = n[0] / 255, i = n[1] / 255, r = n[2] / 255;
        e = e > .04045 ? Math.pow((e + .055) / 1.055, 2.4) : e / 12.92, i = i > .04045 ? Math.pow((i + .055) / 1.055, 2.4) : i / 12.92, r = r > .04045 ? Math.pow((r + .055) / 1.055, 2.4) : r / 12.92;
        var s = e * .41239079926595 + i * .35758433938387 + r * .18048078840183,
            o = e * .21263900587151 + i * .71516867876775 + r * .072192315360733,
            a = e * .019330818715591 + i * .11919477979462 + r * .95053215224966;
        return t = t || un.whitepoint[2].E, [s * t[0], o * t[1], a * t[2]]
    };
    ne = un
});
var Os, Uc = v(() => {
    Ps();
    Os = {
        name: "luv",
        min: [0, -134, -140],
        max: [100, 224, 122],
        channel: ["lightness", "u", "v"],
        alias: ["LUV", "cieluv", "cie1976"],
        xyz: function (n, t, e) {
            var i, r, s, o, a, l, h, c, u, d, f, g, m;
            if (s = n[0], o = n[1], a = n[2], s === 0) return [0, 0, 0];
            var p = .0011070564598794539;
            return t = t || "D65", e = e || 2, u = ne.whitepoint[e][t][0], d = ne.whitepoint[e][t][1], f = ne.whitepoint[e][t][2], g = 4 * u / (u + 15 * d + 3 * f), m = 9 * d / (u + 15 * d + 3 * f), i = o / (13 * s) + g || 0, r = a / (13 * s) + m || 0, h = s > 8 ? d * Math.pow((s + 16) / 116, 3) : d * s * p, l = h * 9 * i / (4 * r) || 0, c = h * (12 - 3 * i - 20 * r) / (4 * r) || 0, [l, h, c]
        }
    };
    ne.luv = function (n, t, e) {
        var i, r, s, o, a, l, h, c, u, d, f, g, m, p = .008856451679035631, _ = 903.2962962962961;
        t = t || "D65", e = e || 2, u = ne.whitepoint[e][t][0], d = ne.whitepoint[e][t][1], f = ne.whitepoint[e][t][2], g = 4 * u / (u + 15 * d + 3 * f), m = 9 * d / (u + 15 * d + 3 * f), l = n[0], h = n[1], c = n[2], i = 4 * l / (l + 15 * h + 3 * c) || 0, r = 9 * h / (l + 15 * h + 3 * c) || 0;
        var y = h / d;
        return s = y <= p ? _ * y : 116 * Math.pow(y, 1 / 3) - 16, o = 13 * s * (i - g), a = 13 * s * (r - m), [s, o, a]
    }
});
var jc, Bc, Kc = v(() => {
    Uc();
    Ps();
    jc = {
        name: "lchuv",
        channel: ["lightness", "chroma", "hue"],
        alias: ["LCHuv", "cielchuv"],
        min: [0, 0, 0],
        max: [100, 100, 360],
        luv: function (n) {
            var t = n[0], e = n[1], i = n[2], r, s, o;
            return o = i / 360 * 2 * Math.PI, r = e * Math.cos(o), s = e * Math.sin(o), [t, r, s]
        },
        xyz: function (n) {
            return Os.xyz(jc.luv(n))
        }
    }, Bc = jc;
    Os.lchuv = function (n) {
        var t = n[0], e = n[1], i = n[2], r = Math.sqrt(e * e + i * i), s = Math.atan2(i, e), o = s * 360 / 2 / Math.PI;
        return o < 0 && (o += 360), [t, r, o]
    };
    ne.lchuv = function (n) {
        return Os.lchuv(ne.luv(n))
    }
});
var Zc = Rc((J_, Vc) => {
    "use strict";
    Vc.exports = {
        aliceblue: [240, 248, 255],
        antiquewhite: [250, 235, 215],
        aqua: [0, 255, 255],
        aquamarine: [127, 255, 212],
        azure: [240, 255, 255],
        beige: [245, 245, 220],
        bisque: [255, 228, 196],
        black: [0, 0, 0],
        blanchedalmond: [255, 235, 205],
        blue: [0, 0, 255],
        blueviolet: [138, 43, 226],
        brown: [165, 42, 42],
        burlywood: [222, 184, 135],
        cadetblue: [95, 158, 160],
        chartreuse: [127, 255, 0],
        chocolate: [210, 105, 30],
        coral: [255, 127, 80],
        cornflowerblue: [100, 149, 237],
        cornsilk: [255, 248, 220],
        crimson: [220, 20, 60],
        cyan: [0, 255, 255],
        darkblue: [0, 0, 139],
        darkcyan: [0, 139, 139],
        darkgoldenrod: [184, 134, 11],
        darkgray: [169, 169, 169],
        darkgreen: [0, 100, 0],
        darkgrey: [169, 169, 169],
        darkkhaki: [189, 183, 107],
        darkmagenta: [139, 0, 139],
        darkolivegreen: [85, 107, 47],
        darkorange: [255, 140, 0],
        darkorchid: [153, 50, 204],
        darkred: [139, 0, 0],
        darksalmon: [233, 150, 122],
        darkseagreen: [143, 188, 143],
        darkslateblue: [72, 61, 139],
        darkslategray: [47, 79, 79],
        darkslategrey: [47, 79, 79],
        darkturquoise: [0, 206, 209],
        darkviolet: [148, 0, 211],
        deeppink: [255, 20, 147],
        deepskyblue: [0, 191, 255],
        dimgray: [105, 105, 105],
        dimgrey: [105, 105, 105],
        dodgerblue: [30, 144, 255],
        firebrick: [178, 34, 34],
        floralwhite: [255, 250, 240],
        forestgreen: [34, 139, 34],
        fuchsia: [255, 0, 255],
        gainsboro: [220, 220, 220],
        ghostwhite: [248, 248, 255],
        gold: [255, 215, 0],
        goldenrod: [218, 165, 32],
        gray: [128, 128, 128],
        green: [0, 128, 0],
        greenyellow: [173, 255, 47],
        grey: [128, 128, 128],
        honeydew: [240, 255, 240],
        hotpink: [255, 105, 180],
        indianred: [205, 92, 92],
        indigo: [75, 0, 130],
        ivory: [255, 255, 240],
        khaki: [240, 230, 140],
        lavender: [230, 230, 250],
        lavenderblush: [255, 240, 245],
        lawngreen: [124, 252, 0],
        lemonchiffon: [255, 250, 205],
        lightblue: [173, 216, 230],
        lightcoral: [240, 128, 128],
        lightcyan: [224, 255, 255],
        lightgoldenrodyellow: [250, 250, 210],
        lightgray: [211, 211, 211],
        lightgreen: [144, 238, 144],
        lightgrey: [211, 211, 211],
        lightpink: [255, 182, 193],
        lightsalmon: [255, 160, 122],
        lightseagreen: [32, 178, 170],
        lightskyblue: [135, 206, 250],
        lightslategray: [119, 136, 153],
        lightslategrey: [119, 136, 153],
        lightsteelblue: [176, 196, 222],
        lightyellow: [255, 255, 224],
        lime: [0, 255, 0],
        limegreen: [50, 205, 50],
        linen: [250, 240, 230],
        magenta: [255, 0, 255],
        maroon: [128, 0, 0],
        mediumaquamarine: [102, 205, 170],
        mediumblue: [0, 0, 205],
        mediumorchid: [186, 85, 211],
        mediumpurple: [147, 112, 219],
        mediumseagreen: [60, 179, 113],
        mediumslateblue: [123, 104, 238],
        mediumspringgreen: [0, 250, 154],
        mediumturquoise: [72, 209, 204],
        mediumvioletred: [199, 21, 133],
        midnightblue: [25, 25, 112],
        mintcream: [245, 255, 250],
        mistyrose: [255, 228, 225],
        moccasin: [255, 228, 181],
        navajowhite: [255, 222, 173],
        navy: [0, 0, 128],
        oldlace: [253, 245, 230],
        olive: [128, 128, 0],
        olivedrab: [107, 142, 35],
        orange: [255, 165, 0],
        orangered: [255, 69, 0],
        orchid: [218, 112, 214],
        palegoldenrod: [238, 232, 170],
        palegreen: [152, 251, 152],
        paleturquoise: [175, 238, 238],
        palevioletred: [219, 112, 147],
        papayawhip: [255, 239, 213],
        peachpuff: [255, 218, 185],
        peru: [205, 133, 63],
        pink: [255, 192, 203],
        plum: [221, 160, 221],
        powderblue: [176, 224, 230],
        purple: [128, 0, 128],
        rebeccapurple: [102, 51, 153],
        red: [255, 0, 0],
        rosybrown: [188, 143, 143],
        royalblue: [65, 105, 225],
        saddlebrown: [139, 69, 19],
        salmon: [250, 128, 114],
        sandybrown: [244, 164, 96],
        seagreen: [46, 139, 87],
        seashell: [255, 245, 238],
        sienna: [160, 82, 45],
        silver: [192, 192, 192],
        skyblue: [135, 206, 235],
        slateblue: [106, 90, 205],
        slategray: [112, 128, 144],
        slategrey: [112, 128, 144],
        snow: [255, 250, 250],
        springgreen: [0, 255, 127],
        steelblue: [70, 130, 180],
        tan: [210, 180, 140],
        teal: [0, 128, 128],
        thistle: [216, 191, 216],
        tomato: [255, 99, 71],
        turquoise: [64, 224, 208],
        violet: [238, 130, 238],
        wheat: [245, 222, 179],
        white: [255, 255, 255],
        whitesmoke: [245, 245, 245],
        yellow: [255, 255, 0],
        yellowgreen: [154, 205, 50]
    }
});

function um(n) {
    var t, e = [], i = 1, r;
    if (typeof n == "number") return {space: "rgb", values: [n >>> 16, (n & 65280) >>> 8, n & 255], alpha: 1};
    if (typeof n == "number") return {space: "rgb", values: [n >>> 16, (n & 65280) >>> 8, n & 255], alpha: 1};
    if (n = String(n).toLowerCase(), Qo.default[n]) e = Qo.default[n].slice(), r = "rgb"; else if (n === "transparent") i = 0, r = "rgb", e = [0, 0, 0]; else if (n[0] === "#") {
        var s = n.slice(1), o = s.length, a = o <= 4;
        i = 1, a ? (e = [parseInt(s[0] + s[0], 16), parseInt(s[1] + s[1], 16), parseInt(s[2] + s[2], 16)], o === 4 && (i = parseInt(s[3] + s[3], 16) / 255)) : (e = [parseInt(s[0] + s[1], 16), parseInt(s[2] + s[3], 16), parseInt(s[4] + s[5], 16)], o === 8 && (i = parseInt(s[6] + s[7], 16) / 255)), e[0] || (e[0] = 0), e[1] || (e[1] = 0), e[2] || (e[2] = 0), r = "rgb"
    } else if (t = /^((?:rgba?|hs[lvb]a?|hwba?|cmyk?|xy[zy]|gray|lab|lchu?v?|[ly]uv|lms|oklch|oklab|color))\s*\(([^\)]*)\)/.exec(n)) {
        var l = t[1];
        r = l.replace(/a$/, "");
        var h = r === "cmyk" ? 4 : r === "gray" ? 1 : 3;
        e = t[2].trim().split(/\s*[,\/]\s*|\s+/), r === "color" && (r = e.shift()), e = e.map(function (c, u) {
            if (c[c.length - 1] === "%") return c = parseFloat(c) / 100, u === 3 ? c : r === "rgb" ? c * 255 : r[0] === "h" || r[0] === "l" && !u ? c * 100 : r === "lab" ? c * 125 : r === "lch" ? u < 2 ? c * 150 : c * 360 : r[0] === "o" && !u ? c : r === "oklab" ? c * .4 : r === "oklch" ? u < 2 ? c * .4 : c * 360 : c;
            if (r[u] === "h" || u === 2 && r[r.length - 1] === "h") {
                if (qc[c] !== void 0) return qc[c];
                if (c.endsWith("deg")) return parseFloat(c);
                if (c.endsWith("turn")) return parseFloat(c) * 360;
                if (c.endsWith("grad")) return parseFloat(c) * 360 / 400;
                if (c.endsWith("rad")) return parseFloat(c) * 180 / Math.PI
            }
            return c === "none" ? 0 : parseFloat(c)
        }), i = e.length > h ? e.pop() : 1
    } else /[0-9](?:\s|\/|,)/.test(n) && (e = n.match(/([0-9]+)/g).map(function (c) {
        return parseFloat(c)
    }), r = n.match(/([a-z])/ig)?.join("")?.toLowerCase() || "rgb");
    return {space: r, values: e, alpha: i}
}

var Qo, Hc, qc, $c = v(() => {
    Qo = Ic(Zc(), 1), Hc = um, qc = {red: 0, orange: 60, yellow: 120, green: 180, blue: 240, purple: 300}
});
var Fs, Jc = v(() => {
    Pr();
    Fs = {
        name: "hsl",
        min: [0, 0, 0],
        max: [360, 100, 100],
        channel: ["hue", "saturation", "lightness"],
        alias: ["HSL"],
        rgb: function (n) {
            var t = n[0] / 360, e = n[1] / 100, i = n[2] / 100, r, s, o, a, l, h = 0;
            if (e === 0) return l = i * 255, [l, l, l];
            for (s = i < .5 ? i * (1 + e) : i + e - i * e, r = 2 * i - s, a = [0, 0, 0]; h < 3;) o = t + 1 / 3 * -(h - 1), o < 0 ? o++ : o > 1 && o--, l = 6 * o < 1 ? r + (s - r) * 6 * o : 2 * o < 1 ? s : 3 * o < 2 ? r + (s - r) * (2 / 3 - o) * 6 : r, a[h++] = l * 255;
            return a
        }
    };
    fi.hsl = function (n) {
        var t = n[0] / 255, e = n[1] / 255, i = n[2] / 255, r = Math.min(t, e, i), s = Math.max(t, e, i), o = s - r, a,
            l, h;
        return s === r ? a = 0 : t === s ? a = (e - i) / o : e === s ? a = 2 + (i - t) / o : i === s && (a = 4 + (t - e) / o), a = Math.min(a * 60, 360), a < 0 && (a += 360), h = (r + s) / 2, s === r ? l = 0 : h <= .5 ? l = o / (s + r) : l = o / (2 - s - r), [a, l * 100, h * 100]
    }
});

function ta(n) {
    Array.isArray(n) && n.raw && (n = String.raw(...arguments)), n instanceof Number && (n = +n);
    var t, e, i, r = Hc(n);
    if (!r.space) return [];
    let s = r.space[0] === "h" ? Fs.min : fi.min, o = r.space[0] === "h" ? Fs.max : fi.max;
    return t = Array(3), t[0] = Math.min(Math.max(r.values[0], s[0]), o[0]), t[1] = Math.min(Math.max(r.values[1], s[1]), o[1]), t[2] = Math.min(Math.max(r.values[2], s[2]), o[2]), r.space[0] === "h" && (t = Fs.rgb(t)), t.push(Math.min(Math.max(r.alpha, 0), 1)), t
}

var Qc = v(() => {
    $c();
    Pr();
    Jc()
});

function ot(n, t, e) {
    return Math.min(Math.max(n, t), e)
}

function tu(n, t, e, i, r, s) {
    let o = r - e, a = s - i;
    if (o !== 0 || a !== 0) {
        let l = ((n - e) * o + (t - i) * a) / (o * o + a * a);
        l > 1 ? (e = r, i = s) : l > 0 && (e += o * l, i += a * l)
    }
    return gi(n, t, e, i)
}

function gi(n, t, e, i) {
    let r = e - n, s = i - t;
    return r * r + s * s
}

function eu(n) {
    let t = n.length;
    for (let i = 0; i < t; i++) {
        let r = i, s = Math.abs(n[i][i]);
        for (let a = i + 1; a < t; a++) {
            let l = Math.abs(n[a][i]);
            l > s && (s = l, r = a)
        }
        if (s === 0) return null;
        let o = n[r];
        n[r] = n[i], n[i] = o;
        for (let a = i + 1; a < t; a++) {
            let l = -n[a][i] / n[i][i];
            for (let h = i; h < t + 1; h++) i == h ? n[a][h] = 0 : n[a][h] += l * n[i][h]
        }
    }
    let e = new Array(t);
    for (let i = t - 1; i >= 0; i--) {
        e[i] = n[i][t] / n[i][i];
        for (let r = i - 1; r >= 0; r--) n[r][t] -= n[r][i] * e[i]
    }
    return e
}

function qn(n) {
    return n * Math.PI / 180
}

function ke(n, t) {
    let e = n % t;
    return e * t < 0 ? e + t : e
}

function qt(n, t, e) {
    return n + e * (t - n)
}

function Ds(n, t) {
    let e = Math.pow(10, t);
    return Math.round(n * e) / e
}

function Or(n, t) {
    return Math.floor(Ds(n, t))
}

function Fr(n, t) {
    return Math.ceil(Ds(n, t))
}

var xt = v(() => {
});

function ks(n) {
    return typeof n == "string" ? n : ra(n)
}

function iu(n) {
    if (n.length === 4) return n;
    let t = n.slice();
    return t[3] = 1, t
}

function ia(n) {
    let t = ne.lchuv(fi.xyz(n));
    return t[3] = n[3], t
}

function nu(n) {
    let t = ne.rgb(Bc.xyz(n));
    return t[3] = n[3], t
}

function Ns(n) {
    if (Dr.hasOwnProperty(n)) return Dr[n];
    if (ea >= dm) {
        let e = 0;
        for (let i in Dr) e++ & 3 || (delete Dr[i], --ea)
    }
    let t = ta(n);
    if (t.length !== 4) throw new Error('Failed to parse "' + n + '" as color');
    for (let e of t) if (isNaN(e)) throw new Error('Failed to parse "' + n + '" as color');
    return na(t), Dr[n] = t, ++ea, t
}

function dn(n) {
    return Array.isArray(n) ? n : Ns(n)
}

function na(n) {
    return n[0] = ot(n[0] + .5 | 0, 0, 255), n[1] = ot(n[1] + .5 | 0, 0, 255), n[2] = ot(n[2] + .5 | 0, 0, 255), n[3] = ot(n[3], 0, 1), n
}

function ra(n) {
    let t = n[0];
    t != (t | 0) && (t = t + .5 | 0);
    let e = n[1];
    e != (e | 0) && (e = e + .5 | 0);
    let i = n[2];
    i != (i | 0) && (i = i + .5 | 0);
    let r = n[3] === void 0 ? 1 : Math.round(n[3] * 100) / 100;
    return "rgba(" + t + "," + e + "," + i + "," + r + ")"
}

function ru(n) {
    try {
        return Ns(n), !0
    } catch {
        return !1
    }
}

var dm, Dr, ea, mi = v(() => {
    Kc();
    Qc();
    Pr();
    Ps();
    xt();
    dm = 1024, Dr = {}, ea = 0
});

function su(n, t, e) {
    let i = e ? ks(e) : "null";
    return t + ":" + n + ":" + i
}

var sa, Hn, oa = v(() => {
    mi();
    sa = class {
        constructor() {
            this.cache_ = {}, this.cacheSize_ = 0, this.maxCacheSize_ = 32
        }

        clear() {
            this.cache_ = {}, this.cacheSize_ = 0
        }

        canExpireCache() {
            return this.cacheSize_ > this.maxCacheSize_
        }

        expire() {
            if (this.canExpireCache()) {
                let t = 0;
                for (let e in this.cache_) {
                    let i = this.cache_[e];
                    !(t++ & 3) && !i.hasListener() && (delete this.cache_[e], --this.cacheSize_)
                }
            }
        }

        get(t, e, i) {
            let r = su(t, e, i);
            return r in this.cache_ ? this.cache_[r] : null
        }

        set(t, e, i, r) {
            let s = su(t, e, i);
            this.cache_[s] = r, ++this.cacheSize_
        }

        setSize(t) {
            this.maxCacheSize_ = t, this.expire()
        }
    };
    Hn = new sa
});
var lt, aa = v(() => {
    lt = {
        OPACITY: "opacity",
        VISIBLE: "visible",
        EXTENT: "extent",
        Z_INDEX: "zIndex",
        MAX_RESOLUTION: "maxResolution",
        MIN_RESOLUTION: "minResolution",
        MAX_ZOOM: "maxZoom",
        MIN_ZOOM: "minZoom",
        SOURCE: "source",
        MAP: "map"
    }
});
var la, Gs, ha = v(() => {
    Fe();
    aa();
    wt();
    Zt();
    xt();
    la = class extends St {
        constructor(t) {
            super(), this.on, this.once, this.un, this.background_ = t.background;
            let e = Object.assign({}, t);
            typeof t.properties == "object" && (delete e.properties, Object.assign(e, t.properties)), e[lt.OPACITY] = t.opacity !== void 0 ? t.opacity : 1, z(typeof e[lt.OPACITY] == "number", "Layer opacity must be a number"), e[lt.VISIBLE] = t.visible !== void 0 ? t.visible : !0, e[lt.Z_INDEX] = t.zIndex, e[lt.MAX_RESOLUTION] = t.maxResolution !== void 0 ? t.maxResolution : 1 / 0, e[lt.MIN_RESOLUTION] = t.minResolution !== void 0 ? t.minResolution : 0, e[lt.MIN_ZOOM] = t.minZoom !== void 0 ? t.minZoom : -1 / 0, e[lt.MAX_ZOOM] = t.maxZoom !== void 0 ? t.maxZoom : 1 / 0, this.className_ = e.className !== void 0 ? e.className : "ol-layer", delete e.className, this.setProperties(e), this.state_ = null
        }

        getBackground() {
            return this.background_
        }

        getClassName() {
            return this.className_
        }

        getLayerState(t) {
            let e = this.state_ || {layer: this, managed: t === void 0 ? !0 : t}, i = this.getZIndex();
            return e.opacity = ot(Math.round(this.getOpacity() * 100) / 100, 0, 1), e.visible = this.getVisible(), e.extent = this.getExtent(), e.zIndex = i === void 0 && !e.managed ? 1 / 0 : i, e.maxResolution = this.getMaxResolution(), e.minResolution = Math.max(this.getMinResolution(), 0), e.minZoom = this.getMinZoom(), e.maxZoom = this.getMaxZoom(), this.state_ = e, e
        }

        getLayersArray(t) {
            return H()
        }

        getLayerStatesArray(t) {
            return H()
        }

        getExtent() {
            return this.get(lt.EXTENT)
        }

        getMaxResolution() {
            return this.get(lt.MAX_RESOLUTION)
        }

        getMinResolution() {
            return this.get(lt.MIN_RESOLUTION)
        }

        getMinZoom() {
            return this.get(lt.MIN_ZOOM)
        }

        getMaxZoom() {
            return this.get(lt.MAX_ZOOM)
        }

        getOpacity() {
            return this.get(lt.OPACITY)
        }

        getSourceState() {
            return H()
        }

        getVisible() {
            return this.get(lt.VISIBLE)
        }

        getZIndex() {
            return this.get(lt.Z_INDEX)
        }

        setBackground(t) {
            this.background_ = t, this.changed()
        }

        setExtent(t) {
            this.set(lt.EXTENT, t)
        }

        setMaxResolution(t) {
            this.set(lt.MAX_RESOLUTION, t)
        }

        setMinResolution(t) {
            this.set(lt.MIN_RESOLUTION, t)
        }

        setMaxZoom(t) {
            this.set(lt.MAX_ZOOM, t)
        }

        setMinZoom(t) {
            this.set(lt.MIN_ZOOM, t)
        }

        setOpacity(t) {
            z(typeof t == "number", "Layer opacity must be a number"), this.set(lt.OPACITY, t)
        }

        setVisible(t) {
            this.set(lt.VISIBLE, t)
        }

        setZIndex(t) {
            this.set(lt.Z_INDEX, t)
        }

        disposeInternal() {
            this.state_ && (this.state_.layer = null, this.state_ = null), super.disposeInternal()
        }
    }, Gs = la
});
var Jt, $n = v(() => {
    Jt = {
        PRERENDER: "prerender",
        POSTRENDER: "postrender",
        PRECOMPOSE: "precompose",
        POSTCOMPOSE: "postcompose",
        RENDERCOMPLETE: "rendercomplete"
    }
});
var Pt, Xs = v(() => {
    Pt = {ANIMATING: 0, INTERACTING: 1}
});
var we, ou = v(() => {
    we = {CENTER: "center", RESOLUTION: "resolution", ROTATION: "rotation"}
});
var Ke, ca = v(() => {
    Ke = {radians: 6370997 / (2 * Math.PI), degrees: 2 * Math.PI * 6370997 / 360, ft: .3048, m: 1, "us-ft": 1200 / 3937}
});
var ua, Jn, Ws = v(() => {
    ca();
    ua = class {
        constructor(t) {
            this.code_ = t.code, this.units_ = t.units, this.extent_ = t.extent !== void 0 ? t.extent : null, this.worldExtent_ = t.worldExtent !== void 0 ? t.worldExtent : null, this.axisOrientation_ = t.axisOrientation !== void 0 ? t.axisOrientation : "enu", this.global_ = t.global !== void 0 ? t.global : !1, this.canWrapX_ = !!(this.global_ && this.extent_), this.getPointResolutionFunc_ = t.getPointResolution, this.defaultTileGrid_ = null, this.metersPerUnit_ = t.metersPerUnit
        }

        canWrapX() {
            return this.canWrapX_
        }

        getCode() {
            return this.code_
        }

        getExtent() {
            return this.extent_
        }

        getUnits() {
            return this.units_
        }

        getMetersPerUnit() {
            return this.metersPerUnit_ || Ke[this.units_]
        }

        getWorldExtent() {
            return this.worldExtent_
        }

        getAxisOrientation() {
            return this.axisOrientation_
        }

        isGlobal() {
            return this.global_
        }

        setGlobal(t) {
            this.global_ = t, this.canWrapX_ = !!(t && this.extent_)
        }

        getDefaultTileGrid() {
            return this.defaultTileGrid_
        }

        setDefaultTileGrid(t) {
            this.defaultTileGrid_ = t
        }

        setExtent(t) {
            this.extent_ = t, this.canWrapX_ = !!(this.global_ && t)
        }

        setWorldExtent(t) {
            this.worldExtent_ = t
        }

        setGetPointResolution(t) {
            this.getPointResolutionFunc_ = t
        }

        getPointResolutionFunc() {
            return this.getPointResolutionFunc_
        }
    }, Jn = ua
});

function au(n, t, e) {
    let i = n.length;
    e = e > 1 ? e : 2, t === void 0 && (e > 2 ? t = n.slice() : t = new Array(i));
    for (let r = 0; r < i; r += e) {
        t[r] = Qn * n[r] / 180;
        let s = kr * Math.log(Math.tan(Math.PI * (+n[r + 1] + 90) / 360));
        s > zs ? s = zs : s < -zs && (s = -zs), t[r + 1] = s
    }
    return t
}

function lu(n, t, e) {
    let i = n.length;
    e = e > 1 ? e : 2, t === void 0 && (e > 2 ? t = n.slice() : t = new Array(i));
    for (let r = 0; r < i; r += e) t[r] = 180 * n[r] / Qn, t[r + 1] = 360 * Math.atan(Math.exp(n[r + 1] / kr)) / Math.PI - 90;
    return t
}

var kr, Qn, fm, gm, zs, zi, da, hu = v(() => {
    Ws();
    kr = 6378137, Qn = Math.PI * kr, fm = [-Qn, -Qn, Qn, Qn], gm = [-180, -85, 180, 85], zs = kr * Math.log(Math.tan(Math.PI / 2)), zi = class extends Jn {
        constructor(t) {
            super({
                code: t, units: "m", extent: fm, global: !0, worldExtent: gm, getPointResolution: function (e, i) {
                    return e / Math.cosh(i[1] / kr)
                }
            })
        }
    }, da = [new zi("EPSG:3857"), new zi("EPSG:102100"), new zi("EPSG:102113"), new zi("EPSG:900913"), new zi("http://www.opengis.net/def/crs/EPSG/0/3857"), new zi("http://www.opengis.net/gml/srs/epsg.xml#3857")]
});
var mm, cu, pm, pi, fa, uu = v(() => {
    Ws();
    mm = 6378137, cu = [-180, -90, 180, 90], pm = Math.PI * mm / 180, pi = class extends Jn {
        constructor(t, e) {
            super({
                code: t,
                units: "degrees",
                extent: cu,
                axisOrientation: e,
                global: !0,
                metersPerUnit: pm,
                worldExtent: cu
            })
        }
    }, fa = [new pi("CRS:84"), new pi("EPSG:4326", "neu"), new pi("urn:ogc:def:crs:OGC:1.3:CRS84"), new pi("urn:ogc:def:crs:OGC:2:84"), new pi("http://www.opengis.net/def/crs/OGC/1.3/CRS84"), new pi("http://www.opengis.net/gml/srs/epsg.xml#4326", "neu"), new pi("http://www.opengis.net/def/crs/EPSG/0/4326", "neu")]
});

function du() {
    Ys = {}
}

function fu(n) {
    return Ys[n] || Ys[n.replace(/urn:(x-)?ogc:def:crs:EPSG:(.*:)?(\w+)$/, "EPSG:$3")] || null
}

function gu(n, t) {
    Ys[n] = t
}

var Ys, mu = v(() => {
    Ys = {}
});

function pu() {
    fn = {}
}

function gn(n, t, e) {
    let i = n.getCode(), r = t.getCode();
    i in fn || (fn[i] = {}), fn[i][r] = e
}

function _u(n, t) {
    let e;
    return n in fn && t in fn[n] && (e = fn[n][t]), e
}

var fn, yu = v(() => {
    fn = {}
});

function xu(n, t) {
    return n[0] += +t[0], n[1] += +t[1], n
}

function Eu(n) {
    return function (t) {
        return ym(t, n)
    }
}

function _m(n, t, e) {
    return n ? t.replace("{x}", n[0].toFixed(e)).replace("{y}", n[1].toFixed(e)) : ""
}

function mn(n, t) {
    let e = !0;
    for (let i = n.length - 1; i >= 0; --i) if (n[i] != t[i]) {
        e = !1;
        break
    }
    return e
}

function tr(n, t) {
    let e = Math.cos(t), i = Math.sin(t), r = n[0] * e - n[1] * i, s = n[1] * e + n[0] * i;
    return n[0] = r, n[1] = s, n
}

function Cu(n, t) {
    return n[0] *= t, n[1] *= t, n
}

function ym(n, t) {
    return _m(n, "{x}, {y}", t)
}

function er(n, t) {
    if (t.canWrapX()) {
        let e = $(t.getExtent()), i = ga(n, t, e);
        i && (n[0] -= i * e)
    }
    return n
}

function ga(n, t, e) {
    let i = t.getExtent(), r = 0;
    return t.canWrapX() && (n[0] < i[0] || n[0] > i[2]) && (e = e || $(i), r = Math.floor((n[0] - i[0]) / e)), r
}

var _i = v(() => {
    rt()
});

function ma(n, t, e) {
    e = e || xm;
    let i = qn(n[1]), r = qn(t[1]), s = (r - i) / 2, o = qn(t[0] - n[0]) / 2,
        a = Math.sin(s) * Math.sin(s) + Math.sin(o) * Math.sin(o) * Math.cos(i) * Math.cos(r);
    return 2 * e * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

var xm, wu = v(() => {
    xt();
    xm = 63710088e-1
});

function Us(...n) {
    Em > Tu.warn || console.warn(...n)
}

var Tu, Em, pa = v(() => {
    Tu = {info: 1, warn: 2, error: 3, none: 4}, Em = Tu.info
});
var Au = {};
Fi(Au, {
    METERS_PER_UNIT: () => Ke,
    Projection: () => Jn,
    addCommon: () => bu,
    addCoordinateTransforms: () => wm,
    addEquivalentProjections: () => ya,
    addEquivalentTransforms: () => Su,
    addProjection: () => vu,
    addProjections: () => Ru,
    clearAllProjections: () => Cm,
    clearUserProjection: () => Rm,
    cloneTransform: () => Bs,
    createProjection: () => Gr,
    createSafeCoordinateTransform: () => Im,
    createTransformFromCoordinateTransform: () => xa,
    disableCoordinateWarning: () => js,
    equivalent: () => yi,
    fromLonLat: () => ir,
    fromUserCoordinate: () => Te,
    fromUserExtent: () => ve,
    fromUserResolution: () => Lu,
    get: () => ft,
    getPointResolution: () => Ks,
    getTransform: () => Yi,
    getTransformFromProjections: () => Ve,
    getUserProjection: () => _n,
    identityTransform: () => Nr,
    setUserProjection: () => Iu,
    toLonLat: () => Tm,
    toUserCoordinate: () => nr,
    toUserExtent: () => yn,
    toUserResolution: () => Ca,
    transform: () => pn,
    transformExtent: () => Ea,
    transformWithProjections: () => vm,
    useGeographic: () => Sm
});

function js(n) {
    _a = !(n === void 0 ? !0 : n)
}

function Bs(n, t) {
    if (t !== void 0) {
        for (let e = 0, i = n.length; e < i; ++e) t[e] = n[e];
        t = t
    } else t = n.slice();
    return t
}

function Nr(n, t) {
    if (t !== void 0 && n !== t) {
        for (let e = 0, i = n.length; e < i; ++e) t[e] = n[e];
        n = t
    }
    return n
}

function vu(n) {
    gu(n.getCode(), n), gn(n, n, Bs)
}

function Ru(n) {
    n.forEach(vu)
}

function ft(n) {
    return typeof n == "string" ? fu(n) : n || null
}

function Ks(n, t, e, i) {
    n = ft(n);
    let r, s = n.getPointResolutionFunc();
    if (s) {
        if (r = s(t, e), i && i !== n.getUnits()) {
            let o = n.getMetersPerUnit();
            o && (r = r * o / Ke[i])
        }
    } else {
        let o = n.getUnits();
        if (o == "degrees" && !i || i == "degrees") r = t; else {
            let a = Ve(n, ft("EPSG:4326"));
            if (a === Nr && o !== "degrees") r = t * n.getMetersPerUnit(); else {
                let h = [e[0] - t / 2, e[1], e[0] + t / 2, e[1], e[0], e[1] - t / 2, e[0], e[1] + t / 2];
                h = a(h, h, 2);
                let c = ma(h.slice(0, 2), h.slice(2, 4)), u = ma(h.slice(4, 6), h.slice(6, 8));
                r = (c + u) / 2
            }
            let l = i ? Ke[i] : n.getMetersPerUnit();
            l !== void 0 && (r /= l)
        }
    }
    return r
}

function ya(n) {
    Ru(n), n.forEach(function (t) {
        n.forEach(function (e) {
            t !== e && gn(t, e, Bs)
        })
    })
}

function Su(n, t, e, i) {
    n.forEach(function (r) {
        t.forEach(function (s) {
            gn(r, s, e), gn(s, r, i)
        })
    })
}

function Cm() {
    du(), pu()
}

function Gr(n, t) {
    return n ? typeof n == "string" ? ft(n) : n : ft(t)
}

function xa(n) {
    return function (t, e, i) {
        let r = t.length;
        i = i !== void 0 ? i : 2, e = e !== void 0 ? e : new Array(r);
        for (let s = 0; s < r; s += i) {
            let o = n(t.slice(s, s + i)), a = o.length;
            for (let l = 0, h = i; l < h; ++l) e[s + l] = l >= a ? t[s + l] : o[l]
        }
        return e
    }
}

function wm(n, t, e, i) {
    let r = ft(n), s = ft(t);
    gn(r, s, xa(e)), gn(s, r, xa(i))
}

function ir(n, t) {
    return js(), pn(n, "EPSG:4326", t !== void 0 ? t : "EPSG:3857")
}

function Tm(n, t) {
    let e = pn(n, t !== void 0 ? t : "EPSG:3857", "EPSG:4326"), i = e[0];
    return (i < -180 || i > 180) && (e[0] = ke(i + 180, 360) - 180), e
}

function yi(n, t) {
    if (n === t) return !0;
    let e = n.getUnits() === t.getUnits();
    return (n.getCode() === t.getCode() || Ve(n, t) === Bs) && e
}

function Ve(n, t) {
    let e = n.getCode(), i = t.getCode(), r = _u(e, i);
    return r || (r = Nr), r
}

function Yi(n, t) {
    let e = ft(n), i = ft(t);
    return Ve(e, i)
}

function pn(n, t, e) {
    return Yi(t, e)(n, void 0, n.length)
}

function Ea(n, t, e, i) {
    let r = Yi(t, e);
    return zc(n, r, void 0, i)
}

function vm(n, t, e) {
    return Ve(t, e)(n)
}

function Iu(n) {
    Qt = ft(n)
}

function Rm() {
    Qt = null
}

function _n() {
    return Qt
}

function Sm() {
    Iu("EPSG:4326")
}

function nr(n, t) {
    return Qt ? pn(n, t, Qt) : n
}

function Te(n, t) {
    return Qt ? pn(n, Qt, t) : (_a && !mn(n, [0, 0]) && n[0] >= -180 && n[0] <= 180 && n[1] >= -90 && n[1] <= 90 && (_a = !1, Us("Call useGeographic() from ol/proj once to work with [longitude, latitude] coordinates.")), n)
}

function yn(n, t) {
    return Qt ? Ea(n, t, Qt) : n
}

function ve(n, t) {
    return Qt ? Ea(n, Qt, t) : n
}

function Ca(n, t) {
    if (!Qt) return n;
    let e = ft(t).getMetersPerUnit(), i = Qt.getMetersPerUnit();
    return e && i ? n * e / i : n
}

function Lu(n, t) {
    if (!Qt) return n;
    let e = ft(t).getMetersPerUnit(), i = Qt.getMetersPerUnit();
    return e && i ? n * i / e : n
}

function Im(n, t, e) {
    return function (i) {
        let r, s;
        if (n.canWrapX()) {
            let o = n.getExtent(), a = $(o);
            i = i.slice(0), s = ga(i, n, a), s && (i[0] = i[0] - s * a), i[0] = ot(i[0], o[0], o[2]), i[1] = ot(i[1], o[1], o[3]), r = e(i)
        } else r = e(i);
        return s && t.canWrapX() && (r[0] += s * $(t.getExtent())), r
    }
}

function bu() {
    ya(da), ya(fa), Su(fa, da, au, lu)
}

var _a, Qt, Yt = v(() => {
    Ws();
    hu();
    uu();
    ca();
    mu();
    yu();
    rt();
    xt();
    _i();
    wu();
    pa();
    _a = !0;
    Qt = null;
    bu()
});

function wa(n, t, e) {
    return function (i, r, s, o, a) {
        if (!i) return;
        if (!r && !t) return i;
        let l = t ? 0 : s[0] * r, h = t ? 0 : s[1] * r, c = a ? a[0] : 0, u = a ? a[1] : 0, d = n[0] + l / 2 + c,
            f = n[2] - l / 2 + c, g = n[1] + h / 2 + u, m = n[3] - h / 2 + u;
        d > f && (d = (f + d) / 2, f = d), g > m && (g = (m + g) / 2, m = g);
        let p = ot(i[0], d, f), _ = ot(i[1], g, m);
        if (o && e && r) {
            let y = 30 * r;
            p += -y * Math.log(1 + Math.max(0, d - i[0]) / y) + y * Math.log(1 + Math.max(0, i[0] - f) / y), _ += -y * Math.log(1 + Math.max(0, g - i[1]) / y) + y * Math.log(1 + Math.max(0, i[1] - m) / y)
        }
        return [p, _]
    }
}

function Mu(n) {
    return n
}

var Pu = v(() => {
    xt()
});

function Ta(n, t, e, i) {
    let r = $(t) / e[0], s = Lt(t) / e[1];
    return i ? Math.min(n, Math.max(r, s)) : Math.min(n, Math.min(r, s))
}

function va(n, t, e) {
    let i = Math.min(n, t), r = 50;
    return i *= Math.log(1 + r * Math.max(0, n / t - 1)) / r + 1, e && (i = Math.max(i, e), i /= Math.log(1 + r * Math.max(0, e / n - 1)) / r + 1), ot(i, e / 2, t * 2)
}

function Ou(n, t, e, i) {
    return t = t !== void 0 ? t : !0, function (r, s, o, a) {
        if (r !== void 0) {
            let l = n[0], h = n[n.length - 1], c = e ? Ta(l, e, o, i) : l;
            if (a) return t ? va(r, c, h) : ot(r, h, c);
            let u = Math.min(c, r), d = Math.floor(kn(n, u, s));
            return n[d] > c && d < n.length - 1 ? n[d + 1] : n[d]
        }
    }
}

function Fu(n, t, e, i, r, s) {
    return i = i !== void 0 ? i : !0, e = e !== void 0 ? e : 0, function (o, a, l, h) {
        if (o !== void 0) {
            let c = r ? Ta(t, r, l, s) : t;
            if (h) return i ? va(o, c, e) : ot(o, e, c);
            let u = 1e-9, d = Math.ceil(Math.log(t / c) / Math.log(n) - u), f = -a * (.5 - u) + .5, g = Math.min(c, o),
                m = Math.floor(Math.log(t / g) / Math.log(n) + f), p = Math.max(d, m), _ = t / Math.pow(n, p);
            return ot(_, e, c)
        }
    }
}

function Ra(n, t, e, i, r) {
    return e = e !== void 0 ? e : !0, function (s, o, a, l) {
        if (s !== void 0) {
            let h = i ? Ta(n, i, a, r) : n;
            return !e || !l ? ot(s, t, h) : va(s, h, t)
        }
    }
}

var Du = v(() => {
    xt();
    rt();
    Ct()
});

function rr(n) {
    if (n !== void 0) return 0
}

function Sa(n) {
    if (n !== void 0) return n
}

function ku(n) {
    let t = 2 * Math.PI / n;
    return function (e, i) {
        if (i) return e;
        if (e !== void 0) return e = Math.floor(e / t + .5) * t, e
    }
}

function Nu(n) {
    let t = n === void 0 ? qn(5) : n;
    return function (e, i) {
        return i || e === void 0 ? e : Math.abs(e) <= t ? 0 : e
    }
}

var Vs = v(() => {
    xt()
});

function Ia(n) {
    return Math.pow(n, 3)
}

function Re(n) {
    return 1 - Ia(1 - n)
}

function Gu(n) {
    return 3 * n * n - 2 * n * n * n
}

function Xu(n) {
    return n
}

var Ui = v(() => {
});

function re(n, t, e, i, r, s) {
    s = s || [];
    let o = 0;
    for (let a = t; a < e; a += i) {
        let l = n[a], h = n[a + 1];
        s[o++] = r[0] * l + r[2] * h + r[4], s[o++] = r[1] * l + r[3] * h + r[5]
    }
    return s && s.length != o && (s.length = o), s
}

function Zs(n, t, e, i, r, s, o) {
    o = o || [];
    let a = Math.cos(r), l = Math.sin(r), h = s[0], c = s[1], u = 0;
    for (let d = t; d < e; d += i) {
        let f = n[d] - h, g = n[d + 1] - c;
        o[u++] = h + f * a - g * l, o[u++] = c + f * l + g * a;
        for (let m = d + 2; m < d + i; ++m) o[u++] = n[m]
    }
    return o && o.length != u && (o.length = u), o
}

function Wu(n, t, e, i, r, s, o, a) {
    a = a || [];
    let l = o[0], h = o[1], c = 0;
    for (let u = t; u < e; u += i) {
        let d = n[u] - l, f = n[u + 1] - h;
        a[c++] = l + r * d, a[c++] = h + s * f;
        for (let g = u + 2; g < u + i; ++g) a[c++] = n[g]
    }
    return a && a.length != c && (a.length = c), a
}

function zu(n, t, e, i, r, s, o) {
    o = o || [];
    let a = 0;
    for (let l = t; l < e; l += i) {
        o[a++] = n[l] + r, o[a++] = n[l + 1] + s;
        for (let h = l + 2; h < l + i; ++h) o[a++] = n[h]
    }
    return o && o.length != a && (o.length = a), o
}

var ji = v(() => {
});
var Yu, La, Uu, ju = v(() => {
    Fe();
    wt();
    De();
    rt();
    Yt();
    Ht();
    ji();
    Yu = kt(), La = class extends St {
        constructor() {
            super(), this.extent_ = Tt(), this.extentRevision_ = -1, this.simplifiedGeometryMaxMinSquaredTolerance = 0, this.simplifiedGeometryRevision = 0, this.simplifyTransformedInternal = Es((t, e, i) => {
                if (!i) return this.getSimplifiedGeometry(e);
                let r = this.clone();
                return r.applyTransform(i), r.getSimplifiedGeometry(e)
            })
        }

        simplifyTransformed(t, e) {
            return this.simplifyTransformedInternal(this.getRevision(), t, e)
        }

        clone() {
            return H()
        }

        closestPointXY(t, e, i, r) {
            return H()
        }

        containsXY(t, e) {
            let i = this.getClosestPoint([t, e]);
            return i[0] === t && i[1] === e
        }

        getClosestPoint(t, e) {
            return e = e || [NaN, NaN], this.closestPointXY(t[0], t[1], e, 1 / 0), e
        }

        intersectsCoordinate(t) {
            return this.containsXY(t[0], t[1])
        }

        computeExtent(t) {
            return H()
        }

        getExtent(t) {
            if (this.extentRevision_ != this.getRevision()) {
                let e = this.computeExtent(this.extent_);
                (isNaN(e[0]) || isNaN(e[1])) && hn(e), this.extentRevision_ = this.getRevision()
            }
            return Xc(this.extent_, t)
        }

        rotate(t, e) {
            H()
        }

        scale(t, e, i) {
            H()
        }

        simplify(t) {
            return this.getSimplifiedGeometry(t * t)
        }

        getSimplifiedGeometry(t) {
            return H()
        }

        getType() {
            return H()
        }

        applyTransform(t) {
            H()
        }

        intersectsExtent(t) {
            return H()
        }

        translate(t, e) {
            H()
        }

        transform(t, e) {
            let i = ft(t), r = i.getUnits() == "tile-pixels" ? function (s, o, a) {
                let l = i.getExtent(), h = i.getWorldExtent(), c = Lt(h) / Lt(l);
                return zt(Yu, h[0], h[3], c, -c, 0, 0, 0), re(s, 0, s.length, a, Yu, o), Yi(i, e)(s, o, a)
            } : Yi(i, e);
            return this.applyTransform(r), this
        }
    }, Uu = La
});

function Lm(n) {
    let t;
    return n == 2 ? t = "XY" : n == 3 ? t = "XYZ" : n == 4 && (t = "XYZM"), t
}

function Bu(n) {
    let t;
    return n == "XY" ? t = 2 : n == "XYZ" || n == "XYM" ? t = 3 : n == "XYZM" && (t = 4), t
}

function Ku(n, t, e) {
    let i = n.getFlatCoordinates();
    if (!i) return null;
    let r = n.getStride();
    return re(i, 0, i.length, r, t, e)
}

var ba, sr, Xr = v(() => {
    ju();
    wt();
    rt();
    ji();
    ba = class extends Uu {
        constructor() {
            super(), this.layout = "XY", this.stride = 2, this.flatCoordinates
        }

        computeExtent(t) {
            return Bn(this.flatCoordinates, 0, this.flatCoordinates.length, this.stride, t)
        }

        getCoordinates() {
            return H()
        }

        getFirstCoordinate() {
            return this.flatCoordinates.slice(0, this.stride)
        }

        getFlatCoordinates() {
            return this.flatCoordinates
        }

        getLastCoordinate() {
            return this.flatCoordinates.slice(this.flatCoordinates.length - this.stride)
        }

        getLayout() {
            return this.layout
        }

        getSimplifiedGeometry(t) {
            if (this.simplifiedGeometryRevision !== this.getRevision() && (this.simplifiedGeometryMaxMinSquaredTolerance = 0, this.simplifiedGeometryRevision = this.getRevision()), t < 0 || this.simplifiedGeometryMaxMinSquaredTolerance !== 0 && t <= this.simplifiedGeometryMaxMinSquaredTolerance) return this;
            let e = this.getSimplifiedGeometryInternal(t);
            return e.getFlatCoordinates().length < this.flatCoordinates.length ? e : (this.simplifiedGeometryMaxMinSquaredTolerance = t, this)
        }

        getSimplifiedGeometryInternal(t) {
            return this
        }

        getStride() {
            return this.stride
        }

        setFlatCoordinates(t, e) {
            this.stride = Bu(t), this.layout = t, this.flatCoordinates = e
        }

        setCoordinates(t, e) {
            H()
        }

        setLayout(t, e, i) {
            let r;
            if (t) r = Bu(t); else {
                for (let s = 0; s < i; ++s) {
                    if (e.length === 0) {
                        this.layout = "XY", this.stride = 2;
                        return
                    }
                    e = e[0]
                }
                r = e.length, t = Lm(r)
            }
            this.layout = t, this.stride = r
        }

        applyTransform(t) {
            this.flatCoordinates && (t(this.flatCoordinates, this.flatCoordinates, this.stride), this.changed())
        }

        rotate(t, e) {
            let i = this.getFlatCoordinates();
            if (i) {
                let r = this.getStride();
                Zs(i, 0, i.length, r, t, e, i), this.changed()
            }
        }

        scale(t, e, i) {
            e === void 0 && (e = t), i || (i = Ee(this.getExtent()));
            let r = this.getFlatCoordinates();
            if (r) {
                let s = this.getStride();
                Wu(r, 0, r.length, s, t, e, i, r), this.changed()
            }
        }

        translate(t, e) {
            let i = this.getFlatCoordinates();
            if (i) {
                let r = this.getStride();
                zu(i, 0, i.length, r, t, e, i), this.changed()
            }
        }
    };
    sr = ba
});

function Vu(n, t, e, i, r, s, o) {
    let a = n[t], l = n[t + 1], h = n[e] - a, c = n[e + 1] - l, u;
    if (h === 0 && c === 0) u = t; else {
        let d = ((r - a) * h + (s - l) * c) / (h * h + c * c);
        if (d > 1) u = e; else if (d > 0) {
            for (let f = 0; f < i; ++f) o[f] = qt(n[t + f], n[e + f], d);
            o.length = i;
            return
        } else u = t
    }
    for (let d = 0; d < i; ++d) o[d] = n[u + d];
    o.length = i
}

function Aa(n, t, e, i, r) {
    let s = n[t], o = n[t + 1];
    for (t += i; t < e; t += i) {
        let a = n[t], l = n[t + 1], h = gi(s, o, a, l);
        h > r && (r = h), s = a, o = l
    }
    return r
}

function Zu(n, t, e, i, r) {
    for (let s = 0, o = e.length; s < o; ++s) {
        let a = e[s];
        r = Aa(n, t, a, i, r), t = a
    }
    return r
}

function Ma(n, t, e, i, r, s, o, a, l, h, c) {
    if (t == e) return h;
    let u, d;
    if (r === 0) {
        if (d = gi(o, a, n[t], n[t + 1]), d < h) {
            for (u = 0; u < i; ++u) l[u] = n[t + u];
            return l.length = i, d
        }
        return h
    }
    c = c || [NaN, NaN];
    let f = t + i;
    for (; f < e;) if (Vu(n, f - i, f, i, o, a, c), d = gi(o, a, c[0], c[1]), d < h) {
        for (h = d, u = 0; u < i; ++u) l[u] = c[u];
        l.length = i, f += i
    } else f += i * Math.max((Math.sqrt(d) - Math.sqrt(h)) / r | 0, 1);
    if (s && (Vu(n, e - i, t, i, o, a, c), d = gi(o, a, c[0], c[1]), d < h)) {
        for (h = d, u = 0; u < i; ++u) l[u] = c[u];
        l.length = i
    }
    return h
}

function qu(n, t, e, i, r, s, o, a, l, h, c) {
    c = c || [NaN, NaN];
    for (let u = 0, d = e.length; u < d; ++u) {
        let f = e[u];
        h = Ma(n, t, f, i, r, s, o, a, l, h, c), t = f
    }
    return h
}

var Pa = v(() => {
    xt()
});

function Hu(n, t, e, i) {
    for (let r = 0, s = e.length; r < s; ++r) n[t++] = e[r];
    return t
}

function Oa(n, t, e, i) {
    for (let r = 0, s = e.length; r < s; ++r) {
        let o = e[r];
        for (let a = 0; a < i; ++a) n[t++] = o[a]
    }
    return t
}

function $u(n, t, e, i, r) {
    r = r || [];
    let s = 0;
    for (let o = 0, a = e.length; o < a; ++o) {
        let l = Oa(n, t, e[o], i);
        r[s++] = l, t = l
    }
    return r.length = s, r
}

var qs = v(() => {
});

function Wr(n, t, e, i, r, s, o) {
    let a = (e - t) / i;
    if (a < 3) {
        for (; t < e; t += i) s[o++] = n[t], s[o++] = n[t + 1];
        return o
    }
    let l = new Array(a);
    l[0] = 1, l[a - 1] = 1;
    let h = [t, e - i], c = 0;
    for (; h.length > 0;) {
        let u = h.pop(), d = h.pop(), f = 0, g = n[d], m = n[d + 1], p = n[u], _ = n[u + 1];
        for (let y = d + i; y < u; y += i) {
            let C = n[y], w = n[y + 1], T = tu(C, w, g, m, p, _);
            T > f && (c = y, f = T)
        }
        f > r && (l[(c - t) / i] = 1, d + i < c && h.push(d, c), c + i < u && h.push(c, u))
    }
    for (let u = 0; u < a; ++u) l[u] && (s[o++] = n[t + u * i], s[o++] = n[t + u * i + 1]);
    return o
}

function Ju(n, t, e, i, r, s, o, a) {
    for (let l = 0, h = e.length; l < h; ++l) {
        let c = e[l];
        o = Wr(n, t, c, i, r, s, o), a.push(o), t = c
    }
    return o
}

function Bi(n, t) {
    return t * Math.round(n / t)
}

function bm(n, t, e, i, r, s, o) {
    if (t == e) return o;
    let a = Bi(n[t], r), l = Bi(n[t + 1], r);
    t += i, s[o++] = a, s[o++] = l;
    let h, c;
    do if (h = Bi(n[t], r), c = Bi(n[t + 1], r), t += i, t == e) return s[o++] = h, s[o++] = c, o; while (h == a && c == l);
    for (; t < e;) {
        let u = Bi(n[t], r), d = Bi(n[t + 1], r);
        if (t += i, u == h && d == c) continue;
        let f = h - a, g = c - l, m = u - a, p = d - l;
        if (f * p == g * m && (f < 0 && m < f || f == m || f > 0 && m > f) && (g < 0 && p < g || g == p || g > 0 && p > g)) {
            h = u, c = d;
            continue
        }
        s[o++] = h, s[o++] = c, a = h, l = c, h = u, c = d
    }
    return s[o++] = h, s[o++] = c, o
}

function Hs(n, t, e, i, r, s, o, a) {
    for (let l = 0, h = e.length; l < h; ++l) {
        let c = e[l];
        o = bm(n, t, c, i, r, s, o), a.push(o), t = c
    }
    return o
}

var zr = v(() => {
    xt()
});

function Ki(n, t, e, i, r) {
    r = r !== void 0 ? r : [];
    let s = 0;
    for (let o = t; o < e; o += i) r[s++] = n.slice(o, o + i);
    return r.length = s, r
}

function or(n, t, e, i, r) {
    r = r !== void 0 ? r : [];
    let s = 0;
    for (let o = 0, a = e.length; o < a; ++o) {
        let l = e[o];
        r[s++] = Ki(n, t, l, i, r[s]), t = l
    }
    return r.length = s, r
}

function Fa(n, t, e, i, r) {
    r = r !== void 0 ? r : [];
    let s = 0;
    for (let o = 0, a = e.length; o < a; ++o) {
        let l = e[o];
        r[s++] = l.length === 1 && l[0] === t ? [] : or(n, t, l, i, r[s]), t = l[l.length - 1]
    }
    return r.length = s, r
}

var $s = v(() => {
});

function Da(n, t, e, i) {
    let r = 0, s = n[e - i], o = n[e - i + 1];
    for (; t < e; t += i) {
        let a = n[t], l = n[t + 1];
        r += o * a - s * l, s = a, o = l
    }
    return r / 2
}

function Qu(n, t, e, i) {
    let r = 0;
    for (let s = 0, o = e.length; s < o; ++s) {
        let a = e[s];
        r += Da(n, t, a, i), t = a
    }
    return r
}

var ka = v(() => {
});
var Na, Ga, td = v(() => {
    Xr();
    Pa();
    rt();
    qs();
    zr();
    $s();
    ka();
    Na = class n extends sr {
        constructor(t, e) {
            super(), this.maxDelta_ = -1, this.maxDeltaRevision_ = -1, e !== void 0 && !Array.isArray(t[0]) ? this.setFlatCoordinates(e, t) : this.setCoordinates(t, e)
        }

        clone() {
            return new n(this.flatCoordinates.slice(), this.layout)
        }

        closestPointXY(t, e, i, r) {
            return r < Ls(this.getExtent(), t, e) ? r : (this.maxDeltaRevision_ != this.getRevision() && (this.maxDelta_ = Math.sqrt(Aa(this.flatCoordinates, 0, this.flatCoordinates.length, this.stride, 0)), this.maxDeltaRevision_ = this.getRevision()), Ma(this.flatCoordinates, 0, this.flatCoordinates.length, this.stride, this.maxDelta_, !0, t, e, i, r))
        }

        getArea() {
            return Da(this.flatCoordinates, 0, this.flatCoordinates.length, this.stride)
        }

        getCoordinates() {
            return Ki(this.flatCoordinates, 0, this.flatCoordinates.length, this.stride)
        }

        getSimplifiedGeometryInternal(t) {
            let e = [];
            return e.length = Wr(this.flatCoordinates, 0, this.flatCoordinates.length, this.stride, t, e, 0), new n(e, "XY")
        }

        getType() {
            return "LinearRing"
        }

        intersectsExtent(t) {
            return !1
        }

        setCoordinates(t, e) {
            this.setLayout(e, t, 1), this.flatCoordinates || (this.flatCoordinates = []), this.flatCoordinates.length = Oa(this.flatCoordinates, 0, t, this.stride), this.changed()
        }
    }, Ga = Na
});
var ed = {};
Fi(ed, {default: () => ar});
var Xa, ar, Js = v(() => {
    Xr();
    rt();
    qs();
    xt();
    Xa = class n extends sr {
        constructor(t, e) {
            super(), this.setCoordinates(t, e)
        }

        clone() {
            let t = new n(this.flatCoordinates.slice(), this.layout);
            return t.applyProperties(this), t
        }

        closestPointXY(t, e, i, r) {
            let s = this.flatCoordinates, o = gi(t, e, s[0], s[1]);
            if (o < r) {
                let a = this.stride;
                for (let l = 0; l < a; ++l) i[l] = s[l];
                return i.length = a, o
            }
            return r
        }

        getCoordinates() {
            return this.flatCoordinates.slice()
        }

        computeExtent(t) {
            return bs(this.flatCoordinates, t)
        }

        getType() {
            return "Point"
        }

        intersectsExtent(t) {
            return Ho(t, this.flatCoordinates[0], this.flatCoordinates[1])
        }

        setCoordinates(t, e) {
            this.setLayout(e, t, 0), this.flatCoordinates || (this.flatCoordinates = []), this.flatCoordinates.length = Hu(this.flatCoordinates, 0, t, this.stride), this.changed()
        }
    }, ar = Xa
});

function id(n, t, e, i, r) {
    return !As(r, function (o) {
        return !Vi(n, t, e, i, o[0], o[1])
    })
}

function Vi(n, t, e, i, r, s) {
    let o = 0, a = n[e - i], l = n[e - i + 1];
    for (; t < e; t += i) {
        let h = n[t], c = n[t + 1];
        l <= s ? c > s && (h - a) * (s - l) - (r - a) * (c - l) > 0 && o++ : c <= s && (h - a) * (s - l) - (r - a) * (c - l) < 0 && o--, a = h, l = c
    }
    return o !== 0
}

function Qs(n, t, e, i, r, s) {
    if (e.length === 0 || !Vi(n, t, e[0], i, r, s)) return !1;
    for (let o = 1, a = e.length; o < a; ++o) if (Vi(n, e[o - 1], e[o], i, r, s)) return !1;
    return !0
}

var to = v(() => {
    rt()
});

function Yr(n, t, e, i, r, s, o) {
    let a, l, h, c, u, d, f, g = r[s + 1], m = [];
    for (let y = 0, C = e.length; y < C; ++y) {
        let w = e[y];
        for (c = n[w - i], d = n[w - i + 1], a = t; a < w; a += i) u = n[a], f = n[a + 1], (g <= d && f <= g || d <= g && g <= f) && (h = (g - d) / (f - d) * (u - c) + c, m.push(h)), c = u, d = f
    }
    let p = NaN, _ = -1 / 0;
    for (m.sort(de), c = m[0], a = 1, l = m.length; a < l; ++a) {
        u = m[a];
        let y = Math.abs(u - c);
        y > _ && (h = (c + u) / 2, Qs(n, t, e, i, h, g) && (p = h, _ = y)), c = u
    }
    return isNaN(p) && (p = r[s]), o ? (o.push(p, g, _), o) : [p, g, _]
}

function nd(n, t, e, i, r) {
    let s = [];
    for (let o = 0, a = e.length; o < a; ++o) {
        let l = e[o];
        s = Yr(n, t, l, i, r, 2 * o, s), t = l[l.length - 1]
    }
    return s
}

var Wa = v(() => {
    Ct();
    to()
});

function rd(n, t, e, i, r) {
    let s;
    for (t += i; t < e; t += i) if (s = r(n.slice(t - i, t), n.slice(t, t + i)), s) return s;
    return !1
}

var sd = v(() => {
});

function od(n, t, e, i, r) {
    let s = $o(Tt(), n, t, e, i);
    return yt(r, s) ? ui(r, s) || s[0] >= r[0] && s[2] <= r[2] || s[1] >= r[1] && s[3] <= r[3] ? !0 : rd(n, t, e, i, function (o, a) {
        return Wc(r, o, a)
    }) : !1
}

function za(n, t, e, i, r) {
    return !!(od(n, t, e, i, r) || Vi(n, t, e, i, r[0], r[1]) || Vi(n, t, e, i, r[0], r[3]) || Vi(n, t, e, i, r[2], r[1]) || Vi(n, t, e, i, r[2], r[3]))
}

function ad(n, t, e, i, r) {
    if (!za(n, t, e[0], i, r)) return !1;
    if (e.length === 1) return !0;
    for (let s = 1, o = e.length; s < o; ++s) if (id(n, e[s - 1], e[s], i, r) && !od(n, e[s - 1], e[s], i, r)) return !1;
    return !0
}

var Ya = v(() => {
    rt();
    sd();
    to()
});

function ld(n, t, e, i) {
    for (; t < e - i;) {
        for (let r = 0; r < i; ++r) {
            let s = n[t + r];
            n[t + r] = n[e - i + r], n[e - i + r] = s
        }
        t += i, e -= i
    }
}

var hd = v(() => {
});

function Ua(n, t, e, i) {
    let r = 0, s = n[e - i], o = n[e - i + 1];
    for (; t < e; t += i) {
        let a = n[t], l = n[t + 1];
        r += (a - s) * (l + o), s = a, o = l
    }
    return r === 0 ? void 0 : r > 0
}

function cd(n, t, e, i, r) {
    r = r !== void 0 ? r : !1;
    for (let s = 0, o = e.length; s < o; ++s) {
        let a = e[s], l = Ua(n, t, a, i);
        if (s === 0) {
            if (r && l || !r && !l) return !1
        } else if (r && !l || !r && l) return !1;
        t = a
    }
    return !0
}

function ja(n, t, e, i, r) {
    r = r !== void 0 ? r : !1;
    for (let s = 0, o = e.length; s < o; ++s) {
        let a = e[s], l = Ua(n, t, a, i);
        (s === 0 ? r && l || !r && !l : r && !l || !r && l) && ld(n, t, a, i), t = a
    }
    return t
}

function ud(n, t) {
    let e = [], i = 0, r = 0, s;
    for (let o = 0, a = t.length; o < a; ++o) {
        let l = t[o], h = Ua(n, i, l, 2);
        if (s === void 0 && (s = h), h === s) e.push(t.slice(r, o + 1)); else {
            if (e.length === 0) continue;
            e[e.length - 1].push(t[r])
        }
        r = o + 1, i = l
    }
    return e
}

var Ba = v(() => {
    hd()
});

function Ka(n) {
    if (Wi(n)) throw new Error("Cannot create polygon from empty extent");
    let t = n[0], e = n[1], i = n[2], r = n[3], s = [t, e, t, r, i, r, i, e, t, e];
    return new eo(s, "XY", [s.length])
}

var eo, dd, Va = v(() => {
    td();
    Js();
    Xr();
    Pa();
    rt();
    qs();
    Ct();
    Wa();
    $s();
    Ya();
    Ba();
    ka();
    to();
    zr();
    eo = class n extends sr {
        constructor(t, e, i) {
            super(), this.ends_ = [], this.flatInteriorPointRevision_ = -1, this.flatInteriorPoint_ = null, this.maxDelta_ = -1, this.maxDeltaRevision_ = -1, this.orientedRevision_ = -1, this.orientedFlatCoordinates_ = null, e !== void 0 && i ? (this.setFlatCoordinates(e, t), this.ends_ = i) : this.setCoordinates(t, e)
        }

        appendLinearRing(t) {
            this.flatCoordinates ? Nn(this.flatCoordinates, t.getFlatCoordinates()) : this.flatCoordinates = t.getFlatCoordinates().slice(), this.ends_.push(this.flatCoordinates.length), this.changed()
        }

        clone() {
            let t = new n(this.flatCoordinates.slice(), this.layout, this.ends_.slice());
            return t.applyProperties(this), t
        }

        closestPointXY(t, e, i, r) {
            return r < Ls(this.getExtent(), t, e) ? r : (this.maxDeltaRevision_ != this.getRevision() && (this.maxDelta_ = Math.sqrt(Zu(this.flatCoordinates, 0, this.ends_, this.stride, 0)), this.maxDeltaRevision_ = this.getRevision()), qu(this.flatCoordinates, 0, this.ends_, this.stride, this.maxDelta_, !0, t, e, i, r))
        }

        containsXY(t, e) {
            return Qs(this.getOrientedFlatCoordinates(), 0, this.ends_, this.stride, t, e)
        }

        getArea() {
            return Qu(this.getOrientedFlatCoordinates(), 0, this.ends_, this.stride)
        }

        getCoordinates(t) {
            let e;
            return t !== void 0 ? (e = this.getOrientedFlatCoordinates().slice(), ja(e, 0, this.ends_, this.stride, t)) : e = this.flatCoordinates, or(e, 0, this.ends_, this.stride)
        }

        getEnds() {
            return this.ends_
        }

        getFlatInteriorPoint() {
            if (this.flatInteriorPointRevision_ != this.getRevision()) {
                let t = Ee(this.getExtent());
                this.flatInteriorPoint_ = Yr(this.getOrientedFlatCoordinates(), 0, this.ends_, this.stride, t, 0), this.flatInteriorPointRevision_ = this.getRevision()
            }
            return this.flatInteriorPoint_
        }

        getInteriorPoint() {
            return new ar(this.getFlatInteriorPoint(), "XYM")
        }

        getLinearRingCount() {
            return this.ends_.length
        }

        getLinearRing(t) {
            return t < 0 || this.ends_.length <= t ? null : new Ga(this.flatCoordinates.slice(t === 0 ? 0 : this.ends_[t - 1], this.ends_[t]), this.layout)
        }

        getLinearRings() {
            let t = this.layout, e = this.flatCoordinates, i = this.ends_, r = [], s = 0;
            for (let o = 0, a = i.length; o < a; ++o) {
                let l = i[o], h = new Ga(e.slice(s, l), t);
                r.push(h), s = l
            }
            return r
        }

        getOrientedFlatCoordinates() {
            if (this.orientedRevision_ != this.getRevision()) {
                let t = this.flatCoordinates;
                cd(t, 0, this.ends_, this.stride) ? this.orientedFlatCoordinates_ = t : (this.orientedFlatCoordinates_ = t.slice(), this.orientedFlatCoordinates_.length = ja(this.orientedFlatCoordinates_, 0, this.ends_, this.stride)), this.orientedRevision_ = this.getRevision()
            }
            return this.orientedFlatCoordinates_
        }

        getSimplifiedGeometryInternal(t) {
            let e = [], i = [];
            return e.length = Hs(this.flatCoordinates, 0, this.ends_, this.stride, Math.sqrt(t), e, 0, i), new n(e, "XY", i)
        }

        getType() {
            return "Polygon"
        }

        intersectsExtent(t) {
            return ad(this.getOrientedFlatCoordinates(), 0, this.ends_, this.stride, t)
        }

        setCoordinates(t, e) {
            this.setLayout(e, t, 2), this.flatCoordinates || (this.flatCoordinates = []);
            let i = $u(this.flatCoordinates, 0, t, this.stride, this.ends_);
            this.flatCoordinates.length = i.length === 0 ? 0 : i[i.length - 1], this.changed()
        }
    }, dd = eo
});

function io(n, t) {
    setTimeout(function () {
        n(t)
    }, 0)
}

function Am(n) {
    if (n.extent !== void 0) {
        let e = n.smoothExtentConstraint !== void 0 ? n.smoothExtentConstraint : !0;
        return wa(n.extent, n.constrainOnlyCenter, e)
    }
    let t = Gr(n.projection, "EPSG:3857");
    if (n.multiWorld !== !0 && t.isGlobal()) {
        let e = t.getExtent().slice();
        return e[0] = -1 / 0, e[2] = 1 / 0, wa(e, !1, !1)
    }
    return Mu
}

function Mm(n) {
    let t, e, i, o = n.minZoom !== void 0 ? n.minZoom : Za, a = n.maxZoom !== void 0 ? n.maxZoom : 28,
        l = n.zoomFactor !== void 0 ? n.zoomFactor : 2, h = n.multiWorld !== void 0 ? n.multiWorld : !1,
        c = n.smoothResolutionConstraint !== void 0 ? n.smoothResolutionConstraint : !0,
        u = n.showFullExtent !== void 0 ? n.showFullExtent : !1, d = Gr(n.projection, "EPSG:3857"), f = d.getExtent(),
        g = n.constrainOnlyCenter, m = n.extent;
    if (!h && !m && d.isGlobal() && (g = !1, m = f), n.resolutions !== void 0) {
        let p = n.resolutions;
        e = p[o], i = p[a] !== void 0 ? p[a] : p[p.length - 1], n.constrainResolution ? t = Ou(p, c, !g && m, u) : t = Ra(e, i, c, !g && m, u)
    } else {
        let _ = (f ? Math.max($(f), Lt(f)) : 360 * Ke.degrees / d.getMetersPerUnit()) / 256 / Math.pow(2, Za),
            y = _ / Math.pow(2, 28 - Za);
        e = n.maxResolution, e !== void 0 ? o = 0 : e = _ / Math.pow(l, o), i = n.minResolution, i === void 0 && (n.maxZoom !== void 0 ? n.maxResolution !== void 0 ? i = e / Math.pow(l, a) : i = _ / Math.pow(l, a) : i = y), a = o + Math.floor(Math.log(e / i) / Math.log(l)), i = e / Math.pow(l, a - o), n.constrainResolution ? t = Fu(l, e, i, c, !g && m, u) : t = Ra(e, i, c, !g && m, u)
    }
    return {constraint: t, maxResolution: e, minResolution: i, minZoom: o, zoomFactor: l}
}

function Pm(n) {
    if (n.enableRotation !== void 0 ? n.enableRotation : !0) {
        let e = n.constrainRotation;
        return e === void 0 || e === !0 ? Nu() : e === !1 ? Sa : typeof e == "number" ? ku(e) : Sa
    }
    return rr
}

function Om(n) {
    return !(n.sourceCenter && n.targetCenter && !mn(n.sourceCenter, n.targetCenter) || n.sourceResolution !== n.targetResolution || n.sourceRotation !== n.targetRotation)
}

function qa(n, t, e, i, r) {
    let s = Math.cos(-r), o = Math.sin(-r), a = n[0] * s - n[1] * o, l = n[1] * s + n[0] * o;
    a += (t[0] / 2 - e[0]) * i, l += (e[1] - t[1] / 2) * i, o = -o;
    let h = a * s - l * o, c = l * s + a * o;
    return [h, c]
}

var Za, Ha, me, no = v(() => {
    Fe();
    Xs();
    ou();
    Yt();
    Ht();
    _i();
    Zt();
    Pu();
    xt();
    Du();
    Vs();
    Ui();
    rt();
    Ct();
    Va();
    Za = 0, Ha = class extends St {
        constructor(t) {
            super(), this.on, this.once, this.un, t = Object.assign({}, t), this.hints_ = [0, 0], this.animations_ = [], this.updateAnimationKey_, this.projection_ = Gr(t.projection, "EPSG:3857"), this.viewportSize_ = [100, 100], this.targetCenter_ = null, this.targetResolution_, this.targetRotation_, this.nextCenter_ = null, this.nextResolution_, this.nextRotation_, this.cancelAnchor_ = void 0, t.projection && js(), t.center && (t.center = Te(t.center, this.projection_)), t.extent && (t.extent = ve(t.extent, this.projection_)), this.applyOptions_(t)
        }

        get padding() {
            return this.padding_
        }

        set padding(t) {
            let e = this.padding_;
            this.padding_ = t;
            let i = this.getCenterInternal();
            if (i) {
                let r = t || [0, 0, 0, 0];
                e = e || [0, 0, 0, 0];
                let s = this.getResolution(), o = s / 2 * (r[3] - e[3] + e[1] - r[1]),
                    a = s / 2 * (r[0] - e[0] + e[2] - r[2]);
                this.setCenterInternal([i[0] + o, i[1] - a])
            }
        }

        applyOptions_(t) {
            let e = Object.assign({}, t);
            for (let a in we) delete e[a];
            this.setProperties(e, !0);
            let i = Mm(t);
            this.maxResolution_ = i.maxResolution, this.minResolution_ = i.minResolution, this.zoomFactor_ = i.zoomFactor, this.resolutions_ = t.resolutions, this.padding_ = t.padding, this.minZoom_ = i.minZoom;
            let r = Am(t), s = i.constraint, o = Pm(t);
            this.constraints_ = {
                center: r,
                resolution: s,
                rotation: o
            }, this.setRotation(t.rotation !== void 0 ? t.rotation : 0), this.setCenterInternal(t.center !== void 0 ? t.center : null), t.resolution !== void 0 ? this.setResolution(t.resolution) : t.zoom !== void 0 && this.setZoom(t.zoom)
        }

        getUpdatedOptions_(t) {
            let e = this.getProperties();
            return e.resolution !== void 0 ? e.resolution = this.getResolution() : e.zoom = this.getZoom(), e.center = this.getCenterInternal(), e.rotation = this.getRotation(), Object.assign({}, e, t)
        }

        animate(t) {
            this.isDef() && !this.getAnimating() && this.resolveConstraints(0);
            let e = new Array(arguments.length);
            for (let i = 0; i < e.length; ++i) {
                let r = arguments[i];
                r.center && (r = Object.assign({}, r), r.center = Te(r.center, this.getProjection())), r.anchor && (r = Object.assign({}, r), r.anchor = Te(r.anchor, this.getProjection())), e[i] = r
            }
            this.animateInternal.apply(this, e)
        }

        animateInternal(t) {
            let e = arguments.length, i;
            e > 1 && typeof arguments[e - 1] == "function" && (i = arguments[e - 1], --e);
            let r = 0;
            for (; r < e && !this.isDef(); ++r) {
                let c = arguments[r];
                c.center && this.setCenterInternal(c.center), c.zoom !== void 0 ? this.setZoom(c.zoom) : c.resolution && this.setResolution(c.resolution), c.rotation !== void 0 && this.setRotation(c.rotation)
            }
            if (r === e) {
                i && io(i, !0);
                return
            }
            let s = Date.now(), o = this.targetCenter_.slice(), a = this.targetResolution_, l = this.targetRotation_,
                h = [];
            for (; r < e; ++r) {
                let c = arguments[r], u = {
                    start: s,
                    complete: !1,
                    anchor: c.anchor,
                    duration: c.duration !== void 0 ? c.duration : 1e3,
                    easing: c.easing || Gu,
                    callback: i
                };
                if (c.center && (u.sourceCenter = o, u.targetCenter = c.center.slice(), o = u.targetCenter), c.zoom !== void 0 ? (u.sourceResolution = a, u.targetResolution = this.getResolutionForZoom(c.zoom), a = u.targetResolution) : c.resolution && (u.sourceResolution = a, u.targetResolution = c.resolution, a = u.targetResolution), c.rotation !== void 0) {
                    u.sourceRotation = l;
                    let d = ke(c.rotation - l + Math.PI, 2 * Math.PI) - Math.PI;
                    u.targetRotation = l + d, l = u.targetRotation
                }
                Om(u) ? u.complete = !0 : s += u.duration, h.push(u)
            }
            this.animations_.push(h), this.setHint(Pt.ANIMATING, 1), this.updateAnimations_()
        }

        getAnimating() {
            return this.hints_[Pt.ANIMATING] > 0
        }

        getInteracting() {
            return this.hints_[Pt.INTERACTING] > 0
        }

        cancelAnimations() {
            this.setHint(Pt.ANIMATING, -this.hints_[Pt.ANIMATING]);
            let t;
            for (let e = 0, i = this.animations_.length; e < i; ++e) {
                let r = this.animations_[e];
                if (r[0].callback && io(r[0].callback, !1), !t) for (let s = 0, o = r.length; s < o; ++s) {
                    let a = r[s];
                    if (!a.complete) {
                        t = a.anchor;
                        break
                    }
                }
            }
            this.animations_.length = 0, this.cancelAnchor_ = t, this.nextCenter_ = null, this.nextResolution_ = NaN, this.nextRotation_ = NaN
        }

        updateAnimations_() {
            if (this.updateAnimationKey_ !== void 0 && (cancelAnimationFrame(this.updateAnimationKey_), this.updateAnimationKey_ = void 0), !this.getAnimating()) return;
            let t = Date.now(), e = !1;
            for (let i = this.animations_.length - 1; i >= 0; --i) {
                let r = this.animations_[i], s = !0;
                for (let o = 0, a = r.length; o < a; ++o) {
                    let l = r[o];
                    if (l.complete) continue;
                    let h = t - l.start, c = l.duration > 0 ? h / l.duration : 1;
                    c >= 1 ? (l.complete = !0, c = 1) : s = !1;
                    let u = l.easing(c);
                    if (l.sourceCenter) {
                        let d = l.sourceCenter[0], f = l.sourceCenter[1], g = l.targetCenter[0], m = l.targetCenter[1];
                        this.nextCenter_ = l.targetCenter;
                        let p = d + u * (g - d), _ = f + u * (m - f);
                        this.targetCenter_ = [p, _]
                    }
                    if (l.sourceResolution && l.targetResolution) {
                        let d = u === 1 ? l.targetResolution : l.sourceResolution + u * (l.targetResolution - l.sourceResolution);
                        if (l.anchor) {
                            let f = this.getViewportSize_(this.getRotation()),
                                g = this.constraints_.resolution(d, 0, f, !0);
                            this.targetCenter_ = this.calculateCenterZoom(g, l.anchor)
                        }
                        this.nextResolution_ = l.targetResolution, this.targetResolution_ = d, this.applyTargetState_(!0)
                    }
                    if (l.sourceRotation !== void 0 && l.targetRotation !== void 0) {
                        let d = u === 1 ? ke(l.targetRotation + Math.PI, 2 * Math.PI) - Math.PI : l.sourceRotation + u * (l.targetRotation - l.sourceRotation);
                        if (l.anchor) {
                            let f = this.constraints_.rotation(d, !0);
                            this.targetCenter_ = this.calculateCenterRotate(f, l.anchor)
                        }
                        this.nextRotation_ = l.targetRotation, this.targetRotation_ = d
                    }
                    if (this.applyTargetState_(!0), e = !0, !l.complete) break
                }
                if (s) {
                    this.animations_[i] = null, this.setHint(Pt.ANIMATING, -1), this.nextCenter_ = null, this.nextResolution_ = NaN, this.nextRotation_ = NaN;
                    let o = r[0].callback;
                    o && io(o, !0)
                }
            }
            this.animations_ = this.animations_.filter(Boolean), e && this.updateAnimationKey_ === void 0 && (this.updateAnimationKey_ = requestAnimationFrame(this.updateAnimations_.bind(this)))
        }

        calculateCenterRotate(t, e) {
            let i, r = this.getCenterInternal();
            return r !== void 0 && (i = [r[0] - e[0], r[1] - e[1]], tr(i, t - this.getRotation()), xu(i, e)), i
        }

        calculateCenterZoom(t, e) {
            let i, r = this.getCenterInternal(), s = this.getResolution();
            if (r !== void 0 && s !== void 0) {
                let o = e[0] - t * (e[0] - r[0]) / s, a = e[1] - t * (e[1] - r[1]) / s;
                i = [o, a]
            }
            return i
        }

        getViewportSize_(t) {
            let e = this.viewportSize_;
            if (t) {
                let i = e[0], r = e[1];
                return [Math.abs(i * Math.cos(t)) + Math.abs(r * Math.sin(t)), Math.abs(i * Math.sin(t)) + Math.abs(r * Math.cos(t))]
            }
            return e
        }

        setViewportSize(t) {
            this.viewportSize_ = Array.isArray(t) ? t.slice() : [100, 100], this.getAnimating() || this.resolveConstraints(0)
        }

        getCenter() {
            let t = this.getCenterInternal();
            return t && nr(t, this.getProjection())
        }

        getCenterInternal() {
            return this.get(we.CENTER)
        }

        getConstraints() {
            return this.constraints_
        }

        getConstrainResolution() {
            return this.get("constrainResolution")
        }

        getHints(t) {
            return t !== void 0 ? (t[0] = this.hints_[0], t[1] = this.hints_[1], t) : this.hints_.slice()
        }

        calculateExtent(t) {
            let e = this.calculateExtentInternal(t);
            return yn(e, this.getProjection())
        }

        calculateExtentInternal(t) {
            t = t || this.getViewportSizeMinusPadding_();
            let e = this.getCenterInternal();
            z(e, "The view center is not defined");
            let i = this.getResolution();
            z(i !== void 0, "The view resolution is not defined");
            let r = this.getRotation();
            return z(r !== void 0, "The view rotation is not defined"), Mr(e, i, r, t)
        }

        getMaxResolution() {
            return this.maxResolution_
        }

        getMinResolution() {
            return this.minResolution_
        }

        getMaxZoom() {
            return this.getZoomForResolution(this.minResolution_)
        }

        setMaxZoom(t) {
            this.applyOptions_(this.getUpdatedOptions_({maxZoom: t}))
        }

        getMinZoom() {
            return this.getZoomForResolution(this.maxResolution_)
        }

        setMinZoom(t) {
            this.applyOptions_(this.getUpdatedOptions_({minZoom: t}))
        }

        setConstrainResolution(t) {
            this.applyOptions_(this.getUpdatedOptions_({constrainResolution: t}))
        }

        getProjection() {
            return this.projection_
        }

        getResolution() {
            return this.get(we.RESOLUTION)
        }

        getResolutions() {
            return this.resolutions_
        }

        getResolutionForExtent(t, e) {
            return this.getResolutionForExtentInternal(ve(t, this.getProjection()), e)
        }

        getResolutionForExtentInternal(t, e) {
            e = e || this.getViewportSizeMinusPadding_();
            let i = $(t) / e[0], r = Lt(t) / e[1];
            return Math.max(i, r)
        }

        getResolutionForValueFunction(t) {
            t = t || 2;
            let e = this.getConstrainedResolution(this.maxResolution_), i = this.minResolution_,
                r = Math.log(e / i) / Math.log(t);
            return function (s) {
                return e / Math.pow(t, s * r)
            }
        }

        getRotation() {
            return this.get(we.ROTATION)
        }

        getValueForResolutionFunction(t) {
            let e = Math.log(t || 2), i = this.getConstrainedResolution(this.maxResolution_), r = this.minResolution_,
                s = Math.log(i / r) / e;
            return function (o) {
                return Math.log(i / o) / e / s
            }
        }

        getViewportSizeMinusPadding_(t) {
            let e = this.getViewportSize_(t), i = this.padding_;
            return i && (e = [e[0] - i[1] - i[3], e[1] - i[0] - i[2]]), e
        }

        getState() {
            let t = this.getProjection(), e = this.getResolution(), i = this.getRotation(),
                r = this.getCenterInternal(), s = this.padding_;
            if (s) {
                let o = this.getViewportSizeMinusPadding_();
                r = qa(r, this.getViewportSize_(), [o[0] / 2 + s[3], o[1] / 2 + s[0]], e, i)
            }
            return {
                center: r.slice(0),
                projection: t !== void 0 ? t : null,
                resolution: e,
                nextCenter: this.nextCenter_,
                nextResolution: this.nextResolution_,
                nextRotation: this.nextRotation_,
                rotation: i,
                zoom: this.getZoom()
            }
        }

        getViewStateAndExtent() {
            return {viewState: this.getState(), extent: this.calculateExtent()}
        }

        getZoom() {
            let t, e = this.getResolution();
            return e !== void 0 && (t = this.getZoomForResolution(e)), t
        }

        getZoomForResolution(t) {
            let e = this.minZoom_ || 0, i, r;
            if (this.resolutions_) {
                let s = kn(this.resolutions_, t, 1);
                e = s, i = this.resolutions_[s], s == this.resolutions_.length - 1 ? r = 2 : r = i / this.resolutions_[s + 1]
            } else i = this.maxResolution_, r = this.zoomFactor_;
            return e + Math.log(i / t) / Math.log(r)
        }

        getResolutionForZoom(t) {
            if (this.resolutions_) {
                if (this.resolutions_.length <= 1) return 0;
                let e = ot(Math.floor(t), 0, this.resolutions_.length - 2),
                    i = this.resolutions_[e] / this.resolutions_[e + 1];
                return this.resolutions_[e] / Math.pow(i, ot(t - e, 0, 1))
            }
            return this.maxResolution_ / Math.pow(this.zoomFactor_, t - this.minZoom_)
        }

        fit(t, e) {
            let i;
            if (z(Array.isArray(t) || typeof t.getSimplifiedGeometry == "function", "Invalid extent or geometry provided as `geometry`"), Array.isArray(t)) {
                z(!Wi(t), "Cannot fit empty extent provided as `geometry`");
                let r = ve(t, this.getProjection());
                i = Ka(r)
            } else if (t.getType() === "Circle") {
                let r = ve(t.getExtent(), this.getProjection());
                i = Ka(r), i.rotate(this.getRotation(), Ee(r))
            } else {
                let r = _n();
                r ? i = t.clone().transform(r, this.getProjection()) : i = t
            }
            this.fitInternal(i, e)
        }

        rotatedExtentForGeometry(t) {
            let e = this.getRotation(), i = Math.cos(e), r = Math.sin(-e), s = t.getFlatCoordinates(),
                o = t.getStride(), a = 1 / 0, l = 1 / 0, h = -1 / 0, c = -1 / 0;
            for (let u = 0, d = s.length; u < d; u += o) {
                let f = s[u] * i - s[u + 1] * r, g = s[u] * r + s[u + 1] * i;
                a = Math.min(a, f), l = Math.min(l, g), h = Math.max(h, f), c = Math.max(c, g)
            }
            return [a, l, h, c]
        }

        fitInternal(t, e) {
            e = e || {};
            let i = e.size;
            i || (i = this.getViewportSizeMinusPadding_());
            let r = e.padding !== void 0 ? e.padding : [0, 0, 0, 0], s = e.nearest !== void 0 ? e.nearest : !1, o;
            e.minResolution !== void 0 ? o = e.minResolution : e.maxZoom !== void 0 ? o = this.getResolutionForZoom(e.maxZoom) : o = 0;
            let a = this.rotatedExtentForGeometry(t),
                l = this.getResolutionForExtentInternal(a, [i[0] - r[1] - r[3], i[1] - r[0] - r[2]]);
            l = isNaN(l) ? o : Math.max(l, o), l = this.getConstrainedResolution(l, s ? 0 : 1);
            let h = this.getRotation(), c = Math.sin(h), u = Math.cos(h), d = Ee(a);
            d[0] += (r[1] - r[3]) / 2 * l, d[1] += (r[0] - r[2]) / 2 * l;
            let f = d[0] * u - d[1] * c, g = d[1] * u + d[0] * c, m = this.getConstrainedCenter([f, g], l),
                p = e.callback ? e.callback : Me;
            e.duration !== void 0 ? this.animateInternal({
                resolution: l,
                center: m,
                duration: e.duration,
                easing: e.easing
            }, p) : (this.targetResolution_ = l, this.targetCenter_ = m, this.applyTargetState_(!1, !0), io(p, !0))
        }

        centerOn(t, e, i) {
            this.centerOnInternal(Te(t, this.getProjection()), e, i)
        }

        centerOnInternal(t, e, i) {
            this.setCenterInternal(qa(t, e, i, this.getResolution(), this.getRotation()))
        }

        calculateCenterShift(t, e, i, r) {
            let s, o = this.padding_;
            if (o && t) {
                let a = this.getViewportSizeMinusPadding_(-i), l = qa(t, r, [a[0] / 2 + o[3], a[1] / 2 + o[0]], e, i);
                s = [t[0] - l[0], t[1] - l[1]]
            }
            return s
        }

        isDef() {
            return !!this.getCenterInternal() && this.getResolution() !== void 0
        }

        adjustCenter(t) {
            let e = nr(this.targetCenter_, this.getProjection());
            this.setCenter([e[0] + t[0], e[1] + t[1]])
        }

        adjustCenterInternal(t) {
            let e = this.targetCenter_;
            this.setCenterInternal([e[0] + t[0], e[1] + t[1]])
        }

        adjustResolution(t, e) {
            e = e && Te(e, this.getProjection()), this.adjustResolutionInternal(t, e)
        }

        adjustResolutionInternal(t, e) {
            let i = this.getAnimating() || this.getInteracting(), r = this.getViewportSize_(this.getRotation()),
                s = this.constraints_.resolution(this.targetResolution_ * t, 0, r, i);
            e && (this.targetCenter_ = this.calculateCenterZoom(s, e)), this.targetResolution_ *= t, this.applyTargetState_()
        }

        adjustZoom(t, e) {
            this.adjustResolution(Math.pow(this.zoomFactor_, -t), e)
        }

        adjustRotation(t, e) {
            e && (e = Te(e, this.getProjection())), this.adjustRotationInternal(t, e)
        }

        adjustRotationInternal(t, e) {
            let i = this.getAnimating() || this.getInteracting(),
                r = this.constraints_.rotation(this.targetRotation_ + t, i);
            e && (this.targetCenter_ = this.calculateCenterRotate(r, e)), this.targetRotation_ += t, this.applyTargetState_()
        }

        setCenter(t) {
            this.setCenterInternal(t && Te(t, this.getProjection()))
        }

        setCenterInternal(t) {
            this.targetCenter_ = t, this.applyTargetState_()
        }

        setHint(t, e) {
            return this.hints_[t] += e, this.changed(), this.hints_[t]
        }

        setResolution(t) {
            this.targetResolution_ = t, this.applyTargetState_()
        }

        setRotation(t) {
            this.targetRotation_ = t, this.applyTargetState_()
        }

        setZoom(t) {
            this.setResolution(this.getResolutionForZoom(t))
        }

        applyTargetState_(t, e) {
            let i = this.getAnimating() || this.getInteracting() || e,
                r = this.constraints_.rotation(this.targetRotation_, i), s = this.getViewportSize_(r),
                o = this.constraints_.resolution(this.targetResolution_, 0, s, i),
                a = this.constraints_.center(this.targetCenter_, o, s, i, this.calculateCenterShift(this.targetCenter_, o, r, s));
            this.get(we.ROTATION) !== r && this.set(we.ROTATION, r), this.get(we.RESOLUTION) !== o && (this.set(we.RESOLUTION, o), this.set("zoom", this.getZoom(), !0)), (!a || !this.get(we.CENTER) || !mn(this.get(we.CENTER), a)) && this.set(we.CENTER, a), this.getAnimating() && !t && this.cancelAnimations(), this.cancelAnchor_ = void 0
        }

        resolveConstraints(t, e, i) {
            t = t !== void 0 ? t : 200;
            let r = e || 0, s = this.constraints_.rotation(this.targetRotation_), o = this.getViewportSize_(s),
                a = this.constraints_.resolution(this.targetResolution_, r, o),
                l = this.constraints_.center(this.targetCenter_, a, o, !1, this.calculateCenterShift(this.targetCenter_, a, s, o));
            if (t === 0 && !this.cancelAnchor_) {
                this.targetResolution_ = a, this.targetRotation_ = s, this.targetCenter_ = l, this.applyTargetState_();
                return
            }
            i = i || (t === 0 ? this.cancelAnchor_ : void 0), this.cancelAnchor_ = void 0, (this.getResolution() !== a || this.getRotation() !== s || !this.getCenterInternal() || !mn(this.getCenterInternal(), l)) && (this.getAnimating() && this.cancelAnimations(), this.animateInternal({
                rotation: s,
                center: l,
                resolution: a,
                duration: t,
                easing: Re,
                anchor: i
            }))
        }

        beginInteraction() {
            this.resolveConstraints(0), this.setHint(Pt.INTERACTING, 1)
        }

        endInteraction(t, e, i) {
            i = i && Te(i, this.getProjection()), this.endInteractionInternal(t, e, i)
        }

        endInteractionInternal(t, e, i) {
            this.getInteracting() && (this.setHint(Pt.INTERACTING, -1), this.resolveConstraints(t, e, i))
        }

        getConstrainedCenter(t, e) {
            let i = this.getViewportSize_(this.getRotation());
            return this.constraints_.center(t, e || this.getResolution(), i)
        }

        getConstrainedZoom(t, e) {
            let i = this.getResolutionForZoom(t);
            return this.getZoomForResolution(this.getConstrainedResolution(i, e))
        }

        getConstrainedResolution(t, e) {
            e = e || 0;
            let i = this.getViewportSize_(this.getRotation());
            return this.constraints_.resolution(t, e, i)
        }
    };
    me = Ha
});

function Ur(n, t) {
    if (!n.visible) return !1;
    let e = t.resolution;
    if (e < n.minResolution || e >= n.maxResolution) return !1;
    let i = t.zoom;
    return i > n.minZoom && i <= n.maxZoom
}

var $a, xn, lr = v(() => {
    ha();
    pt();
    aa();
    $n();
    no();
    Zt();
    rt();
    fe();
    $a = class extends Gs {
        constructor(t) {
            let e = Object.assign({}, t);
            delete e.source, super(e), this.on, this.once, this.un, this.mapPrecomposeKey_ = null, this.mapRenderKey_ = null, this.sourceChangeKey_ = null, this.renderer_ = null, this.sourceReady_ = !1, this.rendered = !1, t.render && (this.render = t.render), t.map && this.setMap(t.map), this.addChangeListener(lt.SOURCE, this.handleSourcePropertyChange_);
            let i = t.source ? t.source : null;
            this.setSource(i)
        }

        getLayersArray(t) {
            return t = t || [], t.push(this), t
        }

        getLayerStatesArray(t) {
            return t = t || [], t.push(this.getLayerState()), t
        }

        getSource() {
            return this.get(lt.SOURCE) || null
        }

        getRenderSource() {
            return this.getSource()
        }

        getSourceState() {
            let t = this.getSource();
            return t ? t.getState() : "undefined"
        }

        handleSourceChange_() {
            this.changed(), !(this.sourceReady_ || this.getSource().getState() !== "ready") && (this.sourceReady_ = !0, this.dispatchEvent("sourceready"))
        }

        handleSourcePropertyChange_() {
            this.sourceChangeKey_ && (et(this.sourceChangeKey_), this.sourceChangeKey_ = null), this.sourceReady_ = !1;
            let t = this.getSource();
            t && (this.sourceChangeKey_ = U(t, D.CHANGE, this.handleSourceChange_, this), t.getState() === "ready" && (this.sourceReady_ = !0, setTimeout(() => {
                this.dispatchEvent("sourceready")
            }, 0))), this.changed()
        }

        getFeatures(t) {
            return this.renderer_ ? this.renderer_.getFeatures(t) : Promise.resolve([])
        }

        getData(t) {
            return !this.renderer_ || !this.rendered ? null : this.renderer_.getData(t)
        }

        isVisible(t) {
            let e, i = this.getMapInternal();
            !t && i && (t = i.getView()), t instanceof me ? e = {
                viewState: t.getState(),
                extent: t.calculateExtent()
            } : e = t, !e.layerStatesArray && i && (e.layerStatesArray = i.getLayerGroup().getLayerStatesArray());
            let r;
            e.layerStatesArray ? r = e.layerStatesArray.find(o => o.layer === this) : r = this.getLayerState();
            let s = this.getExtent();
            return Ur(r, e.viewState) && (!s || yt(s, e.extent))
        }

        getAttributions(t) {
            if (!this.isVisible(t)) return [];
            let e, i = this.getSource();
            if (i && (e = i.getAttributions()), !e) return [];
            let r = t instanceof me ? t.getViewStateAndExtent() : t, s = e(r);
            return Array.isArray(s) || (s = [s]), s
        }

        render(t, e) {
            let i = this.getRenderer();
            return i.prepareFrame(t) ? (this.rendered = !0, i.renderFrame(t, e)) : null
        }

        unrender() {
            this.rendered = !1
        }

        setMapInternal(t) {
            t || this.unrender(), this.set(lt.MAP, t)
        }

        getMapInternal() {
            return this.get(lt.MAP)
        }

        setMap(t) {
            this.mapPrecomposeKey_ && (et(this.mapPrecomposeKey_), this.mapPrecomposeKey_ = null), t || this.changed(), this.mapRenderKey_ && (et(this.mapRenderKey_), this.mapRenderKey_ = null), t && (this.mapPrecomposeKey_ = U(t, Jt.PRECOMPOSE, function (e) {
                let r = e.frameState.layerStatesArray, s = this.getLayerState(!1);
                z(!r.some(function (o) {
                    return o.layer === s.layer
                }), "A layer can only be added to the map once. Use either `layer.setMap()` or `map.addLayer()`, not both."), r.push(s)
            }, this), this.mapRenderKey_ = U(this, D.CHANGE, t.render, t), this.changed())
        }

        setSource(t) {
            this.set(lt.SOURCE, t)
        }

        getRenderer() {
            return this.renderer_ || (this.renderer_ = this.createRenderer()), this.renderer_
        }

        hasRenderer() {
            return !!this.renderer_
        }

        createRenderer() {
            return null
        }

        disposeInternal() {
            this.renderer_ && (this.renderer_.dispose(), delete this.renderer_), this.setSource(null), super.disposeInternal()
        }
    };
    xn = $a
});
var Qa, ro, tl = v(() => {
    je();
    Qa = class extends Ft {
        constructor(t, e, i, r) {
            super(t), this.inversePixelTransform = e, this.frameState = i, this.context = r
        }
    }, ro = Qa
});
var jr, Zi, hr, el, Dm, md, il, cr = v(() => {
    jr = "ol-hidden", Zi = "ol-unselectable", hr = "ol-control", el = "ol-collapsed", Dm = new RegExp(["^\\s*(?=(?:(?:[-a-z]+\\s*){0,2}(italic|oblique))?)", "(?=(?:(?:[-a-z]+\\s*){0,2}(small-caps))?)", "(?=(?:(?:[-a-z]+\\s*){0,2}(bold(?:er)?|lighter|[1-9]00 ))?)", "(?:(?:normal|\\1|\\2|\\3)\\s*){0,3}((?:xx?-)?", "(?:small|large)|medium|smaller|larger|[\\.\\d]+(?:\\%|in|[cem]m|ex|p[ctx]))", "(?:\\s*\\/\\s*(normal|[\\.\\d]+(?:\\%|in|[cem]m|ex|p[ctx])?))", `?\\s*([-,\\"\\'\\sa-z]+?)\\s*$`].join(""), "i"), md = ["style", "variant", "weight", "size", "lineHeight", "family"], il = function (n) {
        let t = n.match(Dm);
        if (!t) return null;
        let e = {lineHeight: "normal", size: "1.2em", style: "normal", weight: "normal", variant: "normal"};
        for (let i = 0, r = md.length; i < r; ++i) {
            let s = t[i + 1];
            s !== void 0 && (e[md[i]] = s)
        }
        return e.families = e.family.split(/,\s?/), e
    }
});

function gt(n, t, e, i) {
    let r;
    return e && e.length ? r = e.shift() : Yn ? r = new OffscreenCanvas(n || 300, t || 300) : r = document.createElement("canvas"), n && (r.width = n), t && (r.height = t), r.getContext("2d", i)
}

function En(n) {
    let t = n.canvas;
    t.width = 1, t.height = 1, n.clearRect(0, 0, 1, 1)
}

function nl(n, t) {
    let e = t.parentNode;
    e && e.replaceChild(n, t)
}

function Br(n) {
    return n && n.parentNode ? n.parentNode.removeChild(n) : null
}

function pd(n) {
    for (; n.lastChild;) n.removeChild(n.lastChild)
}

function _d(n, t) {
    let e = n.childNodes;
    for (let i = 0; ; ++i) {
        let r = e[i], s = t[i];
        if (!r && !s) break;
        if (r !== s) {
            if (!r) {
                n.appendChild(s);
                continue
            }
            if (!s) {
                n.removeChild(r), --i;
                continue
            }
            n.insertBefore(s, r)
        }
    }
}

var te = v(() => {
    ci()
});

function xd(n, t) {
    return ur || (ur = gt(1, 1)), n != rl && (ur.font = n, rl = ur.font), ur.measureText(t)
}

function so(n, t) {
    return xd(n, t).width
}

function ol(n, t, e) {
    if (t in e) return e[t];
    let i = t.split(`
`).reduce((r, s) => Math.max(r, so(n, s)), 0);
    return e[t] = i, i
}

function Ed(n, t) {
    let e = [], i = [], r = [], s = 0, o = 0, a = 0, l = 0;
    for (let h = 0, c = t.length; h <= c; h += 2) {
        let u = t[h];
        if (u === `
` || h === c) {
            s = Math.max(s, o), r.push(o), o = 0, a += l;
            continue
        }
        let d = t[h + 1] || n.font, f = so(d, u);
        e.push(f), o += f;
        let g = km(d);
        i.push(g), l = Math.max(l, g)
    }
    return {width: s, height: a, widths: e, heights: i, lineWidths: r}
}

function Cd(n, t, e, i, r, s, o, a, l, h, c) {
    n.save(), e !== 1 && (n.globalAlpha *= e), t && n.transform.apply(n, t), i.contextInstructions ? (n.translate(l, h), n.scale(c[0], c[1]), Nm(i, n)) : c[0] < 0 || c[1] < 0 ? (n.translate(l, h), n.scale(c[0], c[1]), n.drawImage(i, r, s, o, a, 0, 0, o, a)) : n.drawImage(i, r, s, o, a, l, h, o * c[0], a * c[1]), n.restore()
}

function Nm(n, t) {
    let e = n.contextInstructions;
    for (let i = 0, r = e.length; i < r; i += 2) Array.isArray(e[i + 1]) ? t[e[i]].apply(t, e[i + 1]) : t[e[i]] = e[i + 1]
}

var oo, Ot, qe, se, oe, He, xi, Ei, qi, Cn, Ci, wi, Ze, ur, rl, sl, yd, km, Ti = v(() => {
    Fe();
    ci();
    Oe();
    te();
    cr();
    oo = "10px sans-serif", Ot = "#000", qe = "round", se = [], oe = 0, He = "round", xi = 10, Ei = "#000", qi = "center", Cn = "middle", Ci = [0, 0, 0, 0], wi = 1, Ze = new St, ur = null, sl = {}, yd = function () {
        let t = "32px ", e = ["monospace", "serif"], i = e.length, r = "wmytzilWMYTZIL@#/&?$%10\uF013", s, o;

        function a(h, c, u) {
            let d = !0;
            for (let f = 0; f < i; ++f) {
                let g = e[f];
                if (o = so(h + " " + c + " " + t + g, r), u != g) {
                    let m = so(h + " " + c + " " + t + u + "," + g, r);
                    d = d && m != o
                }
            }
            return !!d
        }

        function l() {
            let h = !0, c = Ze.getKeys();
            for (let u = 0, d = c.length; u < d; ++u) {
                let f = c[u];
                Ze.get(f) < 100 && (a.apply(this, f.split(`
`)) ? (Be(sl), ur = null, rl = void 0, Ze.set(f, 100)) : (Ze.set(f, Ze.get(f) + 1, !0), h = !1))
            }
            h && (clearInterval(s), s = void 0)
        }

        return function (h) {
            let c = il(h);
            if (!c) return;
            let u = c.families;
            for (let d = 0, f = u.length; d < f; ++d) {
                let g = u[d], m = c.style + `
` + c.weight + `
` + g;
                Ze.get(m) === void 0 && (Ze.set(m, 100, !0), a(c.style, c.weight, g) || (Ze.set(m, 0, !0), s === void 0 && (s = setInterval(l, 32))))
            }
        }
    }(), km = function () {
        let n;
        return function (t) {
            let e = sl[t];
            if (e == null) {
                if (Yn) {
                    let i = il(t), r = xd(t, "\u017Dg");
                    e = (isNaN(Number(i.lineHeight)) ? 1.2 : Number(i.lineHeight)) * (r.actualBoundingBoxAscent + r.actualBoundingBoxDescent)
                } else n || (n = document.createElement("div"), n.innerHTML = "M", n.style.minHeight = "0", n.style.maxHeight = "none", n.style.height = "auto", n.style.padding = "0", n.style.border = "none", n.style.position = "absolute", n.style.display = "block", n.style.left = "-99999px"), n.style.font = t, document.body.appendChild(n), e = n.offsetHeight, document.body.removeChild(n);
                sl[t] = e
            }
            return e
        }
    }()
});
var Je, fl = v(() => {
    Je = {
        POSTRENDER: "postrender",
        MOVESTART: "movestart",
        MOVEEND: "moveend",
        LOADSTART: "loadstart",
        LOADEND: "loadend"
    }
});
var Id = {};
Fi(Id, {default: () => vi});
var pl, vi, dr = v(() => {
    Fe();
    fl();
    Ht();
    fe();
    te();
    pl = class extends St {
        constructor(t) {
            super();
            let e = t.element;
            e && !t.target && !e.style.pointerEvents && (e.style.pointerEvents = "auto"), this.element = e || null, this.target_ = null, this.map_ = null, this.listenerKeys = [], t.render && (this.render = t.render), t.target && this.setTarget(t.target)
        }

        disposeInternal() {
            Br(this.element), super.disposeInternal()
        }

        getMap() {
            return this.map_
        }

        setMap(t) {
            this.map_ && Br(this.element);
            for (let e = 0, i = this.listenerKeys.length; e < i; ++e) et(this.listenerKeys[e]);
            this.listenerKeys.length = 0, this.map_ = t, t && ((this.target_ ? this.target_ : t.getOverlayContainerStopEvent()).appendChild(this.element), this.render !== Me && this.listenerKeys.push(U(t, Je.POSTRENDER, this.render, this)), t.render())
        }

        render(t) {
        }

        setTarget(t) {
            this.target_ = typeof t == "string" ? document.getElementById(t) : t
        }
    }, vi = pl
});

function Dl(n) {
    return n[0] > 0 && n[1] > 0
}

function Hd(n, t, e) {
    return e === void 0 && (e = [0, 0]), e[0] = n[0] * t + .5 | 0, e[1] = n[1] * t + .5 | 0, e
}

function bt(n, t) {
    return Array.isArray(n) ? n : (t === void 0 ? t = [n, n] : (t[0] = n, t[1] = n), t)
}

var Ri = v(() => {
});
var ht, mr = v(() => {
    ht = {IDLE: 0, LOADING: 1, LOADED: 2, ERROR: 3, EMPTY: 4}
});

function nf(n, t, e) {
    let i = n, r = !0, s = !1, o = !1, a = [Gn(i, D.LOAD, function () {
        o = !0, s || t()
    })];
    return i.src && Vo ? (s = !0, i.decode().then(function () {
        r && t()
    }).catch(function (l) {
        r && (o ? t() : e())
    })) : a.push(Gn(i, D.ERROR, e)), function () {
        r = !1, a.forEach(et)
    }
}

function Wm(n, t) {
    return new Promise((e, i) => {
        function r() {
            o(), e(n)
        }

        function s() {
            o(), i(new Error("Image load error"))
        }

        function o() {
            n.removeEventListener("load", r), n.removeEventListener("error", s)
        }

        n.addEventListener("load", r), n.addEventListener("error", s), t && (n.src = t)
    })
}

function rf(n, t) {
    return t && (n.src = t), n.src && Vo ? new Promise((e, i) => n.decode().then(() => e(n)).catch(r => n.complete && n.width ? e(n) : i(r))) : Wm(n)
}

var Wl = v(() => {
    pt();
    ci();
    fe()
});

function mf(n) {
    return n ? Array.isArray(n) ? function (t) {
        return n
    } : typeof n == "function" ? n : function (t) {
        return [n]
    } : null
}

var ql, xo, Hl = v(() => {
    Fe();
    Yt();
    ql = class extends St {
        constructor(t) {
            super(), this.projection = ft(t.projection), this.attributions_ = mf(t.attributions), this.attributionsCollapsible_ = t.attributionsCollapsible !== void 0 ? t.attributionsCollapsible : !0, this.loading = !1, this.state_ = t.state !== void 0 ? t.state : "ready", this.wrapX_ = t.wrapX !== void 0 ? t.wrapX : !1, this.interpolate_ = !!t.interpolate, this.viewResolver = null, this.viewRejector = null;
            let e = this;
            this.viewPromise_ = new Promise(function (i, r) {
                e.viewResolver = i, e.viewRejector = r
            })
        }

        getAttributions() {
            return this.attributions_
        }

        getAttributionsCollapsible() {
            return this.attributionsCollapsible_
        }

        getProjection() {
            return this.projection
        }

        getResolutions(t) {
            return null
        }

        getView() {
            return this.viewPromise_
        }

        getState() {
            return this.state_
        }

        getWrapX() {
            return this.wrapX_
        }

        getInterpolate() {
            return this.interpolate_
        }

        refresh() {
            this.changed()
        }

        setAttributions(t) {
            this.attributions_ = mf(t), this.changed()
        }

        setState(t) {
            this.state_ = t, this.changed()
        }
    };
    xo = ql
});
var sh, If, Lf = v(() => {
    pt();
    mr();
    Uo();
    wt();
    sh = class extends Cs {
        constructor(t) {
            super(), this.ready = !0, this.boundHandleImageChange_ = this.handleImageChange_.bind(this), this.layer_ = t, this.declutterExecutorGroup = null
        }

        getFeatures(t) {
            return H()
        }

        getData(t) {
            return null
        }

        prepareFrame(t) {
            return H()
        }

        renderFrame(t, e) {
            return H()
        }

        loadedTileCallback(t, e, i) {
            t[e] || (t[e] = {}), t[e][i.tileCoord.toString()] = i
        }

        createLoadedTileFinder(t, e, i) {
            return (r, s) => {
                let o = this.loadedTileCallback.bind(this, i, r);
                return t.forEachLoadedTile(e, r, s, o)
            }
        }

        forEachFeatureAtCoordinate(t, e, i, r, s) {
        }

        getLayer() {
            return this.layer_
        }

        handleFontsChanged() {
        }

        handleImageChange_(t) {
            let e = t.target;
            (e.getState() === ht.LOADED || e.getState() === ht.ERROR) && this.renderIfReadyAndVisible()
        }

        loadImage(t) {
            let e = t.getState();
            return e != ht.LOADED && e != ht.ERROR && t.addEventListener(D.CHANGE, this.boundHandleImageChange_), e == ht.IDLE && (t.load(), e = t.getState()), e == ht.LOADED
        }

        renderIfReadyAndVisible() {
            let t = this.getLayer();
            t && t.getVisible() && t.getSourceState() === "ready" && t.changed()
        }

        disposeInternal() {
            delete this.layer_, super.disposeInternal()
        }
    }, If = sh
});

function Hm() {
    _r = gt(1, 1, void 0, {willReadFrequently: !0})
}

var ah, _r, oh, Ro, lh = v(() => {
    Lf();
    tl();
    $n();
    De();
    mi();
    te();
    Ct();
    rt();
    ah = [], _r = null;
    oh = class extends If {
        constructor(t) {
            super(t), this.container = null, this.renderedResolution, this.tempTransform = kt(), this.pixelTransform = kt(), this.inversePixelTransform = kt(), this.context = null, this.containerReused = !1, this.pixelContext_ = null, this.frameState = null
        }

        getImageData(t, e, i) {
            _r || Hm(), _r.clearRect(0, 0, 1, 1);
            let r;
            try {
                _r.drawImage(t, e, i, 1, 1, 0, 0, 1, 1), r = _r.getImageData(0, 0, 1, 1).data
            } catch {
                return _r = null, null
            }
            return r
        }

        getBackground(t) {
            let i = this.getLayer().getBackground();
            return typeof i == "function" && (i = i(t.viewState.resolution)), i || void 0
        }

        useContainer(t, e, i) {
            let r = this.getLayer().getClassName(), s, o;
            if (t && t.className === r && (!i || t && t.style.backgroundColor && Vt(dn(t.style.backgroundColor), dn(i)))) {
                let a = t.firstElementChild;
                a instanceof HTMLCanvasElement && (o = a.getContext("2d"))
            }
            if (o && o.canvas.style.transform === e ? (this.container = t, this.context = o, this.containerReused = !0) : this.containerReused ? (this.container = null, this.context = null, this.containerReused = !1) : this.container && (this.container.style.backgroundColor = null), !this.container) {
                s = document.createElement("div"), s.className = r;
                let a = s.style;
                a.position = "absolute", a.width = "100%", a.height = "100%", o = gt();
                let l = o.canvas;
                s.appendChild(l), a = l.style, a.position = "absolute", a.left = "0", a.transformOrigin = "top left", this.container = s, this.context = o
            }
            !this.containerReused && i && !this.container.style.backgroundColor && (this.container.style.backgroundColor = i)
        }

        clipUnrotated(t, e, i) {
            let r = Ce(i), s = Zn(i), o = Vn(i), a = Kn(i);
            _t(e.coordinateToPixelTransform, r), _t(e.coordinateToPixelTransform, s), _t(e.coordinateToPixelTransform, o), _t(e.coordinateToPixelTransform, a);
            let l = this.inversePixelTransform;
            _t(l, r), _t(l, s), _t(l, o), _t(l, a), t.save(), t.beginPath(), t.moveTo(Math.round(r[0]), Math.round(r[1])), t.lineTo(Math.round(s[0]), Math.round(s[1])), t.lineTo(Math.round(o[0]), Math.round(o[1])), t.lineTo(Math.round(a[0]), Math.round(a[1])), t.clip()
        }

        dispatchRenderEvent_(t, e, i) {
            let r = this.getLayer();
            if (r.hasListener(t)) {
                let s = new ro(t, this.inversePixelTransform, i, e);
                r.dispatchEvent(s)
            }
        }

        preRender(t, e) {
            this.frameState = e, this.dispatchRenderEvent_(Jt.PRERENDER, t, e)
        }

        postRender(t, e) {
            this.dispatchRenderEvent_(Jt.POSTRENDER, t, e)
        }

        getRenderTransform(t, e, i, r, s, o, a) {
            let l = s / 2, h = o / 2, c = r / e, u = -c, d = -t[0] + a, f = -t[1];
            return zt(this.tempTransform, l, h, c, u, -i, d, f)
        }

        disposeInternal() {
            delete this.frameState, super.disposeInternal()
        }
    }, Ro = oh
});
var Pf = {};
Fi(Pf, {createStyleFunction: () => Mf, default: () => So});

function Mf(n) {
    if (typeof n == "function") return n;
    let t;
    return Array.isArray(n) ? t = n : (z(typeof n.getZIndex == "function", "Expected an `ol/style/Style` or an array of `ol/style/Style.js`"), t = [n]), function () {
        return t
    }
}

var uh, So, dh = v(() => {
    Fe();
    pt();
    Zt();
    fe();
    uh = class n extends St {
        constructor(t) {
            if (super(), this.on, this.once, this.un, this.id_ = void 0, this.geometryName_ = "geometry", this.style_ = null, this.styleFunction_ = void 0, this.geometryChangeKey_ = null, this.addChangeListener(this.geometryName_, this.handleGeometryChanged_), t) if (typeof t.getSimplifiedGeometry == "function") {
                let e = t;
                this.setGeometry(e)
            } else {
                let e = t;
                this.setProperties(e)
            }
        }

        clone() {
            let t = new n(this.hasProperties() ? this.getProperties() : null);
            t.setGeometryName(this.getGeometryName());
            let e = this.getGeometry();
            e && t.setGeometry(e.clone());
            let i = this.getStyle();
            return i && t.setStyle(i), t
        }

        getGeometry() {
            return this.get(this.geometryName_)
        }

        getId() {
            return this.id_
        }

        getGeometryName() {
            return this.geometryName_
        }

        getStyle() {
            return this.style_
        }

        getStyleFunction() {
            return this.styleFunction_
        }

        handleGeometryChange_() {
            this.changed()
        }

        handleGeometryChanged_() {
            this.geometryChangeKey_ && (et(this.geometryChangeKey_), this.geometryChangeKey_ = null);
            let t = this.getGeometry();
            t && (this.geometryChangeKey_ = U(t, D.CHANGE, this.handleGeometryChange_, this)), this.changed()
        }

        setGeometry(t) {
            this.set(this.geometryName_, t)
        }

        setStyle(t) {
            this.style_ = t, this.styleFunction_ = t ? Mf(t) : void 0, this.changed()
        }

        setId(t) {
            this.id_ = t, this.changed()
        }

        setGeometryName(t) {
            this.removeChangeListener(this.geometryName_, this.handleGeometryChanged_), this.geometryName_ = t, this.addChangeListener(this.geometryName_, this.handleGeometryChanged_), this.handleGeometryChanged_()
        }
    };
    So = uh
});
var fh, tn, Io = v(() => {
    fh = class n {
        constructor(t) {
            t = t || {}, this.color_ = t.color !== void 0 ? t.color : null
        }

        clone() {
            let t = this.getColor();
            return new n({color: Array.isArray(t) ? t.slice() : t || void 0})
        }

        getColor() {
            return this.color_
        }

        setColor(t) {
            this.color_ = t
        }
    }, tn = fh
});

function gh(n, t, e, i, r, s, o) {
    let a, l, h = (e - t) / i;
    if (h === 1) a = t; else if (h === 2) a = t, l = r; else if (h !== 0) {
        let c = n[t], u = n[t + 1], d = 0, f = [0];
        for (let p = t + i; p < e; p += i) {
            let _ = n[p], y = n[p + 1];
            d += Math.sqrt((_ - c) * (_ - c) + (y - u) * (y - u)), f.push(d), c = _, u = y
        }
        let g = r * d, m = Lc(f, g);
        m < 0 ? (l = (g - f[-m - 2]) / (f[-m - 1] - f[-m - 2]), a = t + (-m - 2) * i) : a = t + m * i
    }
    o = o > 1 ? o : 2, s = s || new Array(o);
    for (let c = 0; c < o; ++c) s[c] = a === void 0 ? NaN : l === void 0 ? n[a + c] : qt(n[a + c], n[a + i + c], l);
    return s
}

var Of = v(() => {
    Ct();
    xt()
});

function Ff(n, t, e, i) {
    let r = n[t], s = n[t + 1], o = 0;
    for (let a = t + i; a < e; a += i) {
        let l = n[a], h = n[a + 1];
        o += Math.sqrt((l - r) * (l - r) + (h - s) * (h - s)), r = l, s = h
    }
    return o
}

var Df = v(() => {
});
var mh, Rn, ph = v(() => {
    mh = class n {
        constructor(t) {
            t = t || {}, this.color_ = t.color !== void 0 ? t.color : null, this.lineCap_ = t.lineCap, this.lineDash_ = t.lineDash !== void 0 ? t.lineDash : null, this.lineDashOffset_ = t.lineDashOffset, this.lineJoin_ = t.lineJoin, this.miterLimit_ = t.miterLimit, this.width_ = t.width
        }

        clone() {
            let t = this.getColor();
            return new n({
                color: Array.isArray(t) ? t.slice() : t || void 0,
                lineCap: this.getLineCap(),
                lineDash: this.getLineDash() ? this.getLineDash().slice() : void 0,
                lineDashOffset: this.getLineDashOffset(),
                lineJoin: this.getLineJoin(),
                miterLimit: this.getMiterLimit(),
                width: this.getWidth()
            })
        }

        getColor() {
            return this.color_
        }

        getLineCap() {
            return this.lineCap_
        }

        getLineDash() {
            return this.lineDash_
        }

        getLineDashOffset() {
            return this.lineDashOffset_
        }

        getLineJoin() {
            return this.lineJoin_
        }

        getMiterLimit() {
            return this.miterLimit_
        }

        getWidth() {
            return this.width_
        }

        setColor(t) {
            this.color_ = t
        }

        setLineCap(t) {
            this.lineCap_ = t
        }

        setLineDash(t) {
            this.lineDash_ = t
        }

        setLineDashOffset(t) {
            this.lineDashOffset_ = t
        }

        setLineJoin(t) {
            this.lineJoin_ = t
        }

        setMiterLimit(t) {
            this.miterLimit_ = t
        }

        setWidth(t) {
            this.width_ = t
        }
    }, Rn = mh
});
var _h, Lo, yh = v(() => {
    wt();
    Ri();
    _h = class n {
        constructor(t) {
            this.opacity_ = t.opacity, this.rotateWithView_ = t.rotateWithView, this.rotation_ = t.rotation, this.scale_ = t.scale, this.scaleArray_ = bt(t.scale), this.displacement_ = t.displacement, this.declutterMode_ = t.declutterMode
        }

        clone() {
            let t = this.getScale();
            return new n({
                opacity: this.getOpacity(),
                scale: Array.isArray(t) ? t.slice() : t,
                rotation: this.getRotation(),
                rotateWithView: this.getRotateWithView(),
                displacement: this.getDisplacement().slice(),
                declutterMode: this.getDeclutterMode()
            })
        }

        getOpacity() {
            return this.opacity_
        }

        getRotateWithView() {
            return this.rotateWithView_
        }

        getRotation() {
            return this.rotation_
        }

        getScale() {
            return this.scale_
        }

        getScaleArray() {
            return this.scaleArray_
        }

        getDisplacement() {
            return this.displacement_
        }

        getDeclutterMode() {
            return this.declutterMode_
        }

        getAnchor() {
            return H()
        }

        getImage(t) {
            return H()
        }

        getHitDetectionImage() {
            return H()
        }

        getPixelRatio(t) {
            return 1
        }

        getImageState() {
            return H()
        }

        getImageSize() {
            return H()
        }

        getOrigin() {
            return H()
        }

        getSize() {
            return H()
        }

        setDisplacement(t) {
            this.displacement_ = t
        }

        setOpacity(t) {
            this.opacity_ = t
        }

        setRotateWithView(t) {
            this.rotateWithView_ = t
        }

        setRotation(t) {
            this.rotation_ = t
        }

        setScale(t) {
            this.scale_ = t, this.scaleArray_ = bt(t)
        }

        listenImageChange(t) {
            H()
        }

        load() {
            H()
        }

        unlistenImageChange(t) {
            H()
        }
    }, Lo = _h
});

function ae(n) {
    return Array.isArray(n) ? ra(n) : n
}

var Qr = v(() => {
    mi()
});
var xh, bo, Eh = v(() => {
    mr();
    yh();
    mi();
    Qr();
    te();
    Ti();
    xh = class n extends Lo {
        constructor(t) {
            let e = t.rotateWithView !== void 0 ? t.rotateWithView : !1;
            super({
                opacity: 1,
                rotateWithView: e,
                rotation: t.rotation !== void 0 ? t.rotation : 0,
                scale: t.scale !== void 0 ? t.scale : 1,
                displacement: t.displacement !== void 0 ? t.displacement : [0, 0],
                declutterMode: t.declutterMode
            }), this.canvases_, this.hitDetectionCanvas_ = null, this.fill_ = t.fill !== void 0 ? t.fill : null, this.origin_ = [0, 0], this.points_ = t.points, this.radius_ = t.radius !== void 0 ? t.radius : t.radius1, this.radius2_ = t.radius2, this.angle_ = t.angle !== void 0 ? t.angle : 0, this.stroke_ = t.stroke !== void 0 ? t.stroke : null, this.size_, this.renderOptions_, this.render()
        }

        clone() {
            let t = this.getScale(), e = new n({
                fill: this.getFill() ? this.getFill().clone() : void 0,
                points: this.getPoints(),
                radius: this.getRadius(),
                radius2: this.getRadius2(),
                angle: this.getAngle(),
                stroke: this.getStroke() ? this.getStroke().clone() : void 0,
                rotation: this.getRotation(),
                rotateWithView: this.getRotateWithView(),
                scale: Array.isArray(t) ? t.slice() : t,
                displacement: this.getDisplacement().slice(),
                declutterMode: this.getDeclutterMode()
            });
            return e.setOpacity(this.getOpacity()), e
        }

        getAnchor() {
            let t = this.size_, e = this.getDisplacement(), i = this.getScaleArray();
            return [t[0] / 2 - e[0] / i[0], t[1] / 2 + e[1] / i[1]]
        }

        getAngle() {
            return this.angle_
        }

        getFill() {
            return this.fill_
        }

        setFill(t) {
            this.fill_ = t, this.render()
        }

        getHitDetectionImage() {
            return this.hitDetectionCanvas_ || (this.hitDetectionCanvas_ = this.createHitDetectionCanvas_(this.renderOptions_)), this.hitDetectionCanvas_
        }

        getImage(t) {
            let e = this.canvases_[t];
            if (!e) {
                let i = this.renderOptions_, r = gt(i.size * t, i.size * t);
                this.draw_(i, r, t), e = r.canvas, this.canvases_[t] = e
            }
            return e
        }

        getPixelRatio(t) {
            return t
        }

        getImageSize() {
            return this.size_
        }

        getImageState() {
            return ht.LOADED
        }

        getOrigin() {
            return this.origin_
        }

        getPoints() {
            return this.points_
        }

        getRadius() {
            return this.radius_
        }

        getRadius2() {
            return this.radius2_
        }

        getSize() {
            return this.size_
        }

        getStroke() {
            return this.stroke_
        }

        setStroke(t) {
            this.stroke_ = t, this.render()
        }

        listenImageChange(t) {
        }

        load() {
        }

        unlistenImageChange(t) {
        }

        calculateLineJoinSize_(t, e, i) {
            if (e === 0 || this.points_ === 1 / 0 || t !== "bevel" && t !== "miter") return e;
            let r = this.radius_, s = this.radius2_ === void 0 ? r : this.radius2_;
            if (r < s) {
                let R = r;
                r = s, s = R
            }
            let o = this.radius2_ === void 0 ? this.points_ : this.points_ * 2, a = 2 * Math.PI / o,
                l = s * Math.sin(a), h = Math.sqrt(s * s - l * l), c = r - h, u = Math.sqrt(l * l + c * c), d = u / l;
            if (t === "miter" && d <= i) return d * e;
            let f = e / 2 / d, g = e / 2 * (c / u), p = Math.sqrt((r + f) * (r + f) + g * g) - r;
            if (this.radius2_ === void 0 || t === "bevel") return p * 2;
            let _ = r * Math.sin(a), y = Math.sqrt(r * r - _ * _), C = s - y, T = Math.sqrt(_ * _ + C * C) / _;
            if (T <= i) {
                let R = T * e / 2 - s - r;
                return 2 * Math.max(p, R)
            }
            return p * 2
        }

        createRenderOptions() {
            let t = qe, e = He, i = 0, r = null, s = 0, o, a = 0;
            this.stroke_ && (o = ae(this.stroke_.getColor() ?? Ei), a = this.stroke_.getWidth() ?? wi, r = this.stroke_.getLineDash(), s = this.stroke_.getLineDashOffset() ?? 0, e = this.stroke_.getLineJoin() ?? He, t = this.stroke_.getLineCap() ?? qe, i = this.stroke_.getMiterLimit() ?? xi);
            let l = this.calculateLineJoinSize_(e, a, i), h = Math.max(this.radius_, this.radius2_ || 0),
                c = Math.ceil(2 * h + l);
            return {
                strokeStyle: o,
                strokeWidth: a,
                size: c,
                lineCap: t,
                lineDash: r,
                lineDashOffset: s,
                lineJoin: e,
                miterLimit: i
            }
        }

        render() {
            this.renderOptions_ = this.createRenderOptions();
            let t = this.renderOptions_.size;
            this.canvases_ = {}, this.hitDetectionCanvas_ = null, this.size_ = [t, t]
        }

        draw_(t, e, i) {
            if (e.scale(i, i), e.translate(t.size / 2, t.size / 2), this.createPath_(e), this.fill_) {
                let r = this.fill_.getColor();
                r === null && (r = Ot), e.fillStyle = ae(r), e.fill()
            }
            t.strokeStyle && (e.strokeStyle = t.strokeStyle, e.lineWidth = t.strokeWidth, t.lineDash && (e.setLineDash(t.lineDash), e.lineDashOffset = t.lineDashOffset), e.lineCap = t.lineCap, e.lineJoin = t.lineJoin, e.miterLimit = t.miterLimit, e.stroke())
        }

        createHitDetectionCanvas_(t) {
            let e;
            if (this.fill_) {
                let i = this.fill_.getColor(), r = 0;
                typeof i == "string" && (i = dn(i)), i === null ? r = 1 : Array.isArray(i) && (r = i.length === 4 ? i[3] : 1), r === 0 && (e = gt(t.size, t.size), this.drawHitDetectionCanvas_(t, e))
            }
            return e ? e.canvas : this.getImage(1)
        }

        createPath_(t) {
            let e = this.points_, i = this.radius_;
            if (e === 1 / 0) t.arc(0, 0, i, 0, 2 * Math.PI); else {
                let r = this.radius2_ === void 0 ? i : this.radius2_;
                this.radius2_ !== void 0 && (e *= 2);
                let s = this.angle_ - Math.PI / 2, o = 2 * Math.PI / e;
                for (let a = 0; a < e; a++) {
                    let l = s + a * o, h = a % 2 === 0 ? i : r;
                    t.lineTo(h * Math.cos(l), h * Math.sin(l))
                }
                t.closePath()
            }
        }

        drawHitDetectionCanvas_(t, e) {
            e.translate(t.size / 2, t.size / 2), this.createPath_(e), e.fillStyle = Ot, e.fill(), t.strokeStyle && (e.strokeStyle = t.strokeStyle, e.lineWidth = t.strokeWidth, t.lineDash && (e.setLineDash(t.lineDash), e.lineDashOffset = t.lineDashOffset), e.lineJoin = t.lineJoin, e.miterLimit = t.miterLimit, e.stroke())
        }
    }, bo = xh
});
var Ch, ts, wh = v(() => {
    Eh();
    Ch = class n extends bo {
        constructor(t) {
            t = t || {radius: 5}, super({
                points: 1 / 0,
                fill: t.fill,
                radius: t.radius,
                stroke: t.stroke,
                scale: t.scale !== void 0 ? t.scale : 1,
                rotation: t.rotation !== void 0 ? t.rotation : 0,
                rotateWithView: t.rotateWithView !== void 0 ? t.rotateWithView : !1,
                displacement: t.displacement !== void 0 ? t.displacement : [0, 0],
                declutterMode: t.declutterMode
            })
        }

        clone() {
            let t = this.getScale(), e = new n({
                fill: this.getFill() ? this.getFill().clone() : void 0,
                stroke: this.getStroke() ? this.getStroke().clone() : void 0,
                radius: this.getRadius(),
                scale: Array.isArray(t) ? t.slice() : t,
                rotation: this.getRotation(),
                rotateWithView: this.getRotateWithView(),
                displacement: this.getDisplacement().slice(),
                declutterMode: this.getDeclutterMode()
            });
            return e.setOpacity(this.getOpacity()), e
        }

        setRadius(t) {
            this.radius_ = t, this.render()
        }
    }, ts = Ch
});
var Nf = {};
Fi(Nf, {createDefaultStyle: () => Rh, createEditingStyle: () => $m, default: () => ei, toFunction: () => vh});

function vh(n) {
    let t;
    if (typeof n == "function") t = n; else {
        let e;
        Array.isArray(n) ? e = n : (z(typeof n.getZIndex == "function", "Expected an `Style` or an array of `Style`"), e = [n]), t = function () {
            return e
        }
    }
    return t
}

function Rh(n, t) {
    if (!Th) {
        let e = new tn({color: "rgba(255,255,255,0.4)"}), i = new Rn({color: "#3399CC", width: 1.25});
        Th = [new en({image: new ts({fill: e, stroke: i, radius: 5}), fill: e, stroke: i})]
    }
    return Th
}

function $m() {
    let n = {}, t = [255, 255, 255, 1], e = [0, 153, 255, 1], i = 3;
    return n.Polygon = [new en({fill: new tn({color: [255, 255, 255, .5]})})], n.MultiPolygon = n.Polygon, n.LineString = [new en({
        stroke: new Rn({
            color: t,
            width: i + 2
        })
    }), new en({
        stroke: new Rn({
            color: e,
            width: i
        })
    })], n.MultiLineString = n.LineString, n.Circle = n.Polygon.concat(n.LineString), n.Point = [new en({
        image: new ts({
            radius: i * 2,
            fill: new tn({color: e}),
            stroke: new Rn({color: t, width: i / 2})
        }), zIndex: 1 / 0
    })], n.MultiPoint = n.Point, n.GeometryCollection = n.Polygon.concat(n.LineString, n.Point), n
}

function kf(n) {
    return n.getGeometry()
}

var en, Th, ei, es = v(() => {
    wh();
    Io();
    ph();
    Zt();
    en = class n {
        constructor(t) {
            t = t || {}, this.geometry_ = null, this.geometryFunction_ = kf, t.geometry !== void 0 && this.setGeometry(t.geometry), this.fill_ = t.fill !== void 0 ? t.fill : null, this.image_ = t.image !== void 0 ? t.image : null, this.renderer_ = t.renderer !== void 0 ? t.renderer : null, this.hitDetectionRenderer_ = t.hitDetectionRenderer !== void 0 ? t.hitDetectionRenderer : null, this.stroke_ = t.stroke !== void 0 ? t.stroke : null, this.text_ = t.text !== void 0 ? t.text : null, this.zIndex_ = t.zIndex
        }

        clone() {
            let t = this.getGeometry();
            return t && typeof t == "object" && (t = t.clone()), new n({
                geometry: t ?? void 0,
                fill: this.getFill() ? this.getFill().clone() : void 0,
                image: this.getImage() ? this.getImage().clone() : void 0,
                renderer: this.getRenderer() ?? void 0,
                stroke: this.getStroke() ? this.getStroke().clone() : void 0,
                text: this.getText() ? this.getText().clone() : void 0,
                zIndex: this.getZIndex()
            })
        }

        getRenderer() {
            return this.renderer_
        }

        setRenderer(t) {
            this.renderer_ = t
        }

        setHitDetectionRenderer(t) {
            this.hitDetectionRenderer_ = t
        }

        getHitDetectionRenderer() {
            return this.hitDetectionRenderer_
        }

        getGeometry() {
            return this.geometry_
        }

        getGeometryFunction() {
            return this.geometryFunction_
        }

        getFill() {
            return this.fill_
        }

        setFill(t) {
            this.fill_ = t
        }

        getImage() {
            return this.image_
        }

        setImage(t) {
            this.image_ = t
        }

        getStroke() {
            return this.stroke_
        }

        setStroke(t) {
            this.stroke_ = t
        }

        getText() {
            return this.text_
        }

        setText(t) {
            this.text_ = t
        }

        getZIndex() {
            return this.zIndex_
        }

        setGeometry(t) {
            typeof t == "function" ? this.geometryFunction_ = t : typeof t == "string" ? this.geometryFunction_ = function (e) {
                return e.get(t)
            } : t ? t !== void 0 && (this.geometryFunction_ = function () {
                return t
            }) : this.geometryFunction_ = kf, this.geometry_ = t
        }

        setZIndex(t) {
            this.zIndex_ = t
        }
    };
    Th = null;
    ei = en
});
var Jm, Sh, Gf, Xf = v(() => {
    Io();
    Ri();
    Jm = "#333", Sh = class n {
        constructor(t) {
            t = t || {}, this.font_ = t.font, this.rotation_ = t.rotation, this.rotateWithView_ = t.rotateWithView, this.scale_ = t.scale, this.scaleArray_ = bt(t.scale !== void 0 ? t.scale : 1), this.text_ = t.text, this.textAlign_ = t.textAlign, this.justify_ = t.justify, this.repeat_ = t.repeat, this.textBaseline_ = t.textBaseline, this.fill_ = t.fill !== void 0 ? t.fill : new tn({color: Jm}), this.maxAngle_ = t.maxAngle !== void 0 ? t.maxAngle : Math.PI / 4, this.placement_ = t.placement !== void 0 ? t.placement : "point", this.overflow_ = !!t.overflow, this.stroke_ = t.stroke !== void 0 ? t.stroke : null, this.offsetX_ = t.offsetX !== void 0 ? t.offsetX : 0, this.offsetY_ = t.offsetY !== void 0 ? t.offsetY : 0, this.backgroundFill_ = t.backgroundFill ? t.backgroundFill : null, this.backgroundStroke_ = t.backgroundStroke ? t.backgroundStroke : null, this.padding_ = t.padding === void 0 ? null : t.padding
        }

        clone() {
            let t = this.getScale();
            return new n({
                font: this.getFont(),
                placement: this.getPlacement(),
                repeat: this.getRepeat(),
                maxAngle: this.getMaxAngle(),
                overflow: this.getOverflow(),
                rotation: this.getRotation(),
                rotateWithView: this.getRotateWithView(),
                scale: Array.isArray(t) ? t.slice() : t,
                text: this.getText(),
                textAlign: this.getTextAlign(),
                justify: this.getJustify(),
                textBaseline: this.getTextBaseline(),
                fill: this.getFill() ? this.getFill().clone() : void 0,
                stroke: this.getStroke() ? this.getStroke().clone() : void 0,
                offsetX: this.getOffsetX(),
                offsetY: this.getOffsetY(),
                backgroundFill: this.getBackgroundFill() ? this.getBackgroundFill().clone() : void 0,
                backgroundStroke: this.getBackgroundStroke() ? this.getBackgroundStroke().clone() : void 0,
                padding: this.getPadding() || void 0
            })
        }

        getOverflow() {
            return this.overflow_
        }

        getFont() {
            return this.font_
        }

        getMaxAngle() {
            return this.maxAngle_
        }

        getPlacement() {
            return this.placement_
        }

        getRepeat() {
            return this.repeat_
        }

        getOffsetX() {
            return this.offsetX_
        }

        getOffsetY() {
            return this.offsetY_
        }

        getFill() {
            return this.fill_
        }

        getRotateWithView() {
            return this.rotateWithView_
        }

        getRotation() {
            return this.rotation_
        }

        getScale() {
            return this.scale_
        }

        getScaleArray() {
            return this.scaleArray_
        }

        getStroke() {
            return this.stroke_
        }

        getText() {
            return this.text_
        }

        getTextAlign() {
            return this.textAlign_
        }

        getJustify() {
            return this.justify_
        }

        getTextBaseline() {
            return this.textBaseline_
        }

        getBackgroundFill() {
            return this.backgroundFill_
        }

        getBackgroundStroke() {
            return this.backgroundStroke_
        }

        getPadding() {
            return this.padding_
        }

        setOverflow(t) {
            this.overflow_ = t
        }

        setFont(t) {
            this.font_ = t
        }

        setMaxAngle(t) {
            this.maxAngle_ = t
        }

        setOffsetX(t) {
            this.offsetX_ = t
        }

        setOffsetY(t) {
            this.offsetY_ = t
        }

        setPlacement(t) {
            this.placement_ = t
        }

        setRepeat(t) {
            this.repeat_ = t
        }

        setRotateWithView(t) {
            this.rotateWithView_ = t
        }

        setFill(t) {
            this.fill_ = t
        }

        setRotation(t) {
            this.rotation_ = t
        }

        setScale(t) {
            this.scale_ = t, this.scaleArray_ = bt(t !== void 0 ? t : 1)
        }

        setStroke(t) {
            this.stroke_ = t
        }

        setText(t) {
            this.text_ = t
        }

        setTextAlign(t) {
            this.textAlign_ = t
        }

        setJustify(t) {
            this.justify_ = t
        }

        setTextBaseline(t) {
            this.textBaseline_ = t
        }

        setBackgroundFill(t) {
            this.backgroundFill_ = t
        }

        setBackgroundStroke(t) {
            this.backgroundStroke_ = t
        }

        setPadding(t) {
            this.padding_ = t
        }
    }, Gf = Sh
});

function Ih(n, t, e, i, r) {
    Wf(n, t, e || 0, i || n.length - 1, r || Qm)
}

function Wf(n, t, e, i, r) {
    for (; i > e;) {
        if (i - e > 600) {
            var s = i - e + 1, o = t - e + 1, a = Math.log(s), l = .5 * Math.exp(2 * a / 3),
                h = .5 * Math.sqrt(a * l * (s - l) / s) * (o - s / 2 < 0 ? -1 : 1),
                c = Math.max(e, Math.floor(t - o * l / s + h)), u = Math.min(i, Math.floor(t + (s - o) * l / s + h));
            Wf(n, t, c, u, r)
        }
        var d = n[t], f = e, g = i;
        for (is(n, e, t), r(n[i], d) > 0 && is(n, e, i); f < g;) {
            for (is(n, f, g), f++, g--; r(n[f], d) < 0;) f++;
            for (; r(n[g], d) > 0;) g--
        }
        r(n[e], d) === 0 ? is(n, e, g) : (g++, is(n, g, i)), g <= t && (e = g + 1), t <= g && (i = g - 1)
    }
}

function is(n, t, e) {
    var i = n[t];
    n[t] = n[e], n[e] = i
}

function Qm(n, t) {
    return n < t ? -1 : n > t ? 1 : 0
}

var zf = v(() => {
});

function tp(n, t, e) {
    if (!e) return t.indexOf(n);
    for (let i = 0; i < t.length; i++) if (e(n, t[i])) return i;
    return -1
}

function yr(n, t) {
    ns(n, 0, n.children.length, t, n)
}

function ns(n, t, e, i, r) {
    r || (r = xr(null)), r.minX = 1 / 0, r.minY = 1 / 0, r.maxX = -1 / 0, r.maxY = -1 / 0;
    for (let s = t; s < e; s++) {
        let o = n.children[s];
        rs(r, n.leaf ? i(o) : o)
    }
    return r
}

function rs(n, t) {
    return n.minX = Math.min(n.minX, t.minX), n.minY = Math.min(n.minY, t.minY), n.maxX = Math.max(n.maxX, t.maxX), n.maxY = Math.max(n.maxY, t.maxY), n
}

function ep(n, t) {
    return n.minX - t.minX
}

function ip(n, t) {
    return n.minY - t.minY
}

function Lh(n) {
    return (n.maxX - n.minX) * (n.maxY - n.minY)
}

function Ao(n) {
    return n.maxX - n.minX + (n.maxY - n.minY)
}

function np(n, t) {
    return (Math.max(t.maxX, n.maxX) - Math.min(t.minX, n.minX)) * (Math.max(t.maxY, n.maxY) - Math.min(t.minY, n.minY))
}

function rp(n, t) {
    let e = Math.max(n.minX, t.minX), i = Math.max(n.minY, t.minY), r = Math.min(n.maxX, t.maxX),
        s = Math.min(n.maxY, t.maxY);
    return Math.max(0, r - e) * Math.max(0, s - i)
}

function bh(n, t) {
    return n.minX <= t.minX && n.minY <= t.minY && t.maxX <= n.maxX && t.maxY <= n.maxY
}

function Mo(n, t) {
    return t.minX <= n.maxX && t.minY <= n.maxY && t.maxX >= n.minX && t.maxY >= n.minY
}

function xr(n) {
    return {children: n, height: 1, leaf: !0, minX: 1 / 0, minY: 1 / 0, maxX: -1 / 0, maxY: -1 / 0}
}

function Yf(n, t, e, i, r) {
    let s = [t, e];
    for (; s.length;) {
        if (e = s.pop(), t = s.pop(), e - t <= i) continue;
        let o = t + Math.ceil((e - t) / i / 2) * i;
        Ih(n, o, t, e, r), s.push(t, o, o, e)
    }
}

var Sn, Ah = v(() => {
    zf();
    Sn = class {
        constructor(t = 9) {
            this._maxEntries = Math.max(4, t), this._minEntries = Math.max(2, Math.ceil(this._maxEntries * .4)), this.clear()
        }

        all() {
            return this._all(this.data, [])
        }

        search(t) {
            let e = this.data, i = [];
            if (!Mo(t, e)) return i;
            let r = this.toBBox, s = [];
            for (; e;) {
                for (let o = 0; o < e.children.length; o++) {
                    let a = e.children[o], l = e.leaf ? r(a) : a;
                    Mo(t, l) && (e.leaf ? i.push(a) : bh(t, l) ? this._all(a, i) : s.push(a))
                }
                e = s.pop()
            }
            return i
        }

        collides(t) {
            let e = this.data;
            if (!Mo(t, e)) return !1;
            let i = [];
            for (; e;) {
                for (let r = 0; r < e.children.length; r++) {
                    let s = e.children[r], o = e.leaf ? this.toBBox(s) : s;
                    if (Mo(t, o)) {
                        if (e.leaf || bh(t, o)) return !0;
                        i.push(s)
                    }
                }
                e = i.pop()
            }
            return !1
        }

        load(t) {
            if (!(t && t.length)) return this;
            if (t.length < this._minEntries) {
                for (let i = 0; i < t.length; i++) this.insert(t[i]);
                return this
            }
            let e = this._build(t.slice(), 0, t.length - 1, 0);
            if (!this.data.children.length) this.data = e; else if (this.data.height === e.height) this._splitRoot(this.data, e); else {
                if (this.data.height < e.height) {
                    let i = this.data;
                    this.data = e, e = i
                }
                this._insert(e, this.data.height - e.height - 1, !0)
            }
            return this
        }

        insert(t) {
            return t && this._insert(t, this.data.height - 1), this
        }

        clear() {
            return this.data = xr([]), this
        }

        remove(t, e) {
            if (!t) return this;
            let i = this.data, r = this.toBBox(t), s = [], o = [], a, l, h;
            for (; i || s.length;) {
                if (i || (i = s.pop(), l = s[s.length - 1], a = o.pop(), h = !0), i.leaf) {
                    let c = tp(t, i.children, e);
                    if (c !== -1) return i.children.splice(c, 1), s.push(i), this._condense(s), this
                }
                !h && !i.leaf && bh(i, r) ? (s.push(i), o.push(a), a = 0, l = i, i = i.children[0]) : l ? (a++, i = l.children[a], h = !1) : i = null
            }
            return this
        }

        toBBox(t) {
            return t
        }

        compareMinX(t, e) {
            return t.minX - e.minX
        }

        compareMinY(t, e) {
            return t.minY - e.minY
        }

        toJSON() {
            return this.data
        }

        fromJSON(t) {
            return this.data = t, this
        }

        _all(t, e) {
            let i = [];
            for (; t;) t.leaf ? e.push(...t.children) : i.push(...t.children), t = i.pop();
            return e
        }

        _build(t, e, i, r) {
            let s = i - e + 1, o = this._maxEntries, a;
            if (s <= o) return a = xr(t.slice(e, i + 1)), yr(a, this.toBBox), a;
            r || (r = Math.ceil(Math.log(s) / Math.log(o)), o = Math.ceil(s / Math.pow(o, r - 1))), a = xr([]), a.leaf = !1, a.height = r;
            let l = Math.ceil(s / o), h = l * Math.ceil(Math.sqrt(o));
            Yf(t, e, i, h, this.compareMinX);
            for (let c = e; c <= i; c += h) {
                let u = Math.min(c + h - 1, i);
                Yf(t, c, u, l, this.compareMinY);
                for (let d = c; d <= u; d += l) {
                    let f = Math.min(d + l - 1, u);
                    a.children.push(this._build(t, d, f, r - 1))
                }
            }
            return yr(a, this.toBBox), a
        }

        _chooseSubtree(t, e, i, r) {
            for (; r.push(e), !(e.leaf || r.length - 1 === i);) {
                let s = 1 / 0, o = 1 / 0, a;
                for (let l = 0; l < e.children.length; l++) {
                    let h = e.children[l], c = Lh(h), u = np(t, h) - c;
                    u < o ? (o = u, s = c < s ? c : s, a = h) : u === o && c < s && (s = c, a = h)
                }
                e = a || e.children[0]
            }
            return e
        }

        _insert(t, e, i) {
            let r = i ? t : this.toBBox(t), s = [], o = this._chooseSubtree(r, this.data, e, s);
            for (o.children.push(t), rs(o, r); e >= 0 && s[e].children.length > this._maxEntries;) this._split(s, e), e--;
            this._adjustParentBBoxes(r, s, e)
        }

        _split(t, e) {
            let i = t[e], r = i.children.length, s = this._minEntries;
            this._chooseSplitAxis(i, s, r);
            let o = this._chooseSplitIndex(i, s, r), a = xr(i.children.splice(o, i.children.length - o));
            a.height = i.height, a.leaf = i.leaf, yr(i, this.toBBox), yr(a, this.toBBox), e ? t[e - 1].children.push(a) : this._splitRoot(i, a)
        }

        _splitRoot(t, e) {
            this.data = xr([t, e]), this.data.height = t.height + 1, this.data.leaf = !1, yr(this.data, this.toBBox)
        }

        _chooseSplitIndex(t, e, i) {
            let r, s = 1 / 0, o = 1 / 0;
            for (let a = e; a <= i - e; a++) {
                let l = ns(t, 0, a, this.toBBox), h = ns(t, a, i, this.toBBox), c = rp(l, h), u = Lh(l) + Lh(h);
                c < s ? (s = c, r = a, o = u < o ? u : o) : c === s && u < o && (o = u, r = a)
            }
            return r || i - e
        }

        _chooseSplitAxis(t, e, i) {
            let r = t.leaf ? this.compareMinX : ep, s = t.leaf ? this.compareMinY : ip,
                o = this._allDistMargin(t, e, i, r), a = this._allDistMargin(t, e, i, s);
            o < a && t.children.sort(r)
        }

        _allDistMargin(t, e, i, r) {
            t.children.sort(r);
            let s = this.toBBox, o = ns(t, 0, e, s), a = ns(t, i - e, i, s), l = Ao(o) + Ao(a);
            for (let h = e; h < i - e; h++) {
                let c = t.children[h];
                rs(o, t.leaf ? s(c) : c), l += Ao(o)
            }
            for (let h = i - e - 1; h >= e; h--) {
                let c = t.children[h];
                rs(a, t.leaf ? s(c) : c), l += Ao(a)
            }
            return l
        }

        _adjustParentBBoxes(t, e, i) {
            for (let r = i; r >= 0; r--) rs(e[r], t)
        }

        _condense(t) {
            for (let e = t.length - 1, i; e >= 0; e--) t[e].children.length === 0 ? e > 0 ? (i = t[e - 1].children, i.splice(i.indexOf(t[e]), 1)) : this.clear() : yr(t[e], this.toBBox)
        }
    }
});

function Uf(n, t, e, i, r) {
    let s = t === void 0 ? void 0 : Hn.get(t, e, r);
    return s || (s = new Mh(n, n instanceof HTMLImageElement ? n.src || void 0 : t, e, i, r), Hn.set(t, e, r, s)), s
}

var ss, Mh, jf = v(() => {
    Lr();
    pt();
    mr();
    mi();
    te();
    Wl();
    oa();
    ss = null, Mh = class extends ki {
        constructor(t, e, i, r, s) {
            super(), this.hitDetectionImage_ = null, this.image_ = t, this.crossOrigin_ = i, this.canvas_ = {}, this.color_ = s, this.imageState_ = r === void 0 ? ht.IDLE : r, this.size_ = t && t.width && t.height ? [t.width, t.height] : null, this.src_ = e, this.tainted_
        }

        initializeImage_() {
            this.image_ = new Image, this.crossOrigin_ !== null && (this.image_.crossOrigin = this.crossOrigin_)
        }

        isTainted_() {
            if (this.tainted_ === void 0 && this.imageState_ === ht.LOADED) {
                ss || (ss = gt(1, 1, void 0, {willReadFrequently: !0})), ss.drawImage(this.image_, 0, 0);
                try {
                    ss.getImageData(0, 0, 1, 1), this.tainted_ = !1
                } catch {
                    ss = null, this.tainted_ = !0
                }
            }
            return this.tainted_ === !0
        }

        dispatchChangeEvent_() {
            this.dispatchEvent(D.CHANGE)
        }

        handleImageError_() {
            this.imageState_ = ht.ERROR, this.dispatchChangeEvent_()
        }

        handleImageLoad_() {
            this.imageState_ = ht.LOADED, this.size_ = [this.image_.width, this.image_.height], this.dispatchChangeEvent_()
        }

        getImage(t) {
            return this.image_ || this.initializeImage_(), this.replaceColor_(t), this.canvas_[t] ? this.canvas_[t] : this.image_
        }

        getPixelRatio(t) {
            return this.replaceColor_(t), this.canvas_[t] ? t : 1
        }

        getImageState() {
            return this.imageState_
        }

        getHitDetectionImage() {
            if (this.image_ || this.initializeImage_(), !this.hitDetectionImage_) if (this.isTainted_()) {
                let t = this.size_[0], e = this.size_[1], i = gt(t, e);
                i.fillRect(0, 0, t, e), this.hitDetectionImage_ = i.canvas
            } else this.hitDetectionImage_ = this.image_;
            return this.hitDetectionImage_
        }

        getSize() {
            return this.size_
        }

        getSrc() {
            return this.src_
        }

        load() {
            if (this.imageState_ === ht.IDLE) {
                this.image_ || this.initializeImage_(), this.imageState_ = ht.LOADING;
                try {
                    this.src_ !== void 0 && (this.image_.src = this.src_)
                } catch {
                    this.handleImageError_()
                }
                this.image_ instanceof HTMLImageElement && rf(this.image_, this.src_).then(t => {
                    this.image_ = t, this.handleImageLoad_()
                }).catch(this.handleImageError_.bind(this))
            }
        }

        replaceColor_(t) {
            if (!this.color_ || this.canvas_[t] || this.imageState_ !== ht.LOADED) return;
            let e = this.image_, i = document.createElement("canvas");
            i.width = Math.ceil(e.width * t), i.height = Math.ceil(e.height * t);
            let r = i.getContext("2d");
            r.scale(t, t), r.drawImage(e, 0, 0), r.globalCompositeOperation = "multiply", r.fillStyle = ks(this.color_), r.fillRect(0, 0, i.width / t, i.height / t), r.globalCompositeOperation = "destination-in", r.drawImage(e, 0, 0), this.canvas_[t] = i
        }
    }
});
var Kf = {};
Fi(Kf, {default: () => nn});

function Bf(n, t, e, i) {
    return e !== void 0 && i !== void 0 ? [e / n, i / t] : e !== void 0 ? e / n : i !== void 0 ? i / t : 1
}

var Ph, nn, Po = v(() => {
    pt();
    mr();
    yh();
    mi();
    Zt();
    jf();
    wt();
    Ph = class n extends Lo {
        constructor(t) {
            t = t || {};
            let e = t.opacity !== void 0 ? t.opacity : 1, i = t.rotation !== void 0 ? t.rotation : 0,
                r = t.scale !== void 0 ? t.scale : 1, s = t.rotateWithView !== void 0 ? t.rotateWithView : !1;
            super({
                opacity: e,
                rotation: i,
                scale: r,
                displacement: t.displacement !== void 0 ? t.displacement : [0, 0],
                rotateWithView: s,
                declutterMode: t.declutterMode
            }), this.anchor_ = t.anchor !== void 0 ? t.anchor : [.5, .5], this.normalizedAnchor_ = null, this.anchorOrigin_ = t.anchorOrigin !== void 0 ? t.anchorOrigin : "top-left", this.anchorXUnits_ = t.anchorXUnits !== void 0 ? t.anchorXUnits : "fraction", this.anchorYUnits_ = t.anchorYUnits !== void 0 ? t.anchorYUnits : "fraction", this.crossOrigin_ = t.crossOrigin !== void 0 ? t.crossOrigin : null;
            let o = t.img !== void 0 ? t.img : null, a = t.src;
            z(!(a !== void 0 && o), "`image` and `src` cannot be provided at the same time"), (a === void 0 || a.length === 0) && o && (a = o.src || K(o)), z(a !== void 0 && a.length > 0, "A defined and non-empty `src` or `image` must be provided"), z(!((t.width !== void 0 || t.height !== void 0) && t.scale !== void 0), "`width` or `height` cannot be provided together with `scale`");
            let l;
            if (t.src !== void 0 ? l = ht.IDLE : o !== void 0 && (o instanceof HTMLImageElement ? o.complete ? l = o.src ? ht.LOADED : ht.IDLE : l = ht.LOADING : l = ht.LOADED), this.color_ = t.color !== void 0 ? dn(t.color) : null, this.iconImage_ = Uf(o, a, this.crossOrigin_, l, this.color_), this.offset_ = t.offset !== void 0 ? t.offset : [0, 0], this.offsetOrigin_ = t.offsetOrigin !== void 0 ? t.offsetOrigin : "top-left", this.origin_ = null, this.size_ = t.size !== void 0 ? t.size : null, t.width !== void 0 || t.height !== void 0) {
                let h, c;
                if (t.size) [h, c] = t.size; else {
                    let u = this.getImage(1);
                    if (u.width && u.height) h = u.width, c = u.height; else if (u instanceof HTMLImageElement) {
                        this.initialOptions_ = t;
                        let d = () => {
                            if (this.unlistenImageChange(d), !this.initialOptions_) return;
                            let f = this.iconImage_.getSize();
                            this.setScale(Bf(f[0], f[1], t.width, t.height))
                        };
                        this.listenImageChange(d);
                        return
                    }
                }
                h !== void 0 && this.setScale(Bf(h, c, t.width, t.height))
            }
        }

        clone() {
            let t, e, i;
            return this.initialOptions_ ? (e = this.initialOptions_.width, i = this.initialOptions_.height) : (t = this.getScale(), t = Array.isArray(t) ? t.slice() : t), new n({
                anchor: this.anchor_.slice(),
                anchorOrigin: this.anchorOrigin_,
                anchorXUnits: this.anchorXUnits_,
                anchorYUnits: this.anchorYUnits_,
                color: this.color_ && this.color_.slice ? this.color_.slice() : this.color_ || void 0,
                crossOrigin: this.crossOrigin_,
                offset: this.offset_.slice(),
                offsetOrigin: this.offsetOrigin_,
                opacity: this.getOpacity(),
                rotateWithView: this.getRotateWithView(),
                rotation: this.getRotation(),
                scale: t,
                width: e,
                height: i,
                size: this.size_ !== null ? this.size_.slice() : void 0,
                src: this.getSrc(),
                displacement: this.getDisplacement().slice(),
                declutterMode: this.getDeclutterMode()
            })
        }

        getAnchor() {
            let t = this.normalizedAnchor_;
            if (!t) {
                t = this.anchor_;
                let r = this.getSize();
                if (this.anchorXUnits_ == "fraction" || this.anchorYUnits_ == "fraction") {
                    if (!r) return null;
                    t = this.anchor_.slice(), this.anchorXUnits_ == "fraction" && (t[0] *= r[0]), this.anchorYUnits_ == "fraction" && (t[1] *= r[1])
                }
                if (this.anchorOrigin_ != "top-left") {
                    if (!r) return null;
                    t === this.anchor_ && (t = this.anchor_.slice()), (this.anchorOrigin_ == "top-right" || this.anchorOrigin_ == "bottom-right") && (t[0] = -t[0] + r[0]), (this.anchorOrigin_ == "bottom-left" || this.anchorOrigin_ == "bottom-right") && (t[1] = -t[1] + r[1])
                }
                this.normalizedAnchor_ = t
            }
            let e = this.getDisplacement(), i = this.getScaleArray();
            return [t[0] - e[0] / i[0], t[1] + e[1] / i[1]]
        }

        setAnchor(t) {
            this.anchor_ = t, this.normalizedAnchor_ = null
        }

        getColor() {
            return this.color_
        }

        getImage(t) {
            return this.iconImage_.getImage(t)
        }

        getPixelRatio(t) {
            return this.iconImage_.getPixelRatio(t)
        }

        getImageSize() {
            return this.iconImage_.getSize()
        }

        getImageState() {
            return this.iconImage_.getImageState()
        }

        getHitDetectionImage() {
            return this.iconImage_.getHitDetectionImage()
        }

        getOrigin() {
            if (this.origin_) return this.origin_;
            let t = this.offset_;
            if (this.offsetOrigin_ != "top-left") {
                let e = this.getSize(), i = this.iconImage_.getSize();
                if (!e || !i) return null;
                t = t.slice(), (this.offsetOrigin_ == "top-right" || this.offsetOrigin_ == "bottom-right") && (t[0] = i[0] - e[0] - t[0]), (this.offsetOrigin_ == "bottom-left" || this.offsetOrigin_ == "bottom-right") && (t[1] = i[1] - e[1] - t[1])
            }
            return this.origin_ = t, this.origin_
        }

        getSrc() {
            return this.iconImage_.getSrc()
        }

        getSize() {
            return this.size_ ? this.size_ : this.iconImage_.getSize()
        }

        getWidth() {
            let t = this.getScaleArray();
            if (this.size_) return this.size_[0] * t[0];
            if (this.iconImage_.getImageState() == ht.LOADED) return this.iconImage_.getSize()[0] * t[0]
        }

        getHeight() {
            let t = this.getScaleArray();
            if (this.size_) return this.size_[1] * t[1];
            if (this.iconImage_.getImageState() == ht.LOADED) return this.iconImage_.getSize()[1] * t[1]
        }

        setScale(t) {
            delete this.initialOptions_, super.setScale(t)
        }

        listenImageChange(t) {
            this.iconImage_.addEventListener(D.CHANGE, t)
        }

        load() {
            this.iconImage_.load()
        }

        unlistenImageChange(t) {
            this.iconImage_.removeEventListener(D.CHANGE, t)
        }
    }, nn = Ph
});

function jt(n) {
    let t = [];
    for (let e of sp) op(n, e) && t.push(Zf[e]);
    return t.length === 0 ? "untyped" : t.length < 3 ? t.join(" or ") : t.slice(0, -1).join(", ") + ", or " + t[t.length - 1]
}

function op(n, t) {
    return (n & t) === t
}

function Xe(n, t) {
    return !!(n & t)
}

function Oo(n, t) {
    return n === t
}

function Fh() {
    return {variables: new Set, properties: new Set, featureId: !1, style: {}}
}

function ap(n) {
    switch (n) {
        case"string":
            return Se;
        case"color":
            return Nt;
        case"number":
            return G;
        case"boolean":
            return Et;
        case"number[]":
            return Si;
        default:
            throw new Error(`Unrecognized type hint: ${n}`)
    }
}

function ut(n, t, e) {
    switch (typeof n) {
        case"boolean":
            return new Ge(Et, n);
        case"number":
            return new Ge(G, n);
        case"string": {
            let r = Se;
            return ru(n) && (r |= Nt), Oo(r & e, Cr) || (r &= e), new Ge(r, n)
        }
        default:
    }
    if (!Array.isArray(n)) throw new Error("Expression must be an array or a primitive value");
    if (n.length === 0) throw new Error("Empty expression");
    if (typeof n[0] == "string") return yp(n, t, e);
    for (let r of n) if (typeof r != "number") throw new Error("Expected an array of numbers");
    let i = Si;
    return (n.length === 3 || n.length === 4) && (i |= Nt), e && (i &= e), new Ge(i, n)
}

function hp(n, t) {
    let e = ut(n[1], t);
    if (!(e instanceof Ge)) throw new Error("Expected a literal argument for get operation");
    if (typeof e.value != "string") throw new Error("Expected a string argument for get operation");
    if (t.properties.add(e.value), n.length === 3) {
        let i = ut(n[2], t);
        return [e, i]
    }
    return [e]
}

function cp(n, t, e, i) {
    let r = n[1];
    if (typeof r != "string") throw new Error("Expected a string argument for var operation");
    if (t.variables.add(r), !("variables" in t.style) || t.style.variables[r] === void 0) return [new Ge(le, r)];
    let s = t.style.variables[r], o = ut(s, t);
    if (o.value = r, i && !Xe(i, o.type)) throw new Error(`The variable ${r} has type ${jt(o.type)} but the following type was expected: ${jt(i)}`);
    return [o]
}

function up(n, t) {
    t.featureId = !0
}

function os(n, t) {
    let e = n[0];
    if (n.length !== 1) throw new Error(`Expected no arguments for ${e} operation`);
    return []
}

function J(n, t) {
    return function (e, i) {
        let r = e[0], s = e.length - 1;
        if (n === t) {
            if (s !== n) {
                let o = n === 1 ? "" : "s";
                throw new Error(`Expected ${n} argument${o} for ${r}, got ${s}`)
            }
        } else if (s < n || s > t) {
            let o = t === 1 / 0 ? `${n} or more` : `${n} to ${t}`;
            throw new Error(`Expected ${o} arguments for ${r}, got ${s}`)
        }
    }
}

function ct(n) {
    return function (t, e) {
        let i = t[0], r = t.length - 1, s = new Array(r);
        for (let o = 0; o < r; ++o) {
            let a = ut(t[o + 1], e);
            if (!Xe(n, a.type)) {
                let l = jt(n), h = jt(a.type);
                throw new Error(`Unexpected type for argument ${o} of ${i} operation, got ${l} but expected ${h}`)
            }
            a.type &= n, s[o] = a
        }
        return s
    }
}

function In(n, t, e) {
    let i = n[0], r = n.length - 1, s = le;
    for (let a = 0; a < e.length; ++a) s &= e[a].type;
    if (s === Cr) throw new Error(`No common type could be found for arguments of ${i} operation`);
    let o = new Array(r);
    for (let a = 0; a < r; ++a) o[a] = ut(n[a + 1], t, s);
    return o
}

function dp(n, t) {
    let e = n[0], i = n.length - 1;
    if (i % 2 === 0) throw new Error(`An odd amount of arguments was expected for operation ${e}, got ${JSON.stringify(i)} instead`)
}

function Vf(n, t) {
    let e = n[0], i = n.length - 1;
    if (i % 2 === 1) throw new Error(`An even amount of arguments was expected for operation ${e}, got ${JSON.stringify(i)} instead`)
}

function fp(n, t, e, i) {
    let r = n.length - 1, o = ut(n[1], t).type, a = ut(n[n.length - 1], t), l = i !== void 0 ? i & a.type : a.type,
        h = new Array(r - 2);
    for (let u = 0; u < r - 2; u += 2) {
        let d = ut(n[u + 2], t), f = ut(n[u + 3], t);
        o &= d.type, l &= f.type, h[u] = d, h[u + 1] = f
    }
    let c = Se | G | Et;
    if (!Xe(c, o)) throw new Error(`Expected an input of type ${jt(c)} for the interpolate operation, got ${jt(o)} instead`);
    if (Oo(l, Cr)) throw new Error("Could not find a common output type for the following match operation: " + JSON.stringify(n));
    for (let u = 0; u < r - 2; u += 2) {
        let d = ut(n[u + 2], t, o), f = ut(n[u + 3], t, l);
        h[u] = d, h[u + 1] = f
    }
    return [ut(n[1], t, o), ...h, ut(n[n.length - 1], t, l)]
}

function gp(n, t, e, i) {
    let r = n[1], s;
    switch (r[0]) {
        case"linear":
            s = 1;
            break;
        case"exponential":
            if (s = r[1], typeof s != "number") throw new Error(`Expected a number base for exponential interpolation, got ${JSON.stringify(s)} instead`);
            break;
        default:
            s = null
    }
    if (!s) throw new Error(`Invalid interpolation type: ${JSON.stringify(r)}`);
    s = ut(s, t);
    let o = ut(n[2], t);
    if (!Xe(G, o.type)) throw new Error(`Expected an input of type number for the interpolate operation, got ${jt(o.type)} instead`);
    o = ut(n[2], t, G);
    let a = new Array(n.length - 3);
    for (let l = 0; l < a.length; l += 2) {
        let h = ut(n[l + 3], t);
        if (!Xe(G, h.type)) throw new Error(`Expected all stop input values in the interpolate operation to be of type number, got ${jt(h.type)} at position ${l + 2} instead`);
        let c = ut(n[l + 4], t);
        if (!Xe(G | Nt, c.type)) throw new Error(`Expected all stop output values in the interpolate operation to be a number or color, got ${jt(c.type)} at position ${l + 3} instead`);
        h = ut(n[l + 3], t, G), c = ut(n[l + 4], t, G | Nt), a[l] = h, a[l + 1] = c
    }
    return [s, o, ...a]
}

function mp(n, t, e, i) {
    let r = ut(n[n.length - 1], t), s = i !== void 0 ? i & r.type : r.type, o = new Array(n.length - 1);
    for (let a = 0; a < o.length - 1; a += 2) {
        let l = ut(n[a + 1], t), h = ut(n[a + 2], t);
        if (!Xe(Et, l.type)) throw new Error(`Expected all conditions in the case operation to be of type boolean, got ${jt(l.type)} at position ${a} instead`);
        s &= h.type, o[a] = l, o[a + 1] = h
    }
    if (Oo(s, Cr)) throw new Error("Could not find a common output type for the following case operation: " + JSON.stringify(n));
    for (let a = 0; a < o.length - 1; a += 2) o[a + 1] = ut(n[a + 2], t, s);
    return o[o.length - 1] = ut(n[n.length - 1], t, s), o
}

function pp(n, t) {
    let e = n[2];
    if (!Array.isArray(e)) throw new Error('The "in" operator was provided a literal value which was not an array as second argument.');
    if (typeof e[0] == "string") {
        if (e[0] !== "literal") throw new Error('For the "in" operator, a string array should be wrapped in a "literal" operator to disambiguate from expressions.');
        if (!Array.isArray(e[1])) throw new Error('The "in" operator was provided a literal value which was not an array as second argument.');
        e = e[1]
    }
    let i = Se | G, r = new Array(e.length);
    for (let o = 0; o < r.length; o++) {
        let a = ut(e[o], t);
        i &= a.type, r[o] = a
    }
    if (Oo(i, Cr)) throw new Error("Could not find a common type for the following in operation: " + JSON.stringify(n));
    return [ut(n[1], t, i), ...r]
}

function _p(n, t) {
    let e = ut(n[1], t, G);
    if (e.type !== G) throw new Error(`The first argument of palette must be an number, got ${jt(e.type)} instead`);
    let i = n[2];
    if (!Array.isArray(i)) throw new Error("The second argument of palette must be an array");
    let r = new Array(i.length);
    for (let s = 0; s < r.length; s++) {
        let o = ut(i[s], t, Nt);
        if (!(o instanceof Ge)) throw new Error(`The palette color at index ${s} must be a literal value`);
        if (!Xe(o.type, Nt)) throw new Error(`The palette color at index ${s} should be of type color, got ${jt(o.type)} instead`);
        r[s] = o
    }
    return [e, ...r]
}

function V(n, ...t) {
    return function (e, i, r) {
        let s = e[0], o = [];
        for (let l = 0; l < t.length; l++) o = t[l](e, i, o, r) || o;
        let a = typeof n == "function" ? n(o) : n;
        if (r !== void 0) {
            if (!Xe(a, r)) throw new Error(`The following expression was expected to return ${jt(r)}, but returns ${jt(a)} instead: ${JSON.stringify(e)}`);
            a &= r
        }
        if (a === Cr) throw new Error(`No matching type was found for the following expression: ${JSON.stringify(e)}`);
        return new Oh(a, s, ...o)
    }
}

function yp(n, t, e) {
    let i = n[0], r = lp[i];
    if (!r) throw new Error(`Unknown operator: ${i}`);
    return r(n, t, e)
}

var Er, Cr, Et, G, Se, Nt, Si, le, Zf, sp, Ge, Oh, S, lp, Dh = v(() => {
    Ct();
    mi();
    Er = 0, Cr = 0, Et = 1 << Er++, G = 1 << Er++, Se = 1 << Er++, Nt = 1 << Er++, Si = 1 << Er++, le = Math.pow(2, Er) - 1, Zf = {
        [Et]: "boolean",
        [G]: "number",
        [Se]: "string",
        [Nt]: "color",
        [Si]: "number[]"
    }, sp = Object.keys(Zf).map(Number).sort(de);
    Ge = class {
        constructor(t, e) {
            this.type = t, this.value = e
        }
    }, Oh = class {
        constructor(t, e, ...i) {
            this.type = t, this.operator = e, this.args = i
        }
    };
    S = {
        Get: "get",
        Var: "var",
        Concat: "concat",
        GeometryType: "geometry-type",
        Any: "any",
        All: "all",
        Not: "!",
        Resolution: "resolution",
        Zoom: "zoom",
        Time: "time",
        Equal: "==",
        NotEqual: "!=",
        GreaterThan: ">",
        GreaterThanOrEqualTo: ">=",
        LessThan: "<",
        LessThanOrEqualTo: "<=",
        Multiply: "*",
        Divide: "/",
        Add: "+",
        Subtract: "-",
        Clamp: "clamp",
        Mod: "%",
        Pow: "^",
        Abs: "abs",
        Floor: "floor",
        Ceil: "ceil",
        Round: "round",
        Sin: "sin",
        Cos: "cos",
        Atan: "atan",
        Sqrt: "sqrt",
        Match: "match",
        Between: "between",
        Interpolate: "interpolate",
        Case: "case",
        In: "in",
        Number: "number",
        String: "string",
        Array: "array",
        Color: "color",
        Id: "id",
        Band: "band",
        Palette: "palette"
    }, lp = {
        [S.Get]: V(([n, t]) => t !== void 0 ? ap(t.value) : le, J(1, 2), hp),
        [S.Var]: V(([n]) => n.type, J(1, 1), cp),
        [S.Id]: V(G | Se, os, up),
        [S.Concat]: V(Se, J(2, 1 / 0), ct(le)),
        [S.GeometryType]: V(Se, os),
        [S.Resolution]: V(G, os),
        [S.Zoom]: V(G, os),
        [S.Time]: V(G, os),
        [S.Any]: V(Et, J(2, 1 / 0), ct(Et)),
        [S.All]: V(Et, J(2, 1 / 0), ct(Et)),
        [S.Not]: V(Et, J(1, 1), ct(Et)),
        [S.Equal]: V(Et, J(2, 2), ct(le), In),
        [S.NotEqual]: V(Et, J(2, 2), ct(le), In),
        [S.GreaterThan]: V(Et, J(2, 2), ct(le), In),
        [S.GreaterThanOrEqualTo]: V(Et, J(2, 2), ct(le), In),
        [S.LessThan]: V(Et, J(2, 2), ct(le), In),
        [S.LessThanOrEqualTo]: V(Et, J(2, 2), ct(le), In),
        [S.Multiply]: V(n => {
            let t = G | Nt;
            for (let e = 0; e < n.length; e++) t &= n[e].type;
            return t
        }, J(2, 1 / 0), ct(G | Nt), In),
        [S.Divide]: V(G, J(2, 2), ct(G)),
        [S.Add]: V(G, J(2, 1 / 0), ct(G)),
        [S.Subtract]: V(G, J(2, 2), ct(G)),
        [S.Clamp]: V(G, J(3, 3), ct(G)),
        [S.Mod]: V(G, J(2, 2), ct(G)),
        [S.Pow]: V(G, J(2, 2), ct(G)),
        [S.Abs]: V(G, J(1, 1), ct(G)),
        [S.Floor]: V(G, J(1, 1), ct(G)),
        [S.Ceil]: V(G, J(1, 1), ct(G)),
        [S.Round]: V(G, J(1, 1), ct(G)),
        [S.Sin]: V(G, J(1, 1), ct(G)),
        [S.Cos]: V(G, J(1, 1), ct(G)),
        [S.Atan]: V(G, J(1, 2), ct(G)),
        [S.Sqrt]: V(G, J(1, 1), ct(G)),
        [S.Match]: V(n => {
            let t = le;
            for (let e = 2; e < n.length; e += 2) t &= n[e].type;
            return t &= n[n.length - 1].type, t
        }, J(4, 1 / 0), Vf, fp),
        [S.Between]: V(Et, J(3, 3), ct(G)),
        [S.Interpolate]: V(n => {
            let t = Nt | G;
            for (let e = 3; e < n.length; e += 2) t &= n[e].type;
            return t
        }, J(6, 1 / 0), Vf, gp),
        [S.Case]: V(n => {
            let t = le;
            for (let e = 1; e < n.length; e += 2) t &= n[e].type;
            return t &= n[n.length - 1].type, t
        }, J(3, 1 / 0), dp, mp),
        [S.In]: V(Et, J(2, 2), pp),
        [S.Number]: V(G, J(1, 1 / 0), ct(le)),
        [S.String]: V(Se, J(1, 1 / 0), ct(le)),
        [S.Array]: V(n => n.length === 3 || n.length === 4 ? Si | Nt : Si, J(1, 1 / 0), ct(G)),
        [S.Color]: V(Nt, J(3, 4), ct(G)),
        [S.Band]: V(G, J(1, 3), ct(G)),
        [S.Palette]: V(Nt, J(2, 2), _p)
    }
});

function kh() {
    return {variables: {}, properties: {}, resolution: NaN, featureId: null}
}

function Li(n, t, e) {
    let i = ut(n, e);
    if (!Xe(t, i.type)) {
        let r = jt(t), s = jt(i.type);
        throw new Error(`Expected expression to be of type ${r}, got ${s}`)
    }
    return Ii(i, e)
}

function Ii(n, t) {
    if (n instanceof Ge) {
        if (n.type === Nt && typeof n.value == "string") {
            let i = Ns(n.value);
            return function () {
                return i
            }
        }
        return function () {
            return n.value
        }
    }
    let e = n.operator;
    switch (e) {
        case S.Number:
        case S.String:
            return xp(n, t);
        case S.Get:
        case S.Var:
            return Ep(n, t);
        case S.Id:
            return i => i.featureId;
        case S.Concat: {
            let i = n.args.map(r => Ii(r, t));
            return r => "".concat(...i.map(s => s(r).toString()))
        }
        case S.Resolution:
            return i => i.resolution;
        case S.Any:
        case S.All:
        case S.Not:
            return wp(n, t);
        case S.Equal:
        case S.NotEqual:
        case S.LessThan:
        case S.LessThanOrEqualTo:
        case S.GreaterThan:
        case S.GreaterThanOrEqualTo:
            return Cp(n, t);
        case S.Multiply:
        case S.Divide:
        case S.Add:
        case S.Subtract:
        case S.Clamp:
        case S.Mod:
        case S.Pow:
        case S.Abs:
        case S.Floor:
        case S.Ceil:
        case S.Round:
        case S.Sin:
        case S.Cos:
        case S.Atan:
        case S.Sqrt:
            return Tp(n, t);
        case S.Match:
            return vp(n, t);
        case S.Interpolate:
            return Rp(n, t);
        default:
            throw new Error(`Unsupported operator ${e}`)
    }
}

function xp(n, t) {
    let e = n.operator, i = n.args.length, r = new Array(i);
    for (let s = 0; s < i; ++s) r[s] = Ii(n.args[s], t);
    switch (e) {
        case S.Number:
        case S.String:
            return s => {
                for (let o = 0; o < i; ++o) {
                    let a = r[o](s);
                    if (typeof a === e) return a
                }
                throw new Error(`Expected one of the values to be a ${e}`)
            };
        default:
            throw new Error(`Unsupported assertion operator ${e}`)
    }
}

function Ep(n, t) {
    let i = n.args[0].value;
    switch (n.operator) {
        case S.Get:
            return r => r.properties[i];
        case S.Var:
            return r => r.variables[i];
        default:
            throw new Error(`Unsupported accessor operator ${n.operator}`)
    }
}

function Cp(n, t) {
    let e = n.operator, i = Ii(n.args[0], t), r = Ii(n.args[1], t);
    switch (e) {
        case S.Equal:
            return s => i(s) === r(s);
        case S.NotEqual:
            return s => i(s) !== r(s);
        case S.LessThan:
            return s => i(s) < r(s);
        case S.LessThanOrEqualTo:
            return s => i(s) <= r(s);
        case S.GreaterThan:
            return s => i(s) > r(s);
        case S.GreaterThanOrEqualTo:
            return s => i(s) >= r(s);
        default:
            throw new Error(`Unsupported comparison operator ${e}`)
    }
}

function wp(n, t) {
    let e = n.operator, i = n.args.length, r = new Array(i);
    for (let s = 0; s < i; ++s) r[s] = Ii(n.args[s], t);
    switch (e) {
        case S.Any:
            return s => {
                for (let o = 0; o < i; ++o) if (r[o](s)) return !0;
                return !1
            };
        case S.All:
            return s => {
                for (let o = 0; o < i; ++o) if (!r[o](s)) return !1;
                return !0
            };
        case S.Not:
            return s => !r[0](s);
        default:
            throw new Error(`Unsupported logical operator ${e}`)
    }
}

function Tp(n, t) {
    let e = n.operator, i = n.args.length, r = new Array(i);
    for (let s = 0; s < i; ++s) r[s] = Ii(n.args[s], t);
    switch (e) {
        case S.Multiply:
            return s => {
                let o = 1;
                for (let a = 0; a < i; ++a) o *= r[a](s);
                return o
            };
        case S.Divide:
            return s => r[0](s) / r[1](s);
        case S.Add:
            return s => {
                let o = 0;
                for (let a = 0; a < i; ++a) o += r[a](s);
                return o
            };
        case S.Subtract:
            return s => r[0](s) - r[1](s);
        case S.Clamp:
            return s => {
                let o = r[0](s), a = r[1](s);
                if (o < a) return a;
                let l = r[2](s);
                return o > l ? l : o
            };
        case S.Mod:
            return s => r[0](s) % r[1](s);
        case S.Pow:
            return s => Math.pow(r[0](s), r[1](s));
        case S.Abs:
            return s => Math.abs(r[0](s));
        case S.Floor:
            return s => Math.floor(r[0](s));
        case S.Ceil:
            return s => Math.ceil(r[0](s));
        case S.Round:
            return s => Math.round(r[0](s));
        case S.Sin:
            return s => Math.sin(r[0](s));
        case S.Cos:
            return s => Math.cos(r[0](s));
        case S.Atan:
            return i === 2 ? s => Math.atan2(r[0](s), r[1](s)) : s => Math.atan(r[0](s));
        case S.Sqrt:
            return s => Math.sqrt(r[0](s));
        default:
            throw new Error(`Unsupported numeric operator ${e}`)
    }
}

function vp(n, t) {
    let e = n.args.length, i = new Array(e);
    for (let r = 0; r < e; ++r) i[r] = Ii(n.args[r], t);
    return r => {
        let s = i[0](r);
        for (let o = 1; o < e; o += 2) if (s === i[o](r)) return i[o + 1](r);
        return i[e - 1](r)
    }
}

function Rp(n, t) {
    let e = n.args.length, i = new Array(e);
    for (let r = 0; r < e; ++r) i[r] = Ii(n.args[r], t);
    return r => {
        let s = i[0](r), o = i[1](r), a, l;
        for (let h = 2; h < e; h += 2) {
            let c = i[h](r), u = i[h + 1](r), d = Array.isArray(u);
            if (d && (u = iu(u)), c >= o) return h === 2 ? u : d ? Sp(s, o, a, l, c, u) : as(s, o, a, l, c, u);
            a = c, l = u
        }
        return l
    }
}

function as(n, t, e, i, r, s) {
    let o = r - e;
    if (o === 0) return i;
    let a = t - e, l = n === 1 ? a / o : (Math.pow(n, a) - 1) / (Math.pow(n, o) - 1);
    return i + l * (s - i)
}

function Sp(n, t, e, i, r, s) {
    if (r - e === 0) return i;
    let a = ia(i), l = ia(s), h = l[2] - a[2];
    h > 180 ? h -= 360 : h < -180 && (h += 360);
    let c = [as(n, t, e, a[0], r, l[0]), as(n, t, e, a[1], r, l[1]), a[2] + as(n, t, e, 0, r, h), as(n, t, e, i[3], r, s[3])];
    return na(nu(c))
}

var qf = v(() => {
    Dh();
    mi()
});

function Ip(n) {
    return !0
}

function Jf(n) {
    let t = Fh(), e = Lp(n, t), i = kh();
    return function (r, s) {
        if (i.properties = r.getPropertiesInternal(), i.resolution = s, t.featureId) {
            let o = r.getId();
            o !== void 0 ? i.featureId = o : i.featureId = null
        }
        return e(i)
    }
}

function Gh(n) {
    let t = Fh(), e = n.length, i = new Array(e);
    for (let o = 0; o < e; ++o) i[o] = Nh(n[o], t);
    let r = kh(), s = new Array(e);
    return function (o, a) {
        if (r.properties = o.getPropertiesInternal(), r.resolution = a, t.featureId) {
            let h = o.getId();
            h !== void 0 ? r.featureId = h : r.featureId = null
        }
        let l = 0;
        for (let h = 0; h < e; ++h) {
            let c = i[h](r);
            c && (s[l] = c, l += 1)
        }
        return s.length = l, s
    }
}

function Lp(n, t) {
    let e = n.length, i = new Array(e);
    for (let r = 0; r < e; ++r) {
        let s = n[r], o = "filter" in s ? Li(s.filter, Et, t) : Ip, a;
        if (Array.isArray(s.style)) {
            let l = s.style.length;
            a = new Array(l);
            for (let h = 0; h < l; ++h) a[h] = Nh(s.style[h], t)
        } else a = [Nh(s.style, t)];
        i[r] = {filter: o, styles: a}
    }
    return function (r) {
        let s = [], o = !1;
        for (let a = 0; a < e; ++a) {
            let l = i[a].filter;
            if (l(r) && !(n[a].else && o)) {
                o = !0;
                for (let h of i[a].styles) {
                    let c = h(r);
                    c && s.push(c)
                }
            }
        }
        return s
    }
}

function Nh(n, t) {
    let e = ls(n, "", t), i = hs(n, "", t), r = bp(n, t), s = Ap(n, t), o = he(n, "z-index", t);
    if (!e && !i && !r && !s && !Pe(n)) throw new Error("No fill, stroke, point, or text symbolizer properties in style: " + JSON.stringify(n));
    let a = new ei;
    return function (l) {
        let h = !0;
        if (e) {
            let c = e(l);
            c && (h = !1), a.setFill(c)
        }
        if (i) {
            let c = i(l);
            c && (h = !1), a.setStroke(c)
        }
        if (r) {
            let c = r(l);
            c && (h = !1), a.setText(c)
        }
        if (s) {
            let c = s(l);
            c && (h = !1), a.setImage(c)
        }
        return o && a.setZIndex(o(l)), h ? null : a
    }
}

function ls(n, t, e) {
    let i = Qf(n, t + "fill-color", e);
    if (!i) return null;
    let r = new tn;
    return function (s) {
        let o = i(s);
        return o === "none" ? null : (r.setColor(o), r)
    }
}

function hs(n, t, e) {
    let i = he(n, t + "stroke-width", e), r = Qf(n, t + "stroke-color", e);
    if (!i && !r) return null;
    let s = rn(n, t + "stroke-line-cap", e), o = rn(n, t + "stroke-line-join", e), a = tg(n, t + "stroke-line-dash", e),
        l = he(n, t + "stroke-line-dash-offset", e), h = he(n, t + "stroke-miter-limit", e), c = new Rn;
    return function (u) {
        if (r) {
            let d = r(u);
            if (d === "none") return null;
            c.setColor(d)
        }
        if (i && c.setWidth(i(u)), s) {
            let d = s(u);
            if (d !== "butt" && d !== "round" && d !== "square") throw new Error("Expected butt, round, or square line cap");
            c.setLineCap(d)
        }
        if (o) {
            let d = o(u);
            if (d !== "bevel" && d !== "round" && d !== "miter") throw new Error("Expected bevel, round, or miter line join");
            c.setLineJoin(d)
        }
        return a && c.setLineDash(a(u)), l && c.setLineDashOffset(l(u)), h && c.setMiterLimit(h(u)), c
    }
}

function bp(n, t) {
    let e = "text-", i = rn(n, e + "value", t);
    if (!i) return null;
    let r = ls(n, e, t), s = ls(n, e + "background-", t), o = hs(n, e, t), a = hs(n, e + "background-", t),
        l = rn(n, e + "font", t), h = he(n, e + "max-angle", t), c = he(n, e + "offset-x", t),
        u = he(n, e + "offset-y", t), d = cs(n, e + "overflow", t), f = rn(n, e + "placement", t),
        g = he(n, e + "repeat", t), m = Do(n, e + "scale", t), p = cs(n, e + "rotate-with-view", t),
        _ = he(n, e + "rotation", t), y = rn(n, e + "align", t), C = rn(n, e + "justify", t),
        w = rn(n, e + "baseline", t), T = tg(n, e + "padding", t), R = new Gf({});
    return function (A) {
        if (R.setText(i(A)), r && R.setFill(r(A)), s && R.setBackgroundFill(s(A)), o && R.setStroke(o(A)), a && R.setBackgroundStroke(a(A)), l && R.setFont(l(A)), h && R.setMaxAngle(h(A)), c && R.setOffsetX(c(A)), u && R.setOffsetY(u(A)), d && R.setOverflow(d(A)), f) {
            let b = f(A);
            if (b !== "point" && b !== "line") throw new Error("Expected point or line for text-placement");
            R.setPlacement(b)
        }
        if (g && R.setRepeat(g(A)), m && R.setScale(m(A)), p && R.setRotateWithView(p(A)), _ && R.setRotation(_(A)), y) {
            let b = y(A);
            if (b !== "left" && b !== "center" && b !== "right" && b !== "end" && b !== "start") throw new Error("Expected left, right, center, start, or end for text-align");
            R.setTextAlign(b)
        }
        if (C) {
            let b = C(A);
            if (b !== "left" && b !== "right" && b !== "center") throw new Error("Expected left, right, or center for text-justify");
            R.setJustify(b)
        }
        if (w) {
            let b = w(A);
            if (b !== "bottom" && b !== "top" && b !== "middle" && b !== "alphabetic" && b !== "hanging") throw new Error("Expected bottom, top, middle, alphabetic, or hanging for text-baseline");
            R.setTextBaseline(b)
        }
        return T && R.setPadding(T(A)), R
    }
}

function Ap(n, t) {
    return "icon-src" in n ? Mp(n, t) : "shape-points" in n ? Pp(n, t) : "circle-radius" in n ? Op(n, t) : null
}

function Mp(n, t) {
    let e = "icon-", i = e + "src", r = eg(n[i], i), s = Fo(n, e + "anchor", t), o = Do(n, e + "scale", t),
        a = he(n, e + "opacity", t), l = Fo(n, e + "displacement", t), h = he(n, e + "rotation", t),
        c = cs(n, e + "rotate-with-view", t), u = Hf(n, e + "anchor-origin"), d = $f(n, e + "anchor-x-units"),
        f = $f(n, e + "anchor-y-units"), g = Np(n, e + "color"), m = Dp(n, e + "cross-origin"), p = kp(n, e + "offset"),
        _ = Hf(n, e + "offset-origin"), y = wr(n, e + "width"), C = wr(n, e + "height"), w = Fp(n, e + "size"),
        T = Xh(n, e + "declutter"), R = new nn({
            src: r,
            anchorOrigin: u,
            anchorXUnits: d,
            anchorYUnits: f,
            color: g,
            crossOrigin: m,
            offset: p,
            offsetOrigin: _,
            height: C,
            width: y,
            size: w,
            declutterMode: T
        });
    return function (A) {
        return a && R.setOpacity(a(A)), l && R.setDisplacement(l(A)), h && R.setRotation(h(A)), c && R.setRotateWithView(c(A)), o && R.setScale(o(A)), s && R.setAnchor(s(A)), R
    }
}

function Pp(n, t) {
    let e = "shape-", i = e + "points", r = ig(n[i], i), s = ls(n, e, t), o = hs(n, e, t), a = Do(n, e + "scale", t),
        l = Fo(n, e + "displacement", t), h = he(n, e + "rotation", t), c = cs(n, e + "rotate-with-view", t),
        u = wr(n, e + "radius"), d = wr(n, e + "radius1"), f = wr(n, e + "radius2"), g = wr(n, e + "angle"),
        m = Xh(n, e + "declutter-mode"),
        p = new bo({points: r, radius: u, radius1: d, radius2: f, angle: g, declutterMode: m});
    return function (_) {
        return s && p.setFill(s(_)), o && p.setStroke(o(_)), l && p.setDisplacement(l(_)), h && p.setRotation(h(_)), c && p.setRotateWithView(c(_)), a && p.setScale(a(_)), p
    }
}

function Op(n, t) {
    let e = "circle-", i = ls(n, e, t), r = hs(n, e, t), s = he(n, e + "radius", t), o = Do(n, e + "scale", t),
        a = Fo(n, e + "displacement", t), l = he(n, e + "rotation", t), h = cs(n, e + "rotate-with-view", t),
        c = Xh(n, e + "declutter-mode"), u = new ts({radius: 5, declutterMode: c});
    return function (d) {
        return s && u.setRadius(s(d)), i && u.setFill(i(d)), r && u.setStroke(r(d)), a && u.setDisplacement(a(d)), l && u.setRotation(l(d)), h && u.setRotateWithView(h(d)), o && u.setScale(o(d)), u
    }
}

function he(n, t, e) {
    if (!(t in n)) return;
    let i = Li(n[t], G, e);
    return function (r) {
        return ig(i(r), t)
    }
}

function rn(n, t, e) {
    if (!(t in n)) return null;
    let i = Li(n[t], Se, e);
    return function (r) {
        return eg(i(r), t)
    }
}

function cs(n, t, e) {
    if (!(t in n)) return null;
    let i = Li(n[t], Et, e);
    return function (r) {
        let s = i(r);
        if (typeof s != "boolean") throw new Error(`Expected a boolean for ${t}`);
        return s
    }
}

function Qf(n, t, e) {
    if (!(t in n)) return null;
    let i = Li(n[t], Nt | Se, e);
    return function (r) {
        return ng(i(r), t)
    }
}

function tg(n, t, e) {
    if (!(t in n)) return null;
    let i = Li(n[t], Si, e);
    return function (r) {
        return us(i(r), t)
    }
}

function Fo(n, t, e) {
    if (!(t in n)) return null;
    let i = Li(n[t], Si, e);
    return function (r) {
        let s = us(i(r), t);
        if (s.length !== 2) throw new Error(`Expected two numbers for ${t}`);
        return s
    }
}

function Do(n, t, e) {
    if (!(t in n)) return null;
    let i = Li(n[t], Si | G, e);
    return function (r) {
        return Gp(i(r), t)
    }
}

function wr(n, t) {
    let e = n[t];
    if (e !== void 0) {
        if (typeof e != "number") throw new Error(`Expected a number for ${t}`);
        return e
    }
}

function Fp(n, t) {
    let e = n[t];
    if (e !== void 0) {
        if (typeof e == "number") return bt(e);
        if (!Array.isArray(e)) throw new Error(`Expected a number or size array for ${t}`);
        if (e.length !== 2 || typeof e[0] != "number" || typeof e[1] != "number") throw new Error(`Expected a number or size array for ${t}`);
        return e
    }
}

function Dp(n, t) {
    let e = n[t];
    if (e !== void 0) {
        if (typeof e != "string") throw new Error(`Expected a string for ${t}`);
        return e
    }
}

function Hf(n, t) {
    let e = n[t];
    if (e !== void 0) {
        if (e !== "bottom-left" && e !== "bottom-right" && e !== "top-left" && e !== "top-right") throw new Error(`Expected bottom-left, bottom-right, top-left, or top-right for ${t}`);
        return e
    }
}

function $f(n, t) {
    let e = n[t];
    if (e !== void 0) {
        if (e !== "pixels" && e !== "fraction") throw new Error(`Expected pixels or fraction for ${t}`);
        return e
    }
}

function kp(n, t) {
    let e = n[t];
    if (e !== void 0) return us(e, t)
}

function Xh(n, t) {
    let e = n[t];
    if (e !== void 0) {
        if (typeof e != "string") throw new Error(`Expected a string for ${t}`);
        if (e !== "declutter" && e !== "obstacle" && e !== "none") throw new Error(`Expected declutter, obstacle, or none for ${t}`);
        return e
    }
}

function Np(n, t) {
    let e = n[t];
    if (e !== void 0) return ng(e, t)
}

function us(n, t) {
    if (!Array.isArray(n)) throw new Error(`Expected an array for ${t}`);
    let e = n.length;
    for (let i = 0; i < e; ++i) if (typeof n[i] != "number") throw new Error(`Expected an array of numbers for ${t}`);
    return n
}

function eg(n, t) {
    if (typeof n != "string") throw new Error(`Expected a string for ${t}`);
    return n
}

function ig(n, t) {
    if (typeof n != "number") throw new Error(`Expected a number for ${t}`);
    return n
}

function ng(n, t) {
    if (typeof n == "string") return n;
    let e = us(n, t), i = e.length;
    if (i < 3 || i > 4) throw new Error(`Expected a color with 3 or 4 values for ${t}`);
    return e
}

function Gp(n, t) {
    if (typeof n == "number") return n;
    let e = us(n, t);
    if (e.length !== 2) throw new Error(`Expected an array of two numbers for ${t}`);
    return e
}

var rg = v(() => {
    wh();
    Io();
    Po();
    Eh();
    ph();
    es();
    Xf();
    Dh();
    qf();
    Oe();
    Ri()
});

function Xp(n) {
    if (n === void 0) return Rh;
    if (!n) return null;
    if (typeof n == "function" || n instanceof ei) return n;
    if (!Array.isArray(n)) return Gh([n]);
    if (n.length === 0) return [];
    let t = n.length, e = n[0];
    if (e instanceof ei) {
        let r = new Array(t);
        for (let s = 0; s < t; ++s) {
            let o = n[s];
            if (!(o instanceof ei)) throw new Error("Expected a list of style instances");
            r[s] = o
        }
        return r
    }
    if ("style" in e) {
        let r = new Array(t);
        for (let s = 0; s < t; ++s) {
            let o = n[s];
            if (!("style" in o)) throw new Error("Expected a list of rules with a style property");
            r[s] = o
        }
        return Jf(r)
    }
    return Gh(n)
}

var sg, Wh, og, ag = v(() => {
    lr();
    Ah();
    es();
    rg();
    sg = {RENDER_ORDER: "renderOrder"}, Wh = class extends xn {
        constructor(t) {
            t = t || {};
            let e = Object.assign({}, t);
            delete e.style, delete e.renderBuffer, delete e.updateWhileAnimating, delete e.updateWhileInteracting, super(e), this.declutter_ = t.declutter !== void 0 ? t.declutter : !1, this.renderBuffer_ = t.renderBuffer !== void 0 ? t.renderBuffer : 100, this.style_ = null, this.styleFunction_ = void 0, this.setStyle(t.style), this.updateWhileAnimating_ = t.updateWhileAnimating !== void 0 ? t.updateWhileAnimating : !1, this.updateWhileInteracting_ = t.updateWhileInteracting !== void 0 ? t.updateWhileInteracting : !1
        }

        getDeclutter() {
            return this.declutter_
        }

        getFeatures(t) {
            return super.getFeatures(t)
        }

        getRenderBuffer() {
            return this.renderBuffer_
        }

        getRenderOrder() {
            return this.get(sg.RENDER_ORDER)
        }

        getStyle() {
            return this.style_
        }

        getStyleFunction() {
            return this.styleFunction_
        }

        getUpdateWhileAnimating() {
            return this.updateWhileAnimating_
        }

        getUpdateWhileInteracting() {
            return this.updateWhileInteracting_
        }

        renderDeclutter(t) {
            t.declutterTree || (t.declutterTree = new Sn(9)), this.getRenderer().renderDeclutter(t)
        }

        setRenderOrder(t) {
            this.set(sg.RENDER_ORDER, t)
        }

        setStyle(t) {
            this.style_ = Xp(t), this.styleFunction_ = t === null ? void 0 : vh(this.style_), this.changed()
        }
    };
    og = Wh
});
var ds, fs, ii, bi, zh, X, Ln = v(() => {
    ds = {
        BEGIN_GEOMETRY: 0,
        BEGIN_PATH: 1,
        CIRCLE: 2,
        CLOSE_PATH: 3,
        CUSTOM: 4,
        DRAW_CHARS: 5,
        DRAW_IMAGE: 6,
        END_GEOMETRY: 7,
        FILL: 8,
        MOVE_TO_LINE_TO: 9,
        SET_FILL_STYLE: 10,
        SET_STROKE_STYLE: 11,
        STROKE: 12
    }, fs = [ds.FILL], ii = [ds.STROKE], bi = [ds.BEGIN_PATH], zh = [ds.CLOSE_PATH], X = ds
});
var Yh, ko, Uh = v(() => {
    Yh = class {
        drawCustom(t, e, i, r) {
        }

        drawGeometry(t) {
        }

        setStyle(t) {
        }

        drawCircle(t, e) {
        }

        drawFeature(t, e) {
        }

        drawGeometryCollection(t, e) {
        }

        drawLineString(t, e) {
        }

        drawMultiLineString(t, e) {
        }

        drawMultiPoint(t, e) {
        }

        drawMultiPolygon(t, e) {
        }

        drawPoint(t, e) {
        }

        drawPolygon(t, e) {
        }

        drawText(t, e) {
        }

        setFillStrokeStyle(t, e) {
        }

        setImageStyle(t, e) {
        }

        setTextStyle(t, e) {
        }
    }, ko = Yh
});
var jh, ni, Tr = v(() => {
    Ln();
    Zo();
    Uh();
    Qr();
    rt();
    Ti();
    Ct();
    $s();
    jh = class extends ko {
        constructor(t, e, i, r) {
            super(), this.tolerance = t, this.maxExtent = e, this.pixelRatio = r, this.maxLineWidth = 0, this.resolution = i, this.beginGeometryInstruction1_ = null, this.beginGeometryInstruction2_ = null, this.bufferedMaxExtent_ = null, this.instructions = [], this.coordinates = [], this.tmpCoordinate_ = [], this.hitDetectionInstructions = [], this.state = {}
        }

        applyPixelRatio(t) {
            let e = this.pixelRatio;
            return e == 1 ? t : t.map(function (i) {
                return i * e
            })
        }

        appendFlatPointCoordinates(t, e) {
            let i = this.getBufferedMaxExtent(), r = this.tmpCoordinate_, s = this.coordinates, o = s.length;
            for (let a = 0, l = t.length; a < l; a += e) r[0] = t[a], r[1] = t[a + 1], Gi(i, r) && (s[o++] = r[0], s[o++] = r[1]);
            return o
        }

        appendFlatLineCoordinates(t, e, i, r, s, o) {
            let a = this.coordinates, l = a.length, h = this.getBufferedMaxExtent();
            o && (e += r);
            let c = t[e], u = t[e + 1], d = this.tmpCoordinate_, f = !0, g, m, p;
            for (g = e + r; g < i; g += r) d[0] = t[g], d[1] = t[g + 1], p = Ss(h, d), p !== m ? (f && (a[l++] = c, a[l++] = u, f = !1), a[l++] = d[0], a[l++] = d[1]) : p === It.INTERSECTING ? (a[l++] = d[0], a[l++] = d[1], f = !1) : f = !0, c = d[0], u = d[1], m = p;
            return (s && f || g === e + r) && (a[l++] = c, a[l++] = u), l
        }

        drawCustomCoordinates_(t, e, i, r, s) {
            for (let o = 0, a = i.length; o < a; ++o) {
                let l = i[o], h = this.appendFlatLineCoordinates(t, e, l, r, !1, !1);
                s.push(h), e = l
            }
            return e
        }

        drawCustom(t, e, i, r) {
            this.beginGeometry(t, e);
            let s = t.getType(), o = t.getStride(), a = this.coordinates.length, l, h, c, u, d;
            switch (s) {
                case"MultiPolygon":
                    l = t.getOrientedFlatCoordinates(), u = [];
                    let f = t.getEndss();
                    d = 0;
                    for (let g = 0, m = f.length; g < m; ++g) {
                        let p = [];
                        d = this.drawCustomCoordinates_(l, d, f[g], o, p), u.push(p)
                    }
                    this.instructions.push([X.CUSTOM, a, u, t, i, Fa]), this.hitDetectionInstructions.push([X.CUSTOM, a, u, t, r || i, Fa]);
                    break;
                case"Polygon":
                case"MultiLineString":
                    c = [], l = s == "Polygon" ? t.getOrientedFlatCoordinates() : t.getFlatCoordinates(), d = this.drawCustomCoordinates_(l, 0, t.getEnds(), o, c), this.instructions.push([X.CUSTOM, a, c, t, i, or]), this.hitDetectionInstructions.push([X.CUSTOM, a, c, t, r || i, or]);
                    break;
                case"LineString":
                case"Circle":
                    l = t.getFlatCoordinates(), h = this.appendFlatLineCoordinates(l, 0, l.length, o, !1, !1), this.instructions.push([X.CUSTOM, a, h, t, i, Ki]), this.hitDetectionInstructions.push([X.CUSTOM, a, h, t, r || i, Ki]);
                    break;
                case"MultiPoint":
                    l = t.getFlatCoordinates(), h = this.appendFlatPointCoordinates(l, o), h > a && (this.instructions.push([X.CUSTOM, a, h, t, i, Ki]), this.hitDetectionInstructions.push([X.CUSTOM, a, h, t, r || i, Ki]));
                    break;
                case"Point":
                    l = t.getFlatCoordinates(), this.coordinates.push(l[0], l[1]), h = this.coordinates.length, this.instructions.push([X.CUSTOM, a, h, t, i]), this.hitDetectionInstructions.push([X.CUSTOM, a, h, t, r || i]);
                    break;
                default:
            }
            this.endGeometry(e)
        }

        beginGeometry(t, e) {
            this.beginGeometryInstruction1_ = [X.BEGIN_GEOMETRY, e, 0, t], this.instructions.push(this.beginGeometryInstruction1_), this.beginGeometryInstruction2_ = [X.BEGIN_GEOMETRY, e, 0, t], this.hitDetectionInstructions.push(this.beginGeometryInstruction2_)
        }

        finish() {
            return {
                instructions: this.instructions,
                hitDetectionInstructions: this.hitDetectionInstructions,
                coordinates: this.coordinates
            }
        }

        reverseHitDetectionInstructions() {
            let t = this.hitDetectionInstructions;
            t.reverse();
            let e, i = t.length, r, s, o = -1;
            for (e = 0; e < i; ++e) r = t[e], s = r[0], s == X.END_GEOMETRY ? o = e : s == X.BEGIN_GEOMETRY && (r[2] = e, bc(this.hitDetectionInstructions, o, e), o = -1)
        }

        setFillStrokeStyle(t, e) {
            let i = this.state;
            if (t) {
                let r = t.getColor();
                i.fillStyle = ae(r || Ot)
            } else i.fillStyle = void 0;
            if (e) {
                let r = e.getColor();
                i.strokeStyle = ae(r || Ei);
                let s = e.getLineCap();
                i.lineCap = s !== void 0 ? s : qe;
                let o = e.getLineDash();
                i.lineDash = o ? o.slice() : se;
                let a = e.getLineDashOffset();
                i.lineDashOffset = a || oe;
                let l = e.getLineJoin();
                i.lineJoin = l !== void 0 ? l : He;
                let h = e.getWidth();
                i.lineWidth = h !== void 0 ? h : wi;
                let c = e.getMiterLimit();
                i.miterLimit = c !== void 0 ? c : xi, i.lineWidth > this.maxLineWidth && (this.maxLineWidth = i.lineWidth, this.bufferedMaxExtent_ = null)
            } else i.strokeStyle = void 0, i.lineCap = void 0, i.lineDash = null, i.lineDashOffset = void 0, i.lineJoin = void 0, i.lineWidth = void 0, i.miterLimit = void 0
        }

        createFill(t) {
            let e = t.fillStyle, i = [X.SET_FILL_STYLE, e];
            return typeof e != "string" && i.push(!0), i
        }

        applyStroke(t) {
            this.instructions.push(this.createStroke(t))
        }

        createStroke(t) {
            return [X.SET_STROKE_STYLE, t.strokeStyle, t.lineWidth * this.pixelRatio, t.lineCap, t.lineJoin, t.miterLimit, this.applyPixelRatio(t.lineDash), t.lineDashOffset * this.pixelRatio]
        }

        updateFillStyle(t, e) {
            let i = t.fillStyle;
            (typeof i != "string" || t.currentFillStyle != i) && (i !== void 0 && this.instructions.push(e.call(this, t)), t.currentFillStyle = i)
        }

        updateStrokeStyle(t, e) {
            let i = t.strokeStyle, r = t.lineCap, s = t.lineDash, o = t.lineDashOffset, a = t.lineJoin, l = t.lineWidth,
                h = t.miterLimit;
            (t.currentStrokeStyle != i || t.currentLineCap != r || s != t.currentLineDash && !Vt(t.currentLineDash, s) || t.currentLineDashOffset != o || t.currentLineJoin != a || t.currentLineWidth != l || t.currentMiterLimit != h) && (i !== void 0 && e.call(this, t), t.currentStrokeStyle = i, t.currentLineCap = r, t.currentLineDash = s, t.currentLineDashOffset = o, t.currentLineJoin = a, t.currentLineWidth = l, t.currentMiterLimit = h)
        }

        endGeometry(t) {
            this.beginGeometryInstruction1_[2] = this.instructions.length, this.beginGeometryInstruction1_ = null, this.beginGeometryInstruction2_[2] = this.hitDetectionInstructions.length, this.beginGeometryInstruction2_ = null;
            let e = [X.END_GEOMETRY, t];
            this.instructions.push(e), this.hitDetectionInstructions.push(e)
        }

        getBufferedMaxExtent() {
            if (!this.bufferedMaxExtent_ && (this.bufferedMaxExtent_ = Is(this.maxExtent), this.maxLineWidth > 0)) {
                let t = this.resolution * (this.maxLineWidth + 1) / 2;
                jn(this.bufferedMaxExtent_, t, this.bufferedMaxExtent_)
            }
            return this.bufferedMaxExtent_
        }
    }, ni = jh
});
var Bh, lg, hg = v(() => {
    Tr();
    Ln();
    Bh = class extends ni {
        constructor(t, e, i, r) {
            super(t, e, i, r), this.hitDetectionImage_ = null, this.image_ = null, this.imagePixelRatio_ = void 0, this.anchorX_ = void 0, this.anchorY_ = void 0, this.height_ = void 0, this.opacity_ = void 0, this.originX_ = void 0, this.originY_ = void 0, this.rotateWithView_ = void 0, this.rotation_ = void 0, this.scale_ = void 0, this.width_ = void 0, this.declutterMode_ = void 0, this.declutterImageWithText_ = void 0
        }

        drawPoint(t, e) {
            if (!this.image_) return;
            this.beginGeometry(t, e);
            let i = t.getFlatCoordinates(), r = t.getStride(), s = this.coordinates.length,
                o = this.appendFlatPointCoordinates(i, r);
            this.instructions.push([X.DRAW_IMAGE, s, o, this.image_, this.anchorX_ * this.imagePixelRatio_, this.anchorY_ * this.imagePixelRatio_, Math.ceil(this.height_ * this.imagePixelRatio_), this.opacity_, this.originX_ * this.imagePixelRatio_, this.originY_ * this.imagePixelRatio_, this.rotateWithView_, this.rotation_, [this.scale_[0] * this.pixelRatio / this.imagePixelRatio_, this.scale_[1] * this.pixelRatio / this.imagePixelRatio_], Math.ceil(this.width_ * this.imagePixelRatio_), this.declutterMode_, this.declutterImageWithText_]), this.hitDetectionInstructions.push([X.DRAW_IMAGE, s, o, this.hitDetectionImage_, this.anchorX_, this.anchorY_, this.height_, 1, this.originX_, this.originY_, this.rotateWithView_, this.rotation_, this.scale_, this.width_, this.declutterMode_, this.declutterImageWithText_]), this.endGeometry(e)
        }

        drawMultiPoint(t, e) {
            if (!this.image_) return;
            this.beginGeometry(t, e);
            let i = t.getFlatCoordinates(), r = t.getStride(), s = this.coordinates.length,
                o = this.appendFlatPointCoordinates(i, r);
            this.instructions.push([X.DRAW_IMAGE, s, o, this.image_, this.anchorX_ * this.imagePixelRatio_, this.anchorY_ * this.imagePixelRatio_, Math.ceil(this.height_ * this.imagePixelRatio_), this.opacity_, this.originX_ * this.imagePixelRatio_, this.originY_ * this.imagePixelRatio_, this.rotateWithView_, this.rotation_, [this.scale_[0] * this.pixelRatio / this.imagePixelRatio_, this.scale_[1] * this.pixelRatio / this.imagePixelRatio_], Math.ceil(this.width_ * this.imagePixelRatio_), this.declutterMode_, this.declutterImageWithText_]), this.hitDetectionInstructions.push([X.DRAW_IMAGE, s, o, this.hitDetectionImage_, this.anchorX_, this.anchorY_, this.height_, 1, this.originX_, this.originY_, this.rotateWithView_, this.rotation_, this.scale_, this.width_, this.declutterMode_, this.declutterImageWithText_]), this.endGeometry(e)
        }

        finish() {
            return this.reverseHitDetectionInstructions(), this.anchorX_ = void 0, this.anchorY_ = void 0, this.hitDetectionImage_ = null, this.image_ = null, this.imagePixelRatio_ = void 0, this.height_ = void 0, this.scale_ = void 0, this.opacity_ = void 0, this.originX_ = void 0, this.originY_ = void 0, this.rotateWithView_ = void 0, this.rotation_ = void 0, this.width_ = void 0, super.finish()
        }

        setImageStyle(t, e) {
            let i = t.getAnchor(), r = t.getSize(), s = t.getOrigin();
            this.imagePixelRatio_ = t.getPixelRatio(this.pixelRatio), this.anchorX_ = i[0], this.anchorY_ = i[1], this.hitDetectionImage_ = t.getHitDetectionImage(), this.image_ = t.getImage(this.pixelRatio), this.height_ = r[1], this.opacity_ = t.getOpacity(), this.originX_ = s[0], this.originY_ = s[1], this.rotateWithView_ = t.getRotateWithView(), this.rotation_ = t.getRotation(), this.scale_ = t.getScaleArray(), this.width_ = r[0], this.declutterMode_ = t.getDeclutterMode(), this.declutterImageWithText_ = e
        }
    }, lg = Bh
});
var Kh, cg, ug = v(() => {
    Tr();
    Ln();
    Ti();
    Kh = class extends ni {
        constructor(t, e, i, r) {
            super(t, e, i, r)
        }

        drawFlatCoordinates_(t, e, i, r) {
            let s = this.coordinates.length, o = this.appendFlatLineCoordinates(t, e, i, r, !1, !1),
                a = [X.MOVE_TO_LINE_TO, s, o];
            return this.instructions.push(a), this.hitDetectionInstructions.push(a), i
        }

        drawLineString(t, e) {
            let i = this.state, r = i.strokeStyle, s = i.lineWidth;
            if (r === void 0 || s === void 0) return;
            this.updateStrokeStyle(i, this.applyStroke), this.beginGeometry(t, e), this.hitDetectionInstructions.push([X.SET_STROKE_STYLE, i.strokeStyle, i.lineWidth, i.lineCap, i.lineJoin, i.miterLimit, se, oe], bi);
            let o = t.getFlatCoordinates(), a = t.getStride();
            this.drawFlatCoordinates_(o, 0, o.length, a), this.hitDetectionInstructions.push(ii), this.endGeometry(e)
        }

        drawMultiLineString(t, e) {
            let i = this.state, r = i.strokeStyle, s = i.lineWidth;
            if (r === void 0 || s === void 0) return;
            this.updateStrokeStyle(i, this.applyStroke), this.beginGeometry(t, e), this.hitDetectionInstructions.push([X.SET_STROKE_STYLE, i.strokeStyle, i.lineWidth, i.lineCap, i.lineJoin, i.miterLimit, se, oe], bi);
            let o = t.getEnds(), a = t.getFlatCoordinates(), l = t.getStride(), h = 0;
            for (let c = 0, u = o.length; c < u; ++c) h = this.drawFlatCoordinates_(a, h, o[c], l);
            this.hitDetectionInstructions.push(ii), this.endGeometry(e)
        }

        finish() {
            let t = this.state;
            return t.lastStroke != null && t.lastStroke != this.coordinates.length && this.instructions.push(ii), this.reverseHitDetectionInstructions(), this.state = null, super.finish()
        }

        applyStroke(t) {
            t.lastStroke != null && t.lastStroke != this.coordinates.length && (this.instructions.push(ii), t.lastStroke = this.coordinates.length), t.lastStroke = 0, super.applyStroke(t), this.instructions.push(bi)
        }
    }, cg = Kh
});
var Vh, Zh, dg = v(() => {
    Tr();
    Ln();
    Ti();
    zr();
    Vh = class extends ni {
        constructor(t, e, i, r) {
            super(t, e, i, r)
        }

        drawFlatCoordinatess_(t, e, i, r) {
            let s = this.state, o = s.fillStyle !== void 0, a = s.strokeStyle !== void 0, l = i.length;
            this.instructions.push(bi), this.hitDetectionInstructions.push(bi);
            for (let h = 0; h < l; ++h) {
                let c = i[h], u = this.coordinates.length, d = this.appendFlatLineCoordinates(t, e, c, r, !0, !a),
                    f = [X.MOVE_TO_LINE_TO, u, d];
                this.instructions.push(f), this.hitDetectionInstructions.push(f), a && (this.instructions.push(zh), this.hitDetectionInstructions.push(zh)), e = c
            }
            return o && (this.instructions.push(fs), this.hitDetectionInstructions.push(fs)), a && (this.instructions.push(ii), this.hitDetectionInstructions.push(ii)), e
        }

        drawCircle(t, e) {
            let i = this.state, r = i.fillStyle, s = i.strokeStyle;
            if (r === void 0 && s === void 0) return;
            this.setFillStrokeStyles_(), this.beginGeometry(t, e), i.fillStyle !== void 0 && this.hitDetectionInstructions.push([X.SET_FILL_STYLE, Ot]), i.strokeStyle !== void 0 && this.hitDetectionInstructions.push([X.SET_STROKE_STYLE, i.strokeStyle, i.lineWidth, i.lineCap, i.lineJoin, i.miterLimit, se, oe]);
            let o = t.getFlatCoordinates(), a = t.getStride(), l = this.coordinates.length;
            this.appendFlatLineCoordinates(o, 0, o.length, a, !1, !1);
            let h = [X.CIRCLE, l];
            this.instructions.push(bi, h), this.hitDetectionInstructions.push(bi, h), i.fillStyle !== void 0 && (this.instructions.push(fs), this.hitDetectionInstructions.push(fs)), i.strokeStyle !== void 0 && (this.instructions.push(ii), this.hitDetectionInstructions.push(ii)), this.endGeometry(e)
        }

        drawPolygon(t, e) {
            let i = this.state, r = i.fillStyle, s = i.strokeStyle;
            if (r === void 0 && s === void 0) return;
            this.setFillStrokeStyles_(), this.beginGeometry(t, e), i.fillStyle !== void 0 && this.hitDetectionInstructions.push([X.SET_FILL_STYLE, Ot]), i.strokeStyle !== void 0 && this.hitDetectionInstructions.push([X.SET_STROKE_STYLE, i.strokeStyle, i.lineWidth, i.lineCap, i.lineJoin, i.miterLimit, se, oe]);
            let o = t.getEnds(), a = t.getOrientedFlatCoordinates(), l = t.getStride();
            this.drawFlatCoordinatess_(a, 0, o, l), this.endGeometry(e)
        }

        drawMultiPolygon(t, e) {
            let i = this.state, r = i.fillStyle, s = i.strokeStyle;
            if (r === void 0 && s === void 0) return;
            this.setFillStrokeStyles_(), this.beginGeometry(t, e), i.fillStyle !== void 0 && this.hitDetectionInstructions.push([X.SET_FILL_STYLE, Ot]), i.strokeStyle !== void 0 && this.hitDetectionInstructions.push([X.SET_STROKE_STYLE, i.strokeStyle, i.lineWidth, i.lineCap, i.lineJoin, i.miterLimit, se, oe]);
            let o = t.getEndss(), a = t.getOrientedFlatCoordinates(), l = t.getStride(), h = 0;
            for (let c = 0, u = o.length; c < u; ++c) h = this.drawFlatCoordinatess_(a, h, o[c], l);
            this.endGeometry(e)
        }

        finish() {
            this.reverseHitDetectionInstructions(), this.state = null;
            let t = this.tolerance;
            if (t !== 0) {
                let e = this.coordinates;
                for (let i = 0, r = e.length; i < r; ++i) e[i] = Bi(e[i], t)
            }
            return super.finish()
        }

        setFillStrokeStyles_() {
            let t = this.state;
            t.fillStyle !== void 0 && this.updateFillStyle(t, this.createFill), t.strokeStyle !== void 0 && this.updateStrokeStyle(t, this.applyStroke)
        }
    }, Zh = Vh
});

function fg(n, t, e, i, r) {
    let s = [], o = e, a = 0, l = t.slice(e, 2);
    for (; a < n && o + r < i;) {
        let [h, c] = l.slice(-2), u = t[o + r], d = t[o + r + 1], f = Math.sqrt((u - h) * (u - h) + (d - c) * (d - c));
        if (a += f, a >= n) {
            let g = (n - a + f) / f, m = qt(h, u, g), p = qt(c, d, g);
            l.push(m, p), s.push(l), l = [m, p], a == n && (o += r), a = 0
        } else if (a < n) l.push(t[o + r], t[o + r + 1]), o += r; else {
            let g = f - a, m = qt(h, u, g / f), p = qt(c, d, g / f);
            l.push(m, p), s.push(l), l = [m, p], a = 0, o += r
        }
    }
    return a > 0 && s.push(l), s
}

var gg = v(() => {
    xt()
});

function mg(n, t, e, i, r) {
    let s = e, o = e, a = 0, l = 0, h = e, c, u, d, f, g, m, p, _, y, C;
    for (u = e; u < i; u += r) {
        let w = t[u], T = t[u + 1];
        g !== void 0 && (y = w - g, C = T - m, f = Math.sqrt(y * y + C * C), p !== void 0 && (l += d, c = Math.acos((p * y + _ * C) / (d * f)), c > n && (l > a && (a = l, s = h, o = u), l = 0, h = u - r)), d = f, p = y, _ = C), g = w, m = T
    }
    return l += f, l > a ? [h, u] : [s, o]
}

var pg = v(() => {
});
var gs, qh, _g, Hh = v(() => {
    Tr();
    Ln();
    Qr();
    Ti();
    wt();
    rt();
    gg();
    pg();
    gs = {
        left: 0,
        center: .5,
        right: 1,
        top: 0,
        middle: .5,
        hanging: .2,
        alphabetic: .8,
        ideographic: .8,
        bottom: 1
    }, qh = class extends ni {
        constructor(t, e, i, r) {
            super(t, e, i, r), this.labels_ = null, this.text_ = "", this.textOffsetX_ = 0, this.textOffsetY_ = 0, this.textRotateWithView_ = void 0, this.textRotation_ = 0, this.textFillState_ = null, this.fillStates = {}, this.fillStates[Ot] = {fillStyle: Ot}, this.textStrokeState_ = null, this.strokeStates = {}, this.textState_ = {}, this.textStates = {}, this.textKey_ = "", this.fillKey_ = "", this.strokeKey_ = "", this.declutterImageWithText_ = void 0
        }

        finish() {
            let t = super.finish();
            return t.textStates = this.textStates, t.fillStates = this.fillStates, t.strokeStates = this.strokeStates, t
        }

        drawText(t, e) {
            let i = this.textFillState_, r = this.textStrokeState_, s = this.textState_;
            if (this.text_ === "" || !s || !i && !r) return;
            let o = this.coordinates, a = o.length, l = t.getType(), h = null, c = t.getStride();
            if (s.placement === "line" && (l == "LineString" || l == "MultiLineString" || l == "Polygon" || l == "MultiPolygon")) {
                if (!yt(this.getBufferedMaxExtent(), t.getExtent())) return;
                let u;
                if (h = t.getFlatCoordinates(), l == "LineString") u = [h.length]; else if (l == "MultiLineString") u = t.getEnds(); else if (l == "Polygon") u = t.getEnds().slice(0, 1); else if (l == "MultiPolygon") {
                    let m = t.getEndss();
                    u = [];
                    for (let p = 0, _ = m.length; p < _; ++p) u.push(m[p][0])
                }
                this.beginGeometry(t, e);
                let d = s.repeat, f = d ? void 0 : s.textAlign, g = 0;
                for (let m = 0, p = u.length; m < p; ++m) {
                    let _;
                    d ? _ = fg(d * this.resolution, h, g, u[m], c) : _ = [h.slice(g, u[m])];
                    for (let y = 0, C = _.length; y < C; ++y) {
                        let w = _[y], T = 0, R = w.length;
                        if (f == null) {
                            let b = mg(s.maxAngle, w, 0, w.length, 2);
                            T = b[0], R = b[1]
                        }
                        for (let b = T; b < R; b += c) o.push(w[b], w[b + 1]);
                        let A = o.length;
                        g = u[m], this.drawChars_(a, A), a = A
                    }
                }
                this.endGeometry(e)
            } else {
                let u = s.overflow ? null : [];
                switch (l) {
                    case"Point":
                    case"MultiPoint":
                        h = t.getFlatCoordinates();
                        break;
                    case"LineString":
                        h = t.getFlatMidpoint();
                        break;
                    case"Circle":
                        h = t.getCenter();
                        break;
                    case"MultiLineString":
                        h = t.getFlatMidpoints(), c = 2;
                        break;
                    case"Polygon":
                        h = t.getFlatInteriorPoint(), s.overflow || u.push(h[2] / this.resolution), c = 3;
                        break;
                    case"MultiPolygon":
                        let _ = t.getFlatInteriorPoints();
                        h = [];
                        for (let y = 0, C = _.length; y < C; y += 3) s.overflow || u.push(_[y + 2] / this.resolution), h.push(_[y], _[y + 1]);
                        if (h.length === 0) return;
                        c = 2;
                        break;
                    default:
                }
                let d = this.appendFlatPointCoordinates(h, c);
                if (d === a) return;
                if (u && (d - a) / 2 !== h.length / c) {
                    let _ = a / 2;
                    u = u.filter((y, C) => {
                        let w = o[(_ + C) * 2] === h[C * c] && o[(_ + C) * 2 + 1] === h[C * c + 1];
                        return w || --_, w
                    })
                }
                this.saveTextStates_(), (s.backgroundFill || s.backgroundStroke) && (this.setFillStrokeStyle(s.backgroundFill, s.backgroundStroke), s.backgroundFill && this.updateFillStyle(this.state, this.createFill), s.backgroundStroke && (this.updateStrokeStyle(this.state, this.applyStroke), this.hitDetectionInstructions.push(this.createStroke(this.state)))), this.beginGeometry(t, e);
                let f = s.padding;
                if (f != Ci && (s.scale[0] < 0 || s.scale[1] < 0)) {
                    let _ = s.padding[0], y = s.padding[1], C = s.padding[2], w = s.padding[3];
                    s.scale[0] < 0 && (y = -y, w = -w), s.scale[1] < 0 && (_ = -_, C = -C), f = [_, y, C, w]
                }
                let g = this.pixelRatio;
                this.instructions.push([X.DRAW_IMAGE, a, d, null, NaN, NaN, NaN, 1, 0, 0, this.textRotateWithView_, this.textRotation_, [1, 1], NaN, void 0, this.declutterImageWithText_, f == Ci ? Ci : f.map(function (_) {
                    return _ * g
                }), !!s.backgroundFill, !!s.backgroundStroke, this.text_, this.textKey_, this.strokeKey_, this.fillKey_, this.textOffsetX_, this.textOffsetY_, u]);
                let m = 1 / g, p = this.state.fillStyle;
                s.backgroundFill && (this.state.fillStyle = Ot, this.hitDetectionInstructions.push(this.createFill(this.state))), this.hitDetectionInstructions.push([X.DRAW_IMAGE, a, d, null, NaN, NaN, NaN, 1, 0, 0, this.textRotateWithView_, this.textRotation_, [m, m], NaN, void 0, this.declutterImageWithText_, f, !!s.backgroundFill, !!s.backgroundStroke, this.text_, this.textKey_, this.strokeKey_, this.fillKey_ ? Ot : this.fillKey_, this.textOffsetX_, this.textOffsetY_, u]), s.backgroundFill && (this.state.fillStyle = p, this.hitDetectionInstructions.push(this.createFill(this.state))), this.endGeometry(e)
            }
        }

        saveTextStates_() {
            let t = this.textStrokeState_, e = this.textState_, i = this.textFillState_, r = this.strokeKey_;
            t && (r in this.strokeStates || (this.strokeStates[r] = {
                strokeStyle: t.strokeStyle,
                lineCap: t.lineCap,
                lineDashOffset: t.lineDashOffset,
                lineWidth: t.lineWidth,
                lineJoin: t.lineJoin,
                miterLimit: t.miterLimit,
                lineDash: t.lineDash
            }));
            let s = this.textKey_;
            s in this.textStates || (this.textStates[s] = {
                font: e.font,
                textAlign: e.textAlign || qi,
                justify: e.justify,
                textBaseline: e.textBaseline || Cn,
                scale: e.scale
            });
            let o = this.fillKey_;
            i && (o in this.fillStates || (this.fillStates[o] = {fillStyle: i.fillStyle}))
        }

        drawChars_(t, e) {
            let i = this.textStrokeState_, r = this.textState_, s = this.strokeKey_, o = this.textKey_,
                a = this.fillKey_;
            this.saveTextStates_();
            let l = this.pixelRatio, h = gs[r.textBaseline], c = this.textOffsetY_ * l, u = this.text_,
                d = i ? i.lineWidth * Math.abs(r.scale[0]) / 2 : 0;
            this.instructions.push([X.DRAW_CHARS, t, e, h, r.overflow, a, r.maxAngle, l, c, s, d * l, u, o, 1]), this.hitDetectionInstructions.push([X.DRAW_CHARS, t, e, h, r.overflow, a && Ot, r.maxAngle, l, c, s, d * l, u, o, 1 / l])
        }

        setTextStyle(t, e) {
            let i, r, s;
            if (!t) this.text_ = ""; else {
                let o = t.getFill();
                o ? (r = this.textFillState_, r || (r = {}, this.textFillState_ = r), r.fillStyle = ae(o.getColor() || Ot)) : (r = null, this.textFillState_ = r);
                let a = t.getStroke();
                if (!a) s = null, this.textStrokeState_ = s; else {
                    s = this.textStrokeState_, s || (s = {}, this.textStrokeState_ = s);
                    let g = a.getLineDash(), m = a.getLineDashOffset(), p = a.getWidth(), _ = a.getMiterLimit();
                    s.lineCap = a.getLineCap() || qe, s.lineDash = g ? g.slice() : se, s.lineDashOffset = m === void 0 ? oe : m, s.lineJoin = a.getLineJoin() || He, s.lineWidth = p === void 0 ? wi : p, s.miterLimit = _ === void 0 ? xi : _, s.strokeStyle = ae(a.getColor() || Ei)
                }
                i = this.textState_;
                let l = t.getFont() || oo;
                yd(l);
                let h = t.getScaleArray();
                i.overflow = t.getOverflow(), i.font = l, i.maxAngle = t.getMaxAngle(), i.placement = t.getPlacement(), i.textAlign = t.getTextAlign(), i.repeat = t.getRepeat(), i.justify = t.getJustify(), i.textBaseline = t.getTextBaseline() || Cn, i.backgroundFill = t.getBackgroundFill(), i.backgroundStroke = t.getBackgroundStroke(), i.padding = t.getPadding() || Ci, i.scale = h === void 0 ? [1, 1] : h;
                let c = t.getOffsetX(), u = t.getOffsetY(), d = t.getRotateWithView(), f = t.getRotation();
                this.text_ = t.getText() || "", this.textOffsetX_ = c === void 0 ? 0 : c, this.textOffsetY_ = u === void 0 ? 0 : u, this.textRotateWithView_ = d === void 0 ? !1 : d, this.textRotation_ = f === void 0 ? 0 : f, this.strokeKey_ = s ? (typeof s.strokeStyle == "string" ? s.strokeStyle : K(s.strokeStyle)) + s.lineCap + s.lineDashOffset + "|" + s.lineWidth + s.lineJoin + s.miterLimit + "[" + s.lineDash.join() + "]" : "", this.textKey_ = i.font + i.scale + (i.textAlign || "?") + (i.repeat || "?") + (i.justify || "?") + (i.textBaseline || "?"), this.fillKey_ = r ? typeof r.fillStyle == "string" ? r.fillStyle : "|" + K(r.fillStyle) : ""
            }
            this.declutterImageWithText_ = e
        }
    }, _g = qh
});
var Wp, $h, Jh, yg = v(() => {
    Tr();
    hg();
    ug();
    dg();
    Hh();
    Wp = {Circle: Zh, Default: ni, Image: lg, LineString: cg, Polygon: Zh, Text: _g}, $h = class {
        constructor(t, e, i, r) {
            this.tolerance_ = t, this.maxExtent_ = e, this.pixelRatio_ = r, this.resolution_ = i, this.buildersByZIndex_ = {}
        }

        finish() {
            let t = {};
            for (let e in this.buildersByZIndex_) {
                t[e] = t[e] || {};
                let i = this.buildersByZIndex_[e];
                for (let r in i) {
                    let s = i[r].finish();
                    t[e][r] = s
                }
            }
            return t
        }

        getBuilder(t, e) {
            let i = t !== void 0 ? t.toString() : "0", r = this.buildersByZIndex_[i];
            r === void 0 && (r = {}, this.buildersByZIndex_[i] = r);
            let s = r[e];
            if (s === void 0) {
                let o = Wp[e];
                s = new o(this.tolerance_, this.maxExtent_, this.resolution_, this.pixelRatio_), r[e] = s
            }
            return s
        }
    }, Jh = $h
});

function xg(n, t, e, i, r, s, o, a, l, h, c, u) {
    let d = n[t], f = n[t + 1], g = 0, m = 0, p = 0, _ = 0;

    function y() {
        g = d, m = f, t += i, d = n[t], f = n[t + 1], _ += p, p = Math.sqrt((d - g) * (d - g) + (f - m) * (f - m))
    }

    do y(); while (t < e - i && _ + p < s);
    let C = p === 0 ? 0 : (s - _) / p, w = qt(g, d, C), T = qt(m, f, C), R = t - i, A = _, b = s + a * l(h, r, c);
    for (; t < e - i && _ + p < b;) y();
    C = p === 0 ? 0 : (b - _) / p;
    let O = qt(g, d, C), W = qt(m, f, C), Z;
    if (u) {
        let F = [w, T, O, W];
        Zs(F, 0, 4, 2, u, F, F), Z = F[0] > F[2]
    } else Z = w > O;
    let it = Math.PI, j = [], mt = R + i === t;
    t = R, p = 0, _ = A, d = n[t], f = n[t + 1];
    let Y;
    if (mt) {
        y(), Y = Math.atan2(f - m, d - g), Z && (Y += Y > 0 ? -it : it);
        let F = (O + w) / 2, P = (W + T) / 2;
        return j[0] = [F, P, (b - s) / 2, Y, r], j
    }
    r = r.replace(/\n/g, " ");
    for (let F = 0, P = r.length; F < P;) {
        y();
        let N = Math.atan2(f - m, d - g);
        if (Z && (N += N > 0 ? -it : it), Y !== void 0) {
            let q = N - Y;
            if (q += q > it ? -2 * it : q < -it ? 2 * it : 0, Math.abs(q) > o) return null
        }
        Y = N;
        let nt = F, at = 0;
        for (; F < P; ++F) {
            let q = Z ? P - F - 1 : F, st = a * l(h, r[q], c);
            if (t + i < e && _ + p < s + at + st / 2) break;
            at += st
        }
        if (F === nt) continue;
        let At = Z ? r.substring(P - nt, P - F) : r.substring(nt, F);
        C = p === 0 ? 0 : (s + at / 2 - _) / p;
        let I = qt(g, d, C), vt = qt(m, f, C);
        j.push([I, vt, at / 2, N, At]), s += at
    }
    return j
}

var Eg = v(() => {
    xt();
    ji()
});

function Cg(n) {
    return n[3].declutterBox
}

function Qh(n, t) {
    return t === "start" ? t = wg.test(n) ? "right" : "left" : t === "end" && (t = wg.test(n) ? "left" : "right"), gs[t]
}

function zp(n, t, e) {
    return e > 0 && n.push(`
`, ""), n.push(t, ""), n
}

var vr, sn, Ai, Mi, on, wg, tc, Tg, vg = v(() => {
    Ln();
    Hh();
    De();
    rt();
    Ti();
    Eg();
    Ct();
    Df();
    ji();
    vr = Tt(), sn = [], Ai = [], Mi = [], on = [];
    wg = new RegExp("[\u0591-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFC\u0800-\u0FFF\uE800-\uEFFF]");
    tc = class {
        constructor(t, e, i, r) {
            this.overlaps = i, this.pixelRatio = e, this.resolution = t, this.alignFill_, this.instructions = r.instructions, this.coordinates = r.coordinates, this.coordinateCache_ = {}, this.renderedTransform_ = kt(), this.hitDetectionInstructions = r.hitDetectionInstructions, this.pixelCoordinates_ = null, this.viewRotation_ = 0, this.fillStates = r.fillStates || {}, this.strokeStates = r.strokeStates || {}, this.textStates = r.textStates || {}, this.widths_ = {}, this.labels_ = {}
        }

        createLabel(t, e, i, r) {
            let s = t + e + i + r;
            if (this.labels_[s]) return this.labels_[s];
            let o = r ? this.strokeStates[r] : null, a = i ? this.fillStates[i] : null, l = this.textStates[e],
                h = this.pixelRatio, c = [l.scale[0] * h, l.scale[1] * h], u = Array.isArray(t),
                d = l.justify ? gs[l.justify] : Qh(Array.isArray(t) ? t[0] : t, l.textAlign || qi),
                f = r && o.lineWidth ? o.lineWidth : 0, g = u ? t : t.split(`
`).reduce(zp, []), {width: m, height: p, widths: _, heights: y, lineWidths: C} = Ed(l, g), w = m + f, T = [],
                R = (w + 2) * c[0], A = (p + f) * c[1], b = {
                    width: R < 0 ? Math.floor(R) : Math.ceil(R),
                    height: A < 0 ? Math.floor(A) : Math.ceil(A),
                    contextInstructions: T
                };
            (c[0] != 1 || c[1] != 1) && T.push("scale", c), r && (T.push("strokeStyle", o.strokeStyle), T.push("lineWidth", f), T.push("lineCap", o.lineCap), T.push("lineJoin", o.lineJoin), T.push("miterLimit", o.miterLimit), T.push("setLineDash", [o.lineDash]), T.push("lineDashOffset", o.lineDashOffset)), i && T.push("fillStyle", a.fillStyle), T.push("textBaseline", "middle"), T.push("textAlign", "center");
            let O = .5 - d, W = d * w + O * f, Z = [], it = [], j = 0, mt = 0, Y = 0, F = 0, P;
            for (let N = 0, nt = g.length; N < nt; N += 2) {
                let at = g[N];
                if (at === `
`) {
                    mt += j, j = 0, W = d * w + O * f, ++F;
                    continue
                }
                let At = g[N + 1] || l.font;
                At !== P && (r && Z.push("font", At), i && it.push("font", At), P = At), j = Math.max(j, y[Y]);
                let I = [at, W + O * _[Y] + d * (_[Y] - C[F]), .5 * (f + j) + mt];
                W += _[Y], r && Z.push("strokeText", I), i && it.push("fillText", I), ++Y
            }
            return Array.prototype.push.apply(T, Z), Array.prototype.push.apply(T, it), this.labels_[s] = b, b
        }

        replayTextBackground_(t, e, i, r, s, o, a) {
            t.beginPath(), t.moveTo.apply(t, e), t.lineTo.apply(t, i), t.lineTo.apply(t, r), t.lineTo.apply(t, s), t.lineTo.apply(t, e), o && (this.alignFill_ = o[2], this.fill_(t)), a && (this.setStrokeStyle_(t, a), t.stroke())
        }

        calculateImageOrLabelDimensions_(t, e, i, r, s, o, a, l, h, c, u, d, f, g, m, p) {
            a *= d[0], l *= d[1];
            let _ = i - a, y = r - l, C = s + h > t ? t - h : s, w = o + c > e ? e - c : o, T = g[3] + C * d[0] + g[1],
                R = g[0] + w * d[1] + g[2], A = _ - g[3], b = y - g[0];
            (m || u !== 0) && (sn[0] = A, on[0] = A, sn[1] = b, Ai[1] = b, Ai[0] = A + T, Mi[0] = Ai[0], Mi[1] = b + R, on[1] = Mi[1]);
            let O;
            return u !== 0 ? (O = zt(kt(), i, r, 1, 1, u, -i, -r), _t(O, sn), _t(O, Ai), _t(O, Mi), _t(O, on), ge(Math.min(sn[0], Ai[0], Mi[0], on[0]), Math.min(sn[1], Ai[1], Mi[1], on[1]), Math.max(sn[0], Ai[0], Mi[0], on[0]), Math.max(sn[1], Ai[1], Mi[1], on[1]), vr)) : ge(Math.min(A, A + T), Math.min(b, b + R), Math.max(A, A + T), Math.max(b, b + R), vr), f && (_ = Math.round(_), y = Math.round(y)), {
                drawImageX: _,
                drawImageY: y,
                drawImageW: C,
                drawImageH: w,
                originX: h,
                originY: c,
                declutterBox: {minX: vr[0], minY: vr[1], maxX: vr[2], maxY: vr[3], value: p},
                canvasTransform: O,
                scale: d
            }
        }

        replayImageOrLabel_(t, e, i, r, s, o, a) {
            let l = !!(o || a), h = r.declutterBox, c = t.canvas, u = a ? a[2] * r.scale[0] / 2 : 0;
            return h.minX - u <= c.width / e && h.maxX + u >= 0 && h.minY - u <= c.height / e && h.maxY + u >= 0 && (l && this.replayTextBackground_(t, sn, Ai, Mi, on, o, a), Cd(t, r.canvasTransform, s, i, r.originX, r.originY, r.drawImageW, r.drawImageH, r.drawImageX, r.drawImageY, r.scale)), !0
        }

        fill_(t) {
            if (this.alignFill_) {
                let e = _t(this.renderedTransform_, [0, 0]), i = 512 * this.pixelRatio;
                t.save(), t.translate(e[0] % i, e[1] % i), t.rotate(this.viewRotation_)
            }
            t.fill(), this.alignFill_ && t.restore()
        }

        setStrokeStyle_(t, e) {
            t.strokeStyle = e[1], t.lineWidth = e[2], t.lineCap = e[3], t.lineJoin = e[4], t.miterLimit = e[5], t.lineDashOffset = e[7], t.setLineDash(e[6])
        }

        drawLabelWithPointPlacement_(t, e, i, r) {
            let s = this.textStates[e], o = this.createLabel(t, e, r, i), a = this.strokeStates[i], l = this.pixelRatio,
                h = Qh(Array.isArray(t) ? t[0] : t, s.textAlign || qi), c = gs[s.textBaseline || Cn],
                u = a && a.lineWidth ? a.lineWidth : 0, d = o.width / l - 2 * s.scale[0], f = h * d + 2 * (.5 - h) * u,
                g = c * o.height / l + 2 * (.5 - c) * u;
            return {label: o, anchorX: f, anchorY: g}
        }

        execute_(t, e, i, r, s, o, a, l) {
            let h;
            this.pixelCoordinates_ && Vt(i, this.renderedTransform_) ? h = this.pixelCoordinates_ : (this.pixelCoordinates_ || (this.pixelCoordinates_ = []), h = re(this.coordinates, 0, this.coordinates.length, 2, i, this.pixelCoordinates_), Dc(this.renderedTransform_, i));
            let c = 0, u = r.length, d = 0, f, g, m, p, _, y, C, w, T, R, A, b, O = 0, W = 0, Z = null, it = null,
                j = this.coordinateCache_, mt = this.viewRotation_,
                Y = Math.round(Math.atan2(-i[1], i[0]) * 1e12) / 1e12,
                F = {context: t, pixelRatio: this.pixelRatio, resolution: this.resolution, rotation: mt},
                P = this.instructions != r || this.overlaps ? 0 : 200, N, nt, at, At;
            for (; c < u;) {
                let I = r[c];
                switch (I[0]) {
                    case X.BEGIN_GEOMETRY:
                        N = I[1], At = I[3], N.getGeometry() ? a !== void 0 && !yt(a, At.getExtent()) ? c = I[2] + 1 : ++c : c = I[2];
                        break;
                    case X.BEGIN_PATH:
                        O > P && (this.fill_(t), O = 0), W > P && (t.stroke(), W = 0), !O && !W && (t.beginPath(), p = NaN, _ = NaN), ++c;
                        break;
                    case X.CIRCLE:
                        d = I[1];
                        let q = h[d], st = h[d + 1], pe = h[d + 2], Gt = h[d + 3], ee = pe - q, _e = Gt - st,
                            ri = Math.sqrt(ee * ee + _e * _e);
                        t.moveTo(q + ri, st), t.arc(q, st, ri, 0, 2 * Math.PI, !0), ++c;
                        break;
                    case X.CLOSE_PATH:
                        t.closePath(), ++c;
                        break;
                    case X.CUSTOM:
                        d = I[1], f = I[2];
                        let ln = I[3], tt = I[4], Le = I.length == 6 ? I[5] : void 0;
                        F.geometry = ln, F.feature = N, c in j || (j[c] = []);
                        let Ye = j[c];
                        Le ? Le(h, d, f, 2, Ye) : (Ye[0] = h[d], Ye[1] = h[d + 1], Ye.length = 2), tt(Ye, F), ++c;
                        break;
                    case X.DRAW_IMAGE:
                        d = I[1], f = I[2], w = I[3], g = I[4], m = I[5];
                        let Pi = I[6], Ue = I[7], bn = I[8], An = I[9], Mn = I[10], Oi = I[11], Mt = I[12], Bt = I[13],
                            Xt = I[14], L = I[15];
                        if (!w && I.length >= 20) {
                            T = I[19], R = I[20], A = I[21], b = I[22];
                            let ce = this.drawLabelWithPointPlacement_(T, R, A, b);
                            w = ce.label, I[3] = w;
                            let On = I[23];
                            g = (ce.anchorX - On) * this.pixelRatio, I[4] = g;
                            let ye = I[24];
                            m = (ce.anchorY - ye) * this.pixelRatio, I[5] = m, Pi = w.height, I[6] = Pi, Bt = w.width, I[13] = Bt
                        }
                        let x;
                        I.length > 25 && (x = I[25]);
                        let E, M, B;
                        I.length > 17 ? (E = I[16], M = I[17], B = I[18]) : (E = Ci, M = !1, B = !1), Mn && Y ? Oi += mt : !Mn && !Y && (Oi -= mt);
                        let Q = 0;
                        for (; d < f; d += 2) {
                            if (x && x[Q++] < Bt / this.pixelRatio) continue;
                            let ce = this.calculateImageOrLabelDimensions_(w.width, w.height, h[d], h[d + 1], Bt, Pi, g, m, bn, An, Oi, Mt, s, E, M || B, N),
                                On = [t, e, w, ce, Ue, M ? Z : null, B ? it : null];
                            if (l) {
                                if (Xt === "none") continue;
                                if (Xt === "obstacle") {
                                    l.insert(ce.declutterBox);
                                    continue
                                } else {
                                    let ye, oi;
                                    if (L) {
                                        let ue = f - d;
                                        if (!L[ue]) {
                                            L[ue] = On;
                                            continue
                                        }
                                        if (ye = L[ue], delete L[ue], oi = Cg(ye), l.collides(oi)) continue
                                    }
                                    if (l.collides(ce.declutterBox)) continue;
                                    ye && (l.insert(oi), this.replayImageOrLabel_.apply(this, ye)), l.insert(ce.declutterBox)
                                }
                            }
                            this.replayImageOrLabel_.apply(this, On)
                        }
                        ++c;
                        break;
                    case X.DRAW_CHARS:
                        let Wt = I[1], Rt = I[2], be = I[3], Kt = I[4];
                        b = I[5];
                        let si = I[6], Pn = I[7], Cc = I[8];
                        A = I[9];
                        let Go = I[10];
                        T = I[11], R = I[12];
                        let wc = [I[13], I[13]], Xo = this.textStates[R], Rr = Xo.font,
                            Sr = [Xo.scale[0] * Pn, Xo.scale[1] * Pn], Ir;
                        Rr in this.widths_ ? Ir = this.widths_[Rr] : (Ir = {}, this.widths_[Rr] = Ir);
                        let Tc = Ff(h, Wt, Rt, 2), vc = Math.abs(Sr[0]) * ol(Rr, T, Ir);
                        if (Kt || vc <= Tc) {
                            let ce = this.textStates[R].textAlign, On = (Tc - vc) * Qh(T, ce),
                                ye = xg(h, Wt, Rt, 2, T, On, si, Math.abs(Sr[0]), ol, Rr, Ir, Y ? 0 : this.viewRotation_);
                            t:if (ye) {
                                let oi = [], ue, ps, _s, ie, xe;
                                if (A) for (ue = 0, ps = ye.length; ue < ps; ++ue) {
                                    xe = ye[ue], _s = xe[4], ie = this.createLabel(_s, R, "", A), g = xe[2] + (Sr[0] < 0 ? -Go : Go), m = be * ie.height + (.5 - be) * 2 * Go * Sr[1] / Sr[0] - Cc;
                                    let ai = this.calculateImageOrLabelDimensions_(ie.width, ie.height, xe[0], xe[1], ie.width, ie.height, g, m, 0, 0, xe[3], wc, !1, Ci, !1, N);
                                    if (l && l.collides(ai.declutterBox)) break t;
                                    oi.push([t, e, ie, ai, 1, null, null])
                                }
                                if (b) for (ue = 0, ps = ye.length; ue < ps; ++ue) {
                                    xe = ye[ue], _s = xe[4], ie = this.createLabel(_s, R, b, ""), g = xe[2], m = be * ie.height - Cc;
                                    let ai = this.calculateImageOrLabelDimensions_(ie.width, ie.height, xe[0], xe[1], ie.width, ie.height, g, m, 0, 0, xe[3], wc, !1, Ci, !1, N);
                                    if (l && l.collides(ai.declutterBox)) break t;
                                    oi.push([t, e, ie, ai, 1, null, null])
                                }
                                l && l.load(oi.map(Cg));
                                for (let ai = 0, Jg = oi.length; ai < Jg; ++ai) this.replayImageOrLabel_.apply(this, oi[ai])
                            }
                        }
                        ++c;
                        break;
                    case X.END_GEOMETRY:
                        if (o !== void 0) {
                            N = I[1];
                            let ce = o(N, At);
                            if (ce) return ce
                        }
                        ++c;
                        break;
                    case X.FILL:
                        P ? O++ : this.fill_(t), ++c;
                        break;
                    case X.MOVE_TO_LINE_TO:
                        for (d = I[1], f = I[2], nt = h[d], at = h[d + 1], y = nt + .5 | 0, C = at + .5 | 0, (y !== p || C !== _) && (t.moveTo(nt, at), p = y, _ = C), d += 2; d < f; d += 2) nt = h[d], at = h[d + 1], y = nt + .5 | 0, C = at + .5 | 0, (d == f - 2 || y !== p || C !== _) && (t.lineTo(nt, at), p = y, _ = C);
                        ++c;
                        break;
                    case X.SET_FILL_STYLE:
                        Z = I, this.alignFill_ = I[2], O && (this.fill_(t), O = 0, W && (t.stroke(), W = 0)), t.fillStyle = I[1], ++c;
                        break;
                    case X.SET_STROKE_STYLE:
                        it = I, W && (t.stroke(), W = 0), this.setStrokeStyle_(t, I), ++c;
                        break;
                    case X.STROKE:
                        P ? W++ : t.stroke(), ++c;
                        break;
                    default:
                        ++c;
                        break
                }
            }
            O && this.fill_(t), W && t.stroke()
        }

        execute(t, e, i, r, s, o) {
            this.viewRotation_ = r, this.execute_(t, e, i, this.instructions, s, void 0, void 0, o)
        }

        executeHitDetection(t, e, i, r, s) {
            return this.viewRotation_ = i, this.execute_(t, 1, e, this.hitDetectionInstructions, !0, r, s)
        }
    }, Tg = tc
});

function Yp(n) {
    if (ic[n] !== void 0) return ic[n];
    let t = n * 2 + 1, e = n * n, i = new Array(e + 1);
    for (let s = 0; s <= n; ++s) for (let o = 0; o <= n; ++o) {
        let a = s * s + o * o;
        if (a > e) break;
        let l = i[a];
        l || (l = [], i[a] = l), l.push(((n + s) * t + (n + o)) * 4 + 3), s > 0 && l.push(((n - s) * t + (n + o)) * 4 + 3), o > 0 && (l.push(((n + s) * t + (n - o)) * 4 + 3), s > 0 && l.push(((n - s) * t + (n - o)) * 4 + 3))
    }
    let r = [];
    for (let s = 0, o = i.length; s < o; ++s) i[s] && r.push(...i[s]);
    return ic[n] = r, r
}

var ec, nc, ic, rc, Rg = v(() => {
    vg();
    Ct();
    rt();
    De();
    te();
    Oe();
    ji();
    ec = ["Polygon", "Circle", "LineString", "Image", "Text", "Default"], nc = class {
        constructor(t, e, i, r, s, o) {
            this.maxExtent_ = t, this.overlaps_ = r, this.pixelRatio_ = i, this.resolution_ = e, this.renderBuffer_ = o, this.executorsByZIndex_ = {}, this.hitDetectionContext_ = null, this.hitDetectionTransform_ = kt(), this.createExecutors_(s)
        }

        clip(t, e) {
            let i = this.getClipCoords(e);
            t.beginPath(), t.moveTo(i[0], i[1]), t.lineTo(i[2], i[3]), t.lineTo(i[4], i[5]), t.lineTo(i[6], i[7]), t.clip()
        }

        createExecutors_(t) {
            for (let e in t) {
                let i = this.executorsByZIndex_[e];
                i === void 0 && (i = {}, this.executorsByZIndex_[e] = i);
                let r = t[e];
                for (let s in r) {
                    let o = r[s];
                    i[s] = new Tg(this.resolution_, this.pixelRatio_, this.overlaps_, o)
                }
            }
        }

        hasExecutors(t) {
            for (let e in this.executorsByZIndex_) {
                let i = this.executorsByZIndex_[e];
                for (let r = 0, s = t.length; r < s; ++r) if (t[r] in i) return !0
            }
            return !1
        }

        forEachFeatureAtCoordinate(t, e, i, r, s, o) {
            r = Math.round(r);
            let a = r * 2 + 1, l = zt(this.hitDetectionTransform_, r + .5, r + .5, 1 / e, -1 / e, -i, -t[0], -t[1]),
                h = !this.hitDetectionContext_;
            h && (this.hitDetectionContext_ = gt(a, a, void 0, {willReadFrequently: !0}));
            let c = this.hitDetectionContext_;
            c.canvas.width !== a || c.canvas.height !== a ? (c.canvas.width = a, c.canvas.height = a) : h || c.clearRect(0, 0, a, a);
            let u;
            this.renderBuffer_ !== void 0 && (u = Tt(), cn(u, t), jn(u, e * (this.renderBuffer_ + r), u));
            let d = Yp(r), f;

            function g(T, R) {
                let A = c.getImageData(0, 0, a, a).data;
                for (let b = 0, O = d.length; b < O; b++) if (A[d[b]] > 0) {
                    if (!o || f !== "Image" && f !== "Text" || o.includes(T)) {
                        let W = (d[b] - 3) / 4, Z = r - W % a, it = r - (W / a | 0), j = s(T, R, Z * Z + it * it);
                        if (j) return j
                    }
                    c.clearRect(0, 0, a, a);
                    break
                }
            }

            let m = Object.keys(this.executorsByZIndex_).map(Number);
            m.sort(de);
            let p, _, y, C, w;
            for (p = m.length - 1; p >= 0; --p) {
                let T = m[p].toString();
                for (y = this.executorsByZIndex_[T], _ = ec.length - 1; _ >= 0; --_) if (f = ec[_], C = y[f], C !== void 0 && (w = C.executeHitDetection(c, l, i, g, u), w)) return w
            }
        }

        getClipCoords(t) {
            let e = this.maxExtent_;
            if (!e) return null;
            let i = e[0], r = e[1], s = e[2], o = e[3], a = [i, r, i, o, s, o, s, r];
            return re(a, 0, 8, 2, t, a), a
        }

        isEmpty() {
            return Pe(this.executorsByZIndex_)
        }

        execute(t, e, i, r, s, o, a) {
            let l = Object.keys(this.executorsByZIndex_).map(Number);
            l.sort(de), this.maxExtent_ && (t.save(), this.clip(t, i)), o = o || ec;
            let h, c, u, d, f, g;
            for (a && l.reverse(), h = 0, c = l.length; h < c; ++h) {
                let m = l[h].toString();
                for (f = this.executorsByZIndex_[m], u = 0, d = o.length; u < d; ++u) {
                    let p = o[u];
                    g = f[p], g !== void 0 && g.execute(t, e, i, r, s, a)
                }
            }
            this.maxExtent_ && t.restore()
        }
    }, ic = {};
    rc = nc
});
var sc, Sg, Ig = v(() => {
    Uh();
    Qr();
    De();
    Ti();
    Ct();
    rt();
    xt();
    ji();
    Xr();
    sc = class extends ko {
        constructor(t, e, i, r, s, o, a) {
            super(), this.context_ = t, this.pixelRatio_ = e, this.extent_ = i, this.transform_ = r, this.transformRotation_ = r ? Ds(Math.atan2(r[1], r[0]), 10) : 0, this.viewRotation_ = s, this.squaredTolerance_ = o, this.userTransform_ = a, this.contextFillState_ = null, this.contextStrokeState_ = null, this.contextTextState_ = null, this.fillState_ = null, this.strokeState_ = null, this.image_ = null, this.imageAnchorX_ = 0, this.imageAnchorY_ = 0, this.imageHeight_ = 0, this.imageOpacity_ = 0, this.imageOriginX_ = 0, this.imageOriginY_ = 0, this.imageRotateWithView_ = !1, this.imageRotation_ = 0, this.imageScale_ = [0, 0], this.imageWidth_ = 0, this.text_ = "", this.textOffsetX_ = 0, this.textOffsetY_ = 0, this.textRotateWithView_ = !1, this.textRotation_ = 0, this.textScale_ = [0, 0], this.textFillState_ = null, this.textStrokeState_ = null, this.textState_ = null, this.pixelCoordinates_ = [], this.tmpLocalTransform_ = kt()
        }

        drawImages_(t, e, i, r) {
            if (!this.image_) return;
            let s = re(t, e, i, r, this.transform_, this.pixelCoordinates_), o = this.context_,
                a = this.tmpLocalTransform_, l = o.globalAlpha;
            this.imageOpacity_ != 1 && (o.globalAlpha = l * this.imageOpacity_);
            let h = this.imageRotation_;
            this.transformRotation_ === 0 && (h -= this.viewRotation_), this.imageRotateWithView_ && (h += this.viewRotation_);
            for (let c = 0, u = s.length; c < u; c += 2) {
                let d = s[c] - this.imageAnchorX_, f = s[c + 1] - this.imageAnchorY_;
                if (h !== 0 || this.imageScale_[0] != 1 || this.imageScale_[1] != 1) {
                    let g = d + this.imageAnchorX_, m = f + this.imageAnchorY_;
                    zt(a, g, m, 1, 1, h, -g, -m), o.save(), o.transform.apply(o, a), o.translate(g, m), o.scale(this.imageScale_[0], this.imageScale_[1]), o.drawImage(this.image_, this.imageOriginX_, this.imageOriginY_, this.imageWidth_, this.imageHeight_, -this.imageAnchorX_, -this.imageAnchorY_, this.imageWidth_, this.imageHeight_), o.restore()
                } else o.drawImage(this.image_, this.imageOriginX_, this.imageOriginY_, this.imageWidth_, this.imageHeight_, d, f, this.imageWidth_, this.imageHeight_)
            }
            this.imageOpacity_ != 1 && (o.globalAlpha = l)
        }

        drawText_(t, e, i, r) {
            if (!this.textState_ || this.text_ === "") return;
            this.textFillState_ && this.setContextFillState_(this.textFillState_), this.textStrokeState_ && this.setContextStrokeState_(this.textStrokeState_), this.setContextTextState_(this.textState_);
            let s = re(t, e, i, r, this.transform_, this.pixelCoordinates_), o = this.context_, a = this.textRotation_;
            for (this.transformRotation_ === 0 && (a -= this.viewRotation_), this.textRotateWithView_ && (a += this.viewRotation_); e < i; e += r) {
                let l = s[e] + this.textOffsetX_, h = s[e + 1] + this.textOffsetY_;
                a !== 0 || this.textScale_[0] != 1 || this.textScale_[1] != 1 ? (o.save(), o.translate(l - this.textOffsetX_, h - this.textOffsetY_), o.rotate(a), o.translate(this.textOffsetX_, this.textOffsetY_), o.scale(this.textScale_[0], this.textScale_[1]), this.textStrokeState_ && o.strokeText(this.text_, 0, 0), this.textFillState_ && o.fillText(this.text_, 0, 0), o.restore()) : (this.textStrokeState_ && o.strokeText(this.text_, l, h), this.textFillState_ && o.fillText(this.text_, l, h))
            }
        }

        moveToLineTo_(t, e, i, r, s) {
            let o = this.context_, a = re(t, e, i, r, this.transform_, this.pixelCoordinates_);
            o.moveTo(a[0], a[1]);
            let l = a.length;
            s && (l -= 2);
            for (let h = 2; h < l; h += 2) o.lineTo(a[h], a[h + 1]);
            return s && o.closePath(), i
        }

        drawRings_(t, e, i, r) {
            for (let s = 0, o = i.length; s < o; ++s) e = this.moveToLineTo_(t, e, i[s], r, !0);
            return e
        }

        drawCircle(t) {
            if (this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_)), !!yt(this.extent_, t.getExtent())) {
                if (this.fillState_ || this.strokeState_) {
                    this.fillState_ && this.setContextFillState_(this.fillState_), this.strokeState_ && this.setContextStrokeState_(this.strokeState_);
                    let e = Ku(t, this.transform_, this.pixelCoordinates_), i = e[2] - e[0], r = e[3] - e[1],
                        s = Math.sqrt(i * i + r * r), o = this.context_;
                    o.beginPath(), o.arc(e[0], e[1], s, 0, 2 * Math.PI), this.fillState_ && o.fill(), this.strokeState_ && o.stroke()
                }
                this.text_ !== "" && this.drawText_(t.getCenter(), 0, 2, 2)
            }
        }

        setStyle(t) {
            this.setFillStrokeStyle(t.getFill(), t.getStroke()), this.setImageStyle(t.getImage()), this.setTextStyle(t.getText())
        }

        setTransform(t) {
            this.transform_ = t
        }

        drawGeometry(t) {
            switch (t.getType()) {
                case"Point":
                    this.drawPoint(t);
                    break;
                case"LineString":
                    this.drawLineString(t);
                    break;
                case"Polygon":
                    this.drawPolygon(t);
                    break;
                case"MultiPoint":
                    this.drawMultiPoint(t);
                    break;
                case"MultiLineString":
                    this.drawMultiLineString(t);
                    break;
                case"MultiPolygon":
                    this.drawMultiPolygon(t);
                    break;
                case"GeometryCollection":
                    this.drawGeometryCollection(t);
                    break;
                case"Circle":
                    this.drawCircle(t);
                    break;
                default:
            }
        }

        drawFeature(t, e) {
            let i = e.getGeometryFunction()(t);
            i && (this.setStyle(e), this.drawGeometry(i))
        }

        drawGeometryCollection(t) {
            let e = t.getGeometriesArray();
            for (let i = 0, r = e.length; i < r; ++i) this.drawGeometry(e[i])
        }

        drawPoint(t) {
            this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_));
            let e = t.getFlatCoordinates(), i = t.getStride();
            this.image_ && this.drawImages_(e, 0, e.length, i), this.text_ !== "" && this.drawText_(e, 0, e.length, i)
        }

        drawMultiPoint(t) {
            this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_));
            let e = t.getFlatCoordinates(), i = t.getStride();
            this.image_ && this.drawImages_(e, 0, e.length, i), this.text_ !== "" && this.drawText_(e, 0, e.length, i)
        }

        drawLineString(t) {
            if (this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_)), !!yt(this.extent_, t.getExtent())) {
                if (this.strokeState_) {
                    this.setContextStrokeState_(this.strokeState_);
                    let e = this.context_, i = t.getFlatCoordinates();
                    e.beginPath(), this.moveToLineTo_(i, 0, i.length, t.getStride(), !1), e.stroke()
                }
                if (this.text_ !== "") {
                    let e = t.getFlatMidpoint();
                    this.drawText_(e, 0, 2, 2)
                }
            }
        }

        drawMultiLineString(t) {
            this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_));
            let e = t.getExtent();
            if (yt(this.extent_, e)) {
                if (this.strokeState_) {
                    this.setContextStrokeState_(this.strokeState_);
                    let i = this.context_, r = t.getFlatCoordinates(), s = 0, o = t.getEnds(), a = t.getStride();
                    i.beginPath();
                    for (let l = 0, h = o.length; l < h; ++l) s = this.moveToLineTo_(r, s, o[l], a, !1);
                    i.stroke()
                }
                if (this.text_ !== "") {
                    let i = t.getFlatMidpoints();
                    this.drawText_(i, 0, i.length, 2)
                }
            }
        }

        drawPolygon(t) {
            if (this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_)), !!yt(this.extent_, t.getExtent())) {
                if (this.strokeState_ || this.fillState_) {
                    this.fillState_ && this.setContextFillState_(this.fillState_), this.strokeState_ && this.setContextStrokeState_(this.strokeState_);
                    let e = this.context_;
                    e.beginPath(), this.drawRings_(t.getOrientedFlatCoordinates(), 0, t.getEnds(), t.getStride()), this.fillState_ && e.fill(), this.strokeState_ && e.stroke()
                }
                if (this.text_ !== "") {
                    let e = t.getFlatInteriorPoint();
                    this.drawText_(e, 0, 2, 2)
                }
            }
        }

        drawMultiPolygon(t) {
            if (this.squaredTolerance_ && (t = t.simplifyTransformed(this.squaredTolerance_, this.userTransform_)), !!yt(this.extent_, t.getExtent())) {
                if (this.strokeState_ || this.fillState_) {
                    this.fillState_ && this.setContextFillState_(this.fillState_), this.strokeState_ && this.setContextStrokeState_(this.strokeState_);
                    let e = this.context_, i = t.getOrientedFlatCoordinates(), r = 0, s = t.getEndss(),
                        o = t.getStride();
                    e.beginPath();
                    for (let a = 0, l = s.length; a < l; ++a) {
                        let h = s[a];
                        r = this.drawRings_(i, r, h, o)
                    }
                    this.fillState_ && e.fill(), this.strokeState_ && e.stroke()
                }
                if (this.text_ !== "") {
                    let e = t.getFlatInteriorPoints();
                    this.drawText_(e, 0, e.length, 2)
                }
            }
        }

        setContextFillState_(t) {
            let e = this.context_, i = this.contextFillState_;
            i ? i.fillStyle != t.fillStyle && (i.fillStyle = t.fillStyle, e.fillStyle = t.fillStyle) : (e.fillStyle = t.fillStyle, this.contextFillState_ = {fillStyle: t.fillStyle})
        }

        setContextStrokeState_(t) {
            let e = this.context_, i = this.contextStrokeState_;
            i ? (i.lineCap != t.lineCap && (i.lineCap = t.lineCap, e.lineCap = t.lineCap), Vt(i.lineDash, t.lineDash) || e.setLineDash(i.lineDash = t.lineDash), i.lineDashOffset != t.lineDashOffset && (i.lineDashOffset = t.lineDashOffset, e.lineDashOffset = t.lineDashOffset), i.lineJoin != t.lineJoin && (i.lineJoin = t.lineJoin, e.lineJoin = t.lineJoin), i.lineWidth != t.lineWidth && (i.lineWidth = t.lineWidth, e.lineWidth = t.lineWidth), i.miterLimit != t.miterLimit && (i.miterLimit = t.miterLimit, e.miterLimit = t.miterLimit), i.strokeStyle != t.strokeStyle && (i.strokeStyle = t.strokeStyle, e.strokeStyle = t.strokeStyle)) : (e.lineCap = t.lineCap, e.setLineDash(t.lineDash), e.lineDashOffset = t.lineDashOffset, e.lineJoin = t.lineJoin, e.lineWidth = t.lineWidth, e.miterLimit = t.miterLimit, e.strokeStyle = t.strokeStyle, this.contextStrokeState_ = {
                lineCap: t.lineCap,
                lineDash: t.lineDash,
                lineDashOffset: t.lineDashOffset,
                lineJoin: t.lineJoin,
                lineWidth: t.lineWidth,
                miterLimit: t.miterLimit,
                strokeStyle: t.strokeStyle
            })
        }

        setContextTextState_(t) {
            let e = this.context_, i = this.contextTextState_, r = t.textAlign ? t.textAlign : qi;
            i ? (i.font != t.font && (i.font = t.font, e.font = t.font), i.textAlign != r && (i.textAlign = r, e.textAlign = r), i.textBaseline != t.textBaseline && (i.textBaseline = t.textBaseline, e.textBaseline = t.textBaseline)) : (e.font = t.font, e.textAlign = r, e.textBaseline = t.textBaseline, this.contextTextState_ = {
                font: t.font,
                textAlign: r,
                textBaseline: t.textBaseline
            })
        }

        setFillStrokeStyle(t, e) {
            if (!t) this.fillState_ = null; else {
                let i = t.getColor();
                this.fillState_ = {fillStyle: ae(i || Ot)}
            }
            if (!e) this.strokeState_ = null; else {
                let i = e.getColor(), r = e.getLineCap(), s = e.getLineDash(), o = e.getLineDashOffset(),
                    a = e.getLineJoin(), l = e.getWidth(), h = e.getMiterLimit(), c = s || se;
                this.strokeState_ = {
                    lineCap: r !== void 0 ? r : qe,
                    lineDash: this.pixelRatio_ === 1 ? c : c.map(u => u * this.pixelRatio_),
                    lineDashOffset: (o || oe) * this.pixelRatio_,
                    lineJoin: a !== void 0 ? a : He,
                    lineWidth: (l !== void 0 ? l : wi) * this.pixelRatio_,
                    miterLimit: h !== void 0 ? h : xi,
                    strokeStyle: ae(i || Ei)
                }
            }
        }

        setImageStyle(t) {
            let e;
            if (!t || !(e = t.getSize())) {
                this.image_ = null;
                return
            }
            let i = t.getPixelRatio(this.pixelRatio_), r = t.getAnchor(), s = t.getOrigin();
            this.image_ = t.getImage(this.pixelRatio_), this.imageAnchorX_ = r[0] * i, this.imageAnchorY_ = r[1] * i, this.imageHeight_ = e[1] * i, this.imageOpacity_ = t.getOpacity(), this.imageOriginX_ = s[0], this.imageOriginY_ = s[1], this.imageRotateWithView_ = t.getRotateWithView(), this.imageRotation_ = t.getRotation();
            let o = t.getScaleArray();
            this.imageScale_ = [o[0] * this.pixelRatio_ / i, o[1] * this.pixelRatio_ / i], this.imageWidth_ = e[0] * i
        }

        setTextStyle(t) {
            if (!t) this.text_ = ""; else {
                let e = t.getFill();
                if (!e) this.textFillState_ = null; else {
                    let f = e.getColor();
                    this.textFillState_ = {fillStyle: ae(f || Ot)}
                }
                let i = t.getStroke();
                if (!i) this.textStrokeState_ = null; else {
                    let f = i.getColor(), g = i.getLineCap(), m = i.getLineDash(), p = i.getLineDashOffset(),
                        _ = i.getLineJoin(), y = i.getWidth(), C = i.getMiterLimit();
                    this.textStrokeState_ = {
                        lineCap: g !== void 0 ? g : qe,
                        lineDash: m || se,
                        lineDashOffset: p || oe,
                        lineJoin: _ !== void 0 ? _ : He,
                        lineWidth: y !== void 0 ? y : wi,
                        miterLimit: C !== void 0 ? C : xi,
                        strokeStyle: ae(f || Ei)
                    }
                }
                let r = t.getFont(), s = t.getOffsetX(), o = t.getOffsetY(), a = t.getRotateWithView(),
                    l = t.getRotation(), h = t.getScaleArray(), c = t.getText(), u = t.getTextAlign(),
                    d = t.getTextBaseline();
                this.textState_ = {
                    font: r !== void 0 ? r : oo,
                    textAlign: u !== void 0 ? u : qi,
                    textBaseline: d !== void 0 ? d : Cn
                }, this.text_ = c !== void 0 ? Array.isArray(c) ? c.reduce((f, g, m) => f += m % 2 ? " " : g, "") : c : "", this.textOffsetX_ = s !== void 0 ? this.pixelRatio_ * s : 0, this.textOffsetY_ = o !== void 0 ? this.pixelRatio_ * o : 0, this.textRotateWithView_ = a !== void 0 ? a : !1, this.textRotation_ = l !== void 0 ? l : 0, this.textScale_ = [this.pixelRatio_ * h[0], this.pixelRatio_ * h[1]]
            }
        }
    }, Sg = sc
});
var oc = v(() => {
    Po();
    es()
});

function Lg(n, t, e, i, r, s, o) {
    let a = n[0] * We, l = n[1] * We, h = gt(a, l);
    h.imageSmoothingEnabled = !1;
    let c = h.canvas, u = new Sg(h, We, r, null, o), d = e.length, f = Math.floor((256 * 256 * 256 - 1) / d), g = {};
    for (let p = 1; p <= d; ++p) {
        let _ = e[p - 1], y = _.getStyleFunction() || i;
        if (!y) continue;
        let C = y(_, s);
        if (!C) continue;
        Array.isArray(C) || (C = [C]);
        let T = (p * f).toString(16).padStart(7, "#00000");
        for (let R = 0, A = C.length; R < A; ++R) {
            let b = C[R], O = b.getGeometryFunction()(_);
            if (!O || !yt(r, O.getExtent())) continue;
            let W = b.clone(), Z = W.getFill();
            Z && Z.setColor(T);
            let it = W.getStroke();
            it && (it.setColor(T), it.setLineDash(null)), W.setText(void 0);
            let j = b.getImage();
            if (j) {
                let P = j.getImageSize();
                if (!P) continue;
                let N = gt(P[0], P[1], void 0, {alpha: !1}), nt = N.canvas;
                N.fillStyle = T, N.fillRect(0, 0, nt.width, nt.height), W.setImage(new nn({
                    img: nt,
                    anchor: j.getAnchor(),
                    anchorXUnits: "pixels",
                    anchorYUnits: "pixels",
                    offset: j.getOrigin(),
                    opacity: 1,
                    size: j.getSize(),
                    scale: j.getScale(),
                    rotation: j.getRotation(),
                    rotateWithView: j.getRotateWithView()
                }))
            }
            let mt = W.getZIndex() || 0, Y = g[mt];
            Y || (Y = {}, g[mt] = Y, Y.Polygon = [], Y.Circle = [], Y.LineString = [], Y.Point = []);
            let F = O.getType();
            if (F === "GeometryCollection") {
                let P = O.getGeometriesArrayRecursive();
                for (let N = 0, nt = P.length; N < nt; ++N) {
                    let at = P[N];
                    Y[at.getType().replace("Multi", "")].push(at, W)
                }
            } else Y[F.replace("Multi", "")].push(O, W)
        }
    }
    let m = Object.keys(g).map(Number).sort(de);
    for (let p = 0, _ = m.length; p < _; ++p) {
        let y = g[m[p]];
        for (let C in y) {
            let w = y[C];
            for (let T = 0, R = w.length; T < R; T += 2) {
                u.setStyle(w[T + 1]);
                for (let A = 0, b = t.length; A < b; ++A) u.setTransform(t[A]), u.drawGeometry(w[T])
            }
        }
    }
    return h.getImageData(0, 0, c.width, c.height)
}

function bg(n, t, e) {
    let i = [];
    if (e) {
        let r = Math.floor(Math.round(n[0]) * We), s = Math.floor(Math.round(n[1]) * We),
            o = (ot(r, 0, e.width - 1) + ot(s, 0, e.height - 1) * e.width) * 4, a = e.data[o], l = e.data[o + 1],
            c = e.data[o + 2] + 256 * (l + 256 * a), u = Math.floor((256 * 256 * 256 - 1) / t.length);
        c && c % u === 0 && i.push(t[c / u - 1])
    }
    return i
}

var We, Ag = v(() => {
    Ig();
    oc();
    Ct();
    xt();
    te();
    rt();
    We = .5
});

function Pg(n, t) {
    return parseInt(K(n), 10) - parseInt(K(t), 10)
}

function Og(n, t) {
    let e = No(n, t);
    return e * e
}

function No(n, t) {
    return Up * n / t
}

function jp(n, t, e, i, r) {
    let s = e.getFill(), o = e.getStroke();
    if (s || o) {
        let l = n.getBuilder(e.getZIndex(), "Circle");
        l.setFillStrokeStyle(s, o), l.drawCircle(t, i)
    }
    let a = e.getText();
    if (a && a.getText()) {
        let l = (r || n).getBuilder(e.getZIndex(), "Text");
        l.setTextStyle(a), l.drawText(t, i)
    }
}

function ac(n, t, e, i, r, s, o) {
    let a = !1, l = e.getImage();
    if (l) {
        let h = l.getImageState();
        h == ht.LOADED || h == ht.ERROR ? l.unlistenImageChange(r) : (h == ht.IDLE && l.load(), l.listenImageChange(r), a = !0)
    }
    return Bp(n, t, e, i, s, o), a
}

function Bp(n, t, e, i, r, s) {
    let o = e.getGeometryFunction()(t);
    if (!o) return;
    let a = o.simplifyTransformed(i, r);
    if (e.getRenderer()) Fg(n, a, e, t); else {
        let h = Mg[a.getType()];
        h(n, a, e, t, s)
    }
}

function Fg(n, t, e, i) {
    if (t.getType() == "GeometryCollection") {
        let s = t.getGeometries();
        for (let o = 0, a = s.length; o < a; ++o) Fg(n, s[o], e, i);
        return
    }
    n.getBuilder(e.getZIndex(), "Default").drawCustom(t, i, e.getRenderer(), e.getHitDetectionRenderer())
}

function Kp(n, t, e, i, r) {
    let s = t.getGeometriesArray(), o, a;
    for (o = 0, a = s.length; o < a; ++o) {
        let l = Mg[s[o].getType()];
        l(n, s[o], e, i, r)
    }
}

function Vp(n, t, e, i, r) {
    let s = e.getStroke();
    if (s) {
        let a = n.getBuilder(e.getZIndex(), "LineString");
        a.setFillStrokeStyle(null, s), a.drawLineString(t, i)
    }
    let o = e.getText();
    if (o && o.getText()) {
        let a = (r || n).getBuilder(e.getZIndex(), "Text");
        a.setTextStyle(o), a.drawText(t, i)
    }
}

function Zp(n, t, e, i, r) {
    let s = e.getStroke();
    if (s) {
        let a = n.getBuilder(e.getZIndex(), "LineString");
        a.setFillStrokeStyle(null, s), a.drawMultiLineString(t, i)
    }
    let o = e.getText();
    if (o && o.getText()) {
        let a = (r || n).getBuilder(e.getZIndex(), "Text");
        a.setTextStyle(o), a.drawText(t, i)
    }
}

function qp(n, t, e, i, r) {
    let s = e.getFill(), o = e.getStroke();
    if (o || s) {
        let l = n.getBuilder(e.getZIndex(), "Polygon");
        l.setFillStrokeStyle(s, o), l.drawMultiPolygon(t, i)
    }
    let a = e.getText();
    if (a && a.getText()) {
        let l = (r || n).getBuilder(e.getZIndex(), "Text");
        l.setTextStyle(a), l.drawText(t, i)
    }
}

function Hp(n, t, e, i, r) {
    let s = e.getImage(), o = e.getText(), a;
    if (s) {
        if (s.getImageState() != ht.LOADED) return;
        let l = n;
        if (r) {
            let c = s.getDeclutterMode();
            if (c !== "none") if (l = r, c === "obstacle") {
                let u = n.getBuilder(e.getZIndex(), "Image");
                u.setImageStyle(s, a), u.drawPoint(t, i)
            } else o && o.getText() && (a = {})
        }
        let h = l.getBuilder(e.getZIndex(), "Image");
        h.setImageStyle(s, a), h.drawPoint(t, i)
    }
    if (o && o.getText()) {
        let l = n;
        r && (l = r);
        let h = l.getBuilder(e.getZIndex(), "Text");
        h.setTextStyle(o, a), h.drawText(t, i)
    }
}

function $p(n, t, e, i, r) {
    let s = e.getImage(), o = e.getText(), a;
    if (s) {
        if (s.getImageState() != ht.LOADED) return;
        let l = n;
        if (r) {
            let c = s.getDeclutterMode();
            if (c !== "none") if (l = r, c === "obstacle") {
                let u = n.getBuilder(e.getZIndex(), "Image");
                u.setImageStyle(s, a), u.drawMultiPoint(t, i)
            } else o && o.getText() && (a = {})
        }
        let h = l.getBuilder(e.getZIndex(), "Image");
        h.setImageStyle(s, a), h.drawMultiPoint(t, i)
    }
    if (o && o.getText()) {
        let l = n;
        r && (l = r);
        let h = l.getBuilder(e.getZIndex(), "Text");
        h.setTextStyle(o, a), h.drawText(t, i)
    }
}

function Jp(n, t, e, i, r) {
    let s = e.getFill(), o = e.getStroke();
    if (s || o) {
        let l = n.getBuilder(e.getZIndex(), "Polygon");
        l.setFillStrokeStyle(s, o), l.drawPolygon(t, i)
    }
    let a = e.getText();
    if (a && a.getText()) {
        let l = (r || n).getBuilder(e.getZIndex(), "Text");
        l.setTextStyle(a), l.drawText(t, i)
    }
}

var Up, Mg, Dg = v(() => {
    mr();
    wt();
    Up = .5, Mg = {
        Point: Hp,
        LineString: Vp,
        Polygon: Jp,
        MultiPoint: $p,
        MultiLineString: Zp,
        MultiPolygon: qp,
        GeometryCollection: Kp,
        Circle: jp
    }
});
var lc, kg, Ng = v(() => {
    yg();
    lh();
    Rg();
    $n();
    Xs();
    Ag();
    De();
    rt();
    te();
    Dg();
    Ct();
    Yt();
    wt();
    _i();
    lc = class extends Ro {
        constructor(t) {
            super(t), this.boundHandleStyleImageChange_ = this.handleStyleImageChange_.bind(this), this.animatingOrInteracting_, this.hitDetectionImageData_ = null, this.renderedFeatures_ = null, this.renderedRevision_ = -1, this.renderedResolution_ = NaN, this.renderedExtent_ = Tt(), this.wrappedRenderedExtent_ = Tt(), this.renderedRotation_, this.renderedCenter_ = null, this.renderedProjection_ = null, this.renderedRenderOrder_ = null, this.replayGroup_ = null, this.replayGroupChanged = !0, this.declutterExecutorGroup = null, this.clipping = !0, this.compositionContext_ = null, this.opacity_ = 1
        }

        renderWorlds(t, e, i) {
            let r = e.extent, s = e.viewState, o = s.center, a = s.resolution, l = s.projection, h = s.rotation,
                c = l.getExtent(), u = this.getLayer().getSource(), d = e.pixelRatio, f = e.viewHints,
                g = !(f[Pt.ANIMATING] || f[Pt.INTERACTING]), m = this.compositionContext_,
                p = Math.round(e.size[0] * d), _ = Math.round(e.size[1] * d), y = u.getWrapX() && l.canWrapX(),
                C = y ? $(c) : null, w = y ? Math.ceil((r[2] - c[2]) / C) + 1 : 1,
                T = y ? Math.floor((r[0] - c[0]) / C) : 0;
            do {
                let R = this.getRenderTransform(o, a, h, d, p, _, T * C);
                t.execute(m, 1, R, h, g, void 0, i)
            } while (++T < w)
        }

        setupCompositionContext_() {
            if (this.opacity_ !== 1) {
                let t = gt(this.context.canvas.width, this.context.canvas.height, ah);
                this.compositionContext_ = t
            } else this.compositionContext_ = this.context
        }

        releaseCompositionContext_() {
            if (this.opacity_ !== 1) {
                let t = this.context.globalAlpha;
                this.context.globalAlpha = this.opacity_, this.context.drawImage(this.compositionContext_.canvas, 0, 0), this.context.globalAlpha = t, En(this.compositionContext_), ah.push(this.compositionContext_.canvas), this.compositionContext_ = null
            }
        }

        renderDeclutter(t) {
            this.declutterExecutorGroup && (this.setupCompositionContext_(), this.renderWorlds(this.declutterExecutorGroup, t, t.declutterTree), this.releaseCompositionContext_())
        }

        renderFrame(t, e) {
            let i = t.pixelRatio, r = t.layerStatesArray[t.layerIndex];
            kc(this.pixelTransform, 1 / i, 1 / i), Un(this.inversePixelTransform, this.pixelTransform);
            let s = Rs(this.pixelTransform);
            this.useContainer(e, s, this.getBackground(t));
            let o = this.context, a = o.canvas, l = this.replayGroup_, h = this.declutterExecutorGroup,
                c = l && !l.isEmpty() || h && !h.isEmpty();
            if (!c && !(this.getLayer().hasListener(Jt.PRERENDER) || this.getLayer().hasListener(Jt.POSTRENDER))) return null;
            let u = Math.round(t.size[0] * i), d = Math.round(t.size[1] * i);
            a.width != u || a.height != d ? (a.width = u, a.height = d, a.style.transform !== s && (a.style.transform = s)) : this.containerReused || o.clearRect(0, 0, u, d), this.preRender(o, t);
            let f = t.viewState, g = f.projection;
            this.opacity_ = r.opacity, this.setupCompositionContext_();
            let m = !1;
            if (c && r.extent && this.clipping) {
                let p = ve(r.extent, g);
                c = yt(p, t.extent), m = c && !ui(p, t.extent), m && this.clipUnrotated(this.compositionContext_, t, p)
            }
            return c && this.renderWorlds(l, t), m && this.compositionContext_.restore(), this.releaseCompositionContext_(), this.postRender(o, t), this.renderedRotation_ !== f.rotation && (this.renderedRotation_ = f.rotation, this.hitDetectionImageData_ = null), this.container
        }

        getFeatures(t) {
            return new Promise(e => {
                if (!this.hitDetectionImageData_ && !this.animatingOrInteracting_) {
                    let i = [this.context.canvas.width, this.context.canvas.height];
                    _t(this.pixelTransform, i);
                    let r = this.renderedCenter_, s = this.renderedResolution_, o = this.renderedRotation_,
                        a = this.renderedProjection_, l = this.wrappedRenderedExtent_, h = this.getLayer(), c = [],
                        u = i[0] * We, d = i[1] * We;
                    c.push(this.getRenderTransform(r, s, o, We, u, d, 0).slice());
                    let f = h.getSource(), g = a.getExtent();
                    if (f.getWrapX() && a.canWrapX() && !ui(g, l)) {
                        let m = l[0], p = $(g), _ = 0, y;
                        for (; m < g[0];) --_, y = p * _, c.push(this.getRenderTransform(r, s, o, We, u, d, y).slice()), m += p;
                        for (_ = 0, m = l[2]; m > g[2];) ++_, y = p * _, c.push(this.getRenderTransform(r, s, o, We, u, d, y).slice()), m -= p
                    }
                    this.hitDetectionImageData_ = Lg(i, c, this.renderedFeatures_, h.getStyleFunction(), l, s, o)
                }
                e(bg(t, this.renderedFeatures_, this.hitDetectionImageData_))
            })
        }

        forEachFeatureAtCoordinate(t, e, i, r, s) {
            if (!this.replayGroup_) return;
            let o = e.viewState.resolution, a = e.viewState.rotation, l = this.getLayer(), h = {},
                c = function (f, g, m) {
                    let p = K(f), _ = h[p];
                    if (_) {
                        if (_ !== !0 && m < _.distanceSq) {
                            if (m === 0) return h[p] = !0, s.splice(s.lastIndexOf(_), 1), r(f, l, g);
                            _.geometry = g, _.distanceSq = m
                        }
                    } else {
                        if (m === 0) return h[p] = !0, r(f, l, g);
                        s.push(h[p] = {feature: f, layer: l, geometry: g, distanceSq: m, callback: r})
                    }
                }, u, d = [this.replayGroup_];
            return this.declutterExecutorGroup && d.push(this.declutterExecutorGroup), d.some(f => u = f.forEachFeatureAtCoordinate(t, o, a, i, c, f === this.declutterExecutorGroup && e.declutterTree ? e.declutterTree.all().map(g => g.value) : null)), u
        }

        handleFontsChanged() {
            let t = this.getLayer();
            t.getVisible() && this.replayGroup_ && t.changed()
        }

        handleStyleImageChange_(t) {
            this.renderIfReadyAndVisible()
        }

        prepareFrame(t) {
            let e = this.getLayer(), i = e.getSource();
            if (!i) return !1;
            let r = t.viewHints[Pt.ANIMATING], s = t.viewHints[Pt.INTERACTING], o = e.getUpdateWhileAnimating(),
                a = e.getUpdateWhileInteracting();
            if (this.ready && !o && r || !a && s) return this.animatingOrInteracting_ = !0, !0;
            this.animatingOrInteracting_ = !1;
            let l = t.extent, h = t.viewState, c = h.projection, u = h.resolution, d = t.pixelRatio,
                f = e.getRevision(), g = e.getRenderBuffer(), m = e.getRenderOrder();
            m === void 0 && (m = Pg);
            let p = h.center.slice(), _ = jn(l, g * u), y = _.slice(), C = [_.slice()], w = c.getExtent();
            if (i.getWrapX() && c.canWrapX() && !ui(w, t.extent)) {
                let F = $(w), P = Math.max($(_) / 2, F);
                _[0] = w[0] - P, _[2] = w[2] + P, er(p, c);
                let N = Jo(C[0], c);
                N[0] < w[0] && N[2] < w[2] ? C.push([N[0] + F, N[1], N[2] + F, N[3]]) : N[0] > w[0] && N[2] > w[2] && C.push([N[0] - F, N[1], N[2] - F, N[3]])
            }
            if (this.ready && this.renderedResolution_ == u && this.renderedRevision_ == f && this.renderedRenderOrder_ == m && ui(this.wrappedRenderedExtent_, _)) return Vt(this.renderedExtent_, y) || (this.hitDetectionImageData_ = null, this.renderedExtent_ = y), this.renderedCenter_ = p, this.replayGroupChanged = !1, !0;
            this.replayGroup_ = null;
            let T = new Jh(No(u, d), _, u, d), R;
            this.getLayer().getDeclutter() && (R = new Jh(No(u, d), _, u, d));
            let A = _n(), b;
            if (A) {
                for (let F = 0, P = C.length; F < P; ++F) {
                    let N = C[F], nt = yn(N, c);
                    i.loadFeatures(nt, Ca(u, c), A)
                }
                b = Ve(A, c)
            } else for (let F = 0, P = C.length; F < P; ++F) i.loadFeatures(C[F], u, c);
            let O = Og(u, d), W = !0, Z = F => {
                let P, N = F.getStyleFunction() || e.getStyleFunction();
                if (N && (P = N(F, u)), P) {
                    let nt = this.renderFeature(F, O, P, T, b, R);
                    W = W && !nt
                }
            }, it = yn(_, c), j = i.getFeaturesInExtent(it);
            m && j.sort(m);
            for (let F = 0, P = j.length; F < P; ++F) Z(j[F]);
            this.renderedFeatures_ = j, this.ready = W;
            let mt = T.finish(), Y = new rc(_, u, d, i.getOverlaps(), mt, e.getRenderBuffer());
            return R && (this.declutterExecutorGroup = new rc(_, u, d, i.getOverlaps(), R.finish(), e.getRenderBuffer())), this.renderedResolution_ = u, this.renderedRevision_ = f, this.renderedRenderOrder_ = m, this.renderedExtent_ = y, this.wrappedRenderedExtent_ = _, this.renderedCenter_ = p, this.renderedProjection_ = c, this.replayGroup_ = Y, this.hitDetectionImageData_ = null, this.replayGroupChanged = !0, !0
        }

        renderFeature(t, e, i, r, s, o) {
            if (!i) return !1;
            let a = !1;
            if (Array.isArray(i)) for (let l = 0, h = i.length; l < h; ++l) a = ac(r, t, i[l], e, this.boundHandleStyleImageChange_, s, o) || a; else a = ac(r, t, i, e, this.boundHandleStyleImageChange_, s, o);
            return a
        }
    }, kg = lc
});
var Gg = {};
Fi(Gg, {default: () => cc});
var hc, cc, uc = v(() => {
    ag();
    Ng();
    hc = class extends og {
        constructor(t) {
            super(t)
        }

        createRenderer() {
            return new kg(this)
        }
    }, cc = hc
});
var dc, fc, Xg = v(() => {
    Ah();
    rt();
    wt();
    Oe();
    dc = class {
        constructor(t) {
            this.rbush_ = new Sn(t), this.items_ = {}
        }

        insert(t, e) {
            let i = {minX: t[0], minY: t[1], maxX: t[2], maxY: t[3], value: e};
            this.rbush_.insert(i), this.items_[K(e)] = i
        }

        load(t, e) {
            let i = new Array(e.length);
            for (let r = 0, s = e.length; r < s; r++) {
                let o = t[r], a = e[r], l = {minX: o[0], minY: o[1], maxX: o[2], maxY: o[3], value: a};
                i[r] = l, this.items_[K(a)] = l
            }
            this.rbush_.load(i)
        }

        remove(t) {
            let e = K(t), i = this.items_[e];
            return delete this.items_[e], this.rbush_.remove(i) !== null
        }

        update(t, e) {
            let i = this.items_[K(e)], r = [i.minX, i.minY, i.maxX, i.maxY];
            di(r, t) || (this.remove(e), this.insert(t, e))
        }

        getAll() {
            return this.rbush_.all().map(function (e) {
                return e.value
            })
        }

        getInExtent(t) {
            let e = {minX: t[0], minY: t[1], maxX: t[2], maxY: t[3]};
            return this.rbush_.search(e).map(function (r) {
                return r.value
            })
        }

        forEach(t) {
            return this.forEach_(this.getAll(), t)
        }

        forEachInExtent(t, e) {
            return this.forEach_(this.getInExtent(t), e)
        }

        forEach_(t, e) {
            let i;
            for (let r = 0, s = t.length; r < s; r++) if (i = e(t[r]), i) return i;
            return i
        }

        isEmpty() {
            return Pe(this.items_)
        }

        clear() {
            this.rbush_.clear(), this.items_ = {}
        }

        getExtent(t) {
            let e = this.rbush_.toJSON();
            return ge(e.minX, e.minY, e.maxX, e.maxY, t)
        }

        concat(t) {
            this.rbush_.load(t.rbush_.all());
            for (let e in t.items_) this.items_[e] = t.items_[e]
        }
    }, fc = dc
});

function Wg(n, t, e, i) {
    let r = [], s = Tt();
    for (let o = 0, a = e.length; o < a; ++o) {
        let l = e[o];
        s = Bn(n, t, l[0], i), r.push((s[0] + s[2]) / 2, (s[1] + s[3]) / 2), t = l[l.length - 1]
    }
    return r
}

var zg = v(() => {
    rt()
});
var Yg = v(() => {
    Js()
});
var Ug, ms, an, jg = v(() => {
    De();
    rt();
    zr();
    Ct();
    Wa();
    Yt();
    Ba();
    Of();
    zg();
    Ht();
    ji();
    Ug = kt(), ms = class n {
        constructor(t, e, i, r, s, o) {
            this.styleFunction, this.extent_, this.id_ = o, this.type_ = t, this.flatCoordinates_ = e, this.flatInteriorPoints_ = null, this.flatMidpoints_ = null, this.ends_ = i, this.properties_ = s, this.squaredTolerance_, this.stride_ = r, this.simplifiedGeometry_
        }

        get(t) {
            return this.properties_[t]
        }

        getExtent() {
            return this.extent_ || (this.extent_ = this.type_ === "Point" ? bs(this.flatCoordinates_) : Bn(this.flatCoordinates_, 0, this.flatCoordinates_.length, 2)), this.extent_
        }

        getFlatInteriorPoint() {
            if (!this.flatInteriorPoints_) {
                let t = Ee(this.getExtent());
                this.flatInteriorPoints_ = Yr(this.flatCoordinates_, 0, this.ends_, 2, t, 0)
            }
            return this.flatInteriorPoints_
        }

        getFlatInteriorPoints() {
            if (!this.flatInteriorPoints_) {
                let t = ud(this.flatCoordinates_, this.ends_), e = Wg(this.flatCoordinates_, 0, t, 2);
                this.flatInteriorPoints_ = nd(this.flatCoordinates_, 0, t, 2, e)
            }
            return this.flatInteriorPoints_
        }

        getFlatMidpoint() {
            return this.flatMidpoints_ || (this.flatMidpoints_ = gh(this.flatCoordinates_, 0, this.flatCoordinates_.length, 2, .5)), this.flatMidpoints_
        }

        getFlatMidpoints() {
            if (!this.flatMidpoints_) {
                this.flatMidpoints_ = [];
                let t = this.flatCoordinates_, e = 0, i = this.ends_;
                for (let r = 0, s = i.length; r < s; ++r) {
                    let o = i[r], a = gh(t, e, o, 2, .5);
                    Nn(this.flatMidpoints_, a), e = o
                }
            }
            return this.flatMidpoints_
        }

        getId() {
            return this.id_
        }

        getOrientedFlatCoordinates() {
            return this.flatCoordinates_
        }

        getGeometry() {
            return this
        }

        getSimplifiedGeometry(t) {
            return this
        }

        simplifyTransformed(t, e) {
            return this
        }

        getProperties() {
            return this.properties_
        }

        getPropertiesInternal() {
            return this.properties_
        }

        getStride() {
            return this.stride_
        }

        getStyleFunction() {
            return this.styleFunction
        }

        getType() {
            return this.type_
        }

        transform(t) {
            t = ft(t);
            let e = t.getExtent(), i = t.getWorldExtent();
            if (e && i) {
                let r = Lt(i) / Lt(e);
                zt(Ug, i[0], i[3], r, -r, 0, 0, 0), re(this.flatCoordinates_, 0, this.flatCoordinates_.length, 2, Ug, this.flatCoordinates_)
            }
        }

        applyTransform(t) {
            t(this.flatCoordinates_, this.flatCoordinates_, this.stride_)
        }

        clone() {
            return new n(this.type_, this.flatCoordinates_.slice(), this.ends_.slice(), this.stride_, Object.assign({}, this.properties_), this.id_)
        }

        getEnds() {
            return this.ends_
        }

        enableSimplifyTransformed() {
            return this.simplifyTransformed = Es((t, e) => {
                if (t === this.squaredTolerance_) return this.simplifiedGeometry_;
                this.simplifiedGeometry_ = this.clone(), e && this.simplifiedGeometry_.applyTransform(e);
                let i = this.simplifiedGeometry_.getFlatCoordinates(), r;
                switch (this.type_) {
                    case"LineString":
                        i.length = Wr(i, 0, this.simplifiedGeometry_.flatCoordinates_.length, this.simplifiedGeometry_.stride_, t, i, 0), r = [i.length];
                        break;
                    case"MultiLineString":
                        r = [], i.length = Ju(i, 0, this.simplifiedGeometry_.ends_, this.simplifiedGeometry_.stride_, t, i, 0, r);
                        break;
                    case"Polygon":
                        r = [], i.length = Hs(i, 0, this.simplifiedGeometry_.ends_, this.simplifiedGeometry_.stride_, Math.sqrt(t), i, 0, r);
                        break;
                    default:
                }
                return r && (this.simplifiedGeometry_ = new n(this.type_, i, r, 2, this.properties_, this.id_)), this.squaredTolerance_ = t, this.simplifiedGeometry_
            }), this
        }
    };
    ms.prototype.getFlatCoordinates = ms.prototype.getOrientedFlatCoordinates;
    an = ms
});
var Ie, Bg = v(() => {
    Ie = {
        ADDFEATURE: "addfeature",
        CHANGEFEATURE: "changefeature",
        CLEAR: "clear",
        REMOVEFEATURE: "removefeature",
        FEATURESLOADSTART: "featuresloadstart",
        FEATURESLOADEND: "featuresloadend",
        FEATURESLOADERROR: "featuresloaderror"
    }
});

function Kg(n, t) {
    return [[-1 / 0, -1 / 0, 1 / 0, 1 / 0]]
}

var Vg = v(() => {
    Yt()
});

function t_(n, t, e, i, r, s, o) {
    let a = new XMLHttpRequest;
    a.open("GET", typeof n == "function" ? n(e, i, r) : n, !0), t.getType() == "arraybuffer" && (a.responseType = "arraybuffer"), a.withCredentials = Qp, a.onload = function (l) {
        if (!a.status || a.status >= 200 && a.status < 300) {
            let h = t.getType(), c;
            h == "json" ? c = JSON.parse(a.responseText) : h == "text" ? c = a.responseText : h == "xml" ? (c = a.responseXML, c || (c = new DOMParser().parseFromString(a.responseText, "application/xml"))) : h == "arraybuffer" && (c = a.response), c ? s(t.readFeatures(c, {
                extent: e,
                featureProjection: r
            }), t.readProjection(c)) : o()
        } else o()
    }, a.onerror = o, a.send()
}

function gc(n, t) {
    return function (e, i, r, s, o) {
        let a = this;
        t_(n, t, e, i, r, function (l, h) {
            a.addFeatures(l), s !== void 0 && s(l)
        }, o || Me)
    }
}

var Qp, Zg = v(() => {
    Ht();
    Qp = !1
});
var qg = {};
Fi(qg, {VectorSourceEvent: () => ze, default: () => pc});
var ze, mc, pc, _c = v(() => {
    zn();
    br();
    je();
    pt();
    Fn();
    Xg();
    jg();
    Hl();
    Bg();
    Ht();
    Vg();
    Zt();
    rt();
    Ct();
    wt();
    Oe();
    fe();
    Zg();
    ze = class extends Ft {
        constructor(t, e, i) {
            super(t), this.feature = e, this.features = i
        }
    }, mc = class extends xo {
        constructor(t) {
            t = t || {}, super({
                attributions: t.attributions,
                interpolate: !0,
                projection: void 0,
                state: "ready",
                wrapX: t.wrapX !== void 0 ? t.wrapX : !0
            }), this.on, this.once, this.un, this.loader_ = Me, this.format_ = t.format, this.overlaps_ = t.overlaps === void 0 ? !0 : t.overlaps, this.url_ = t.url, t.loader !== void 0 ? this.loader_ = t.loader : this.url_ !== void 0 && (z(this.format_, "`format` must be set when `url` is set"), this.loader_ = gc(this.url_, this.format_)), this.strategy_ = t.strategy !== void 0 ? t.strategy : Kg;
            let e = t.useSpatialIndex !== void 0 ? t.useSpatialIndex : !0;
            this.featuresRtree_ = e ? new fc : null, this.loadedExtentsRtree_ = new fc, this.loadingExtentsCount_ = 0, this.nullGeometryFeatures_ = {}, this.idIndex_ = {}, this.uidIndex_ = {}, this.featureChangeKeys_ = {}, this.featuresCollection_ = null;
            let i, r;
            Array.isArray(t.features) ? r = t.features : t.features && (i = t.features, r = i.getArray()), !e && i === void 0 && (i = new $t(r)), r !== void 0 && this.addFeaturesInternal(r), i !== void 0 && this.bindFeaturesCollection_(i)
        }

        addFeature(t) {
            this.addFeatureInternal(t), this.changed()
        }

        addFeatureInternal(t) {
            let e = K(t);
            if (!this.addToIndex_(e, t)) {
                this.featuresCollection_ && this.featuresCollection_.remove(t);
                return
            }
            this.setupChangeEvents_(e, t);
            let i = t.getGeometry();
            if (i) {
                let r = i.getExtent();
                this.featuresRtree_ && this.featuresRtree_.insert(r, t)
            } else this.nullGeometryFeatures_[e] = t;
            this.dispatchEvent(new ze(Ie.ADDFEATURE, t))
        }

        setupChangeEvents_(t, e) {
            e instanceof an || (this.featureChangeKeys_[t] = [U(e, D.CHANGE, this.handleFeatureChange_, this), U(e, Ae.PROPERTYCHANGE, this.handleFeatureChange_, this)])
        }

        addToIndex_(t, e) {
            let i = !0;
            if (e.getId() !== void 0) {
                let r = String(e.getId());
                if (!(r in this.idIndex_)) this.idIndex_[r] = e; else if (e instanceof an) {
                    let s = this.idIndex_[r];
                    s instanceof an ? Array.isArray(s) ? s.push(e) : this.idIndex_[r] = [s, e] : i = !1
                } else i = !1
            }
            return i && (z(!(t in this.uidIndex_), "The passed `feature` was already added to the source"), this.uidIndex_[t] = e), i
        }

        addFeatures(t) {
            this.addFeaturesInternal(t), this.changed()
        }

        addFeaturesInternal(t) {
            let e = [], i = [], r = [];
            for (let s = 0, o = t.length; s < o; s++) {
                let a = t[s], l = K(a);
                this.addToIndex_(l, a) && i.push(a)
            }
            for (let s = 0, o = i.length; s < o; s++) {
                let a = i[s], l = K(a);
                this.setupChangeEvents_(l, a);
                let h = a.getGeometry();
                if (h) {
                    let c = h.getExtent();
                    e.push(c), r.push(a)
                } else this.nullGeometryFeatures_[l] = a
            }
            if (this.featuresRtree_ && this.featuresRtree_.load(e, r), this.hasListener(Ie.ADDFEATURE)) for (let s = 0, o = i.length; s < o; s++) this.dispatchEvent(new ze(Ie.ADDFEATURE, i[s]))
        }

        bindFeaturesCollection_(t) {
            let e = !1;
            this.addEventListener(Ie.ADDFEATURE, function (i) {
                e || (e = !0, t.push(i.feature), e = !1)
            }), this.addEventListener(Ie.REMOVEFEATURE, function (i) {
                e || (e = !0, t.remove(i.feature), e = !1)
            }), t.addEventListener(Dt.ADD, i => {
                e || (e = !0, this.addFeature(i.element), e = !1)
            }), t.addEventListener(Dt.REMOVE, i => {
                e || (e = !0, this.removeFeature(i.element), e = !1)
            }), this.featuresCollection_ = t
        }

        clear(t) {
            if (t) {
                for (let i in this.featureChangeKeys_) this.featureChangeKeys_[i].forEach(et);
                this.featuresCollection_ || (this.featureChangeKeys_ = {}, this.idIndex_ = {}, this.uidIndex_ = {})
            } else if (this.featuresRtree_) {
                let i = r => {
                    this.removeFeatureInternal(r)
                };
                this.featuresRtree_.forEach(i);
                for (let r in this.nullGeometryFeatures_) this.removeFeatureInternal(this.nullGeometryFeatures_[r])
            }
            this.featuresCollection_ && this.featuresCollection_.clear(), this.featuresRtree_ && this.featuresRtree_.clear(), this.nullGeometryFeatures_ = {};
            let e = new ze(Ie.CLEAR);
            this.dispatchEvent(e), this.changed()
        }

        forEachFeature(t) {
            if (this.featuresRtree_) return this.featuresRtree_.forEach(t);
            this.featuresCollection_ && this.featuresCollection_.forEach(t)
        }

        forEachFeatureAtCoordinateDirect(t, e) {
            let i = [t[0], t[1], t[0], t[1]];
            return this.forEachFeatureInExtent(i, function (r) {
                let s = r.getGeometry();
                if (s instanceof an || s.intersectsCoordinate(t)) return e(r)
            })
        }

        forEachFeatureInExtent(t, e) {
            if (this.featuresRtree_) return this.featuresRtree_.forEachInExtent(t, e);
            this.featuresCollection_ && this.featuresCollection_.forEach(e)
        }

        forEachFeatureIntersectingExtent(t, e) {
            return this.forEachFeatureInExtent(t, function (i) {
                let r = i.getGeometry();
                if (r instanceof an || r.intersectsExtent(t)) {
                    let s = e(i);
                    if (s) return s
                }
            })
        }

        getFeaturesCollection() {
            return this.featuresCollection_
        }

        getFeatures() {
            let t;
            return this.featuresCollection_ ? t = this.featuresCollection_.getArray().slice(0) : this.featuresRtree_ && (t = this.featuresRtree_.getAll(), Pe(this.nullGeometryFeatures_) || Nn(t, Object.values(this.nullGeometryFeatures_))), t
        }

        getFeaturesAtCoordinate(t) {
            let e = [];
            return this.forEachFeatureAtCoordinateDirect(t, function (i) {
                e.push(i)
            }), e
        }

        getFeaturesInExtent(t, e) {
            if (this.featuresRtree_) {
                if (!(e && e.canWrapX() && this.getWrapX())) return this.featuresRtree_.getInExtent(t);
                let r = Yc(t, e);
                return [].concat(...r.map(s => this.featuresRtree_.getInExtent(s)))
            }
            return this.featuresCollection_ ? this.featuresCollection_.getArray().slice(0) : []
        }

        getClosestFeatureToCoordinate(t, e) {
            let i = t[0], r = t[1], s = null, o = [NaN, NaN], a = 1 / 0, l = [-1 / 0, -1 / 0, 1 / 0, 1 / 0];
            return e = e || li, this.featuresRtree_.forEachInExtent(l, function (h) {
                if (e(h)) {
                    let c = h.getGeometry(), u = a;
                    if (a = c instanceof an ? 0 : c.closestPointXY(i, r, o, a), a < u) {
                        s = h;
                        let d = Math.sqrt(a);
                        l[0] = i - d, l[1] = r - d, l[2] = i + d, l[3] = r + d
                    }
                }
            }), s
        }

        getExtent(t) {
            return this.featuresRtree_.getExtent(t)
        }

        getFeatureById(t) {
            let e = this.idIndex_[t.toString()];
            return e !== void 0 ? e : null
        }

        getFeatureByUid(t) {
            let e = this.uidIndex_[t];
            return e !== void 0 ? e : null
        }

        getFormat() {
            return this.format_
        }

        getOverlaps() {
            return this.overlaps_
        }

        getUrl() {
            return this.url_
        }

        handleFeatureChange_(t) {
            let e = t.target, i = K(e), r = e.getGeometry();
            if (!r) i in this.nullGeometryFeatures_ || (this.featuresRtree_ && this.featuresRtree_.remove(e), this.nullGeometryFeatures_[i] = e); else {
                let o = r.getExtent();
                i in this.nullGeometryFeatures_ ? (delete this.nullGeometryFeatures_[i], this.featuresRtree_ && this.featuresRtree_.insert(o, e)) : this.featuresRtree_ && this.featuresRtree_.update(o, e)
            }
            let s = e.getId();
            if (s !== void 0) {
                let o = s.toString();
                this.idIndex_[o] !== e && (this.removeFromIdIndex_(e), this.idIndex_[o] = e)
            } else this.removeFromIdIndex_(e), this.uidIndex_[i] = e;
            this.changed(), this.dispatchEvent(new ze(Ie.CHANGEFEATURE, e))
        }

        hasFeature(t) {
            let e = t.getId();
            return e !== void 0 ? e in this.idIndex_ : K(t) in this.uidIndex_
        }

        isEmpty() {
            return this.featuresRtree_ ? this.featuresRtree_.isEmpty() && Pe(this.nullGeometryFeatures_) : this.featuresCollection_ ? this.featuresCollection_.getLength() === 0 : !0
        }

        loadFeatures(t, e, i) {
            let r = this.loadedExtentsRtree_, s = this.strategy_(t, e, i);
            for (let o = 0, a = s.length; o < a; ++o) {
                let l = s[o];
                r.forEachInExtent(l, function (c) {
                    return ui(c.extent, l)
                }) || (++this.loadingExtentsCount_, this.dispatchEvent(new ze(Ie.FEATURESLOADSTART)), this.loader_.call(this, l, e, i, c => {
                    --this.loadingExtentsCount_, this.dispatchEvent(new ze(Ie.FEATURESLOADEND, void 0, c))
                }, () => {
                    --this.loadingExtentsCount_, this.dispatchEvent(new ze(Ie.FEATURESLOADERROR))
                }), r.insert(l, {extent: l.slice()}))
            }
            this.loading = this.loader_.length < 4 ? !1 : this.loadingExtentsCount_ > 0
        }

        refresh() {
            this.clear(!0), this.loadedExtentsRtree_.clear(), super.refresh()
        }

        removeLoadedExtent(t) {
            let e = this.loadedExtentsRtree_, i;
            e.forEachInExtent(t, function (r) {
                if (di(r.extent, t)) return i = r, !0
            }), i && e.remove(i)
        }

        removeFeature(t) {
            if (!t) return;
            let e = K(t);
            e in this.nullGeometryFeatures_ ? delete this.nullGeometryFeatures_[e] : this.featuresRtree_ && this.featuresRtree_.remove(t), this.removeFeatureInternal(t) && this.changed()
        }

        removeFeatureInternal(t) {
            let e = K(t), i = this.featureChangeKeys_[e];
            if (!i) return;
            i.forEach(et), delete this.featureChangeKeys_[e];
            let r = t.getId();
            return r !== void 0 && delete this.idIndex_[r.toString()], delete this.uidIndex_[e], this.dispatchEvent(new ze(Ie.REMOVEFEATURE, t)), t
        }

        removeFromIdIndex_(t) {
            let e = !1;
            for (let i in this.idIndex_) {
                let r = this.idIndex_[i];
                if (t instanceof an && Array.isArray(r) && r.includes(t)) r.splice(r.indexOf(t), 1); else if (this.idIndex_[i] === t) {
                    delete this.idIndex_[i], e = !0;
                    break
                }
            }
            return e
        }

        setLoader(t) {
            this.loader_ = t
        }

        setUrl(t) {
            z(this.format_, "`format` must be set when `url` is set"), this.url_ = t, this.setLoader(gc(t, this.format_))
        }
    }, pc = mc
});
var Hg = Rc((yc, xc) => {
    (function (n, t) {
        typeof yc == "object" && typeof xc < "u" ? xc.exports = t((dr(), Di(Id)), (es(), Di(Nf)), (Po(), Di(Kf)), (uc(), Di(Gg)), (_c(), Di(qg)), (Js(), Di(ed)), (dh(), Di(Pf)), (Yt(), Di(Au))) : typeof define == "function" && define.amd ? define(["ol/control/Control", "ol/style/Style", "ol/style/Icon", "ol/layer/Vector", "ol/source/Vector", "ol/geom/Point", "ol/Feature", "ol/proj"], t) : (n = typeof globalThis < "u" ? globalThis : n || self).Geocoder = t(n.ol.control.Control, n.ol.style.Style, n.ol.style.Icon, n.ol.layer.Vector, n.ol.source.Vector, n.ol.geom.Point, n.ol.Feature, n.ol.proj)
    })(yc, function (n, t, e, i, r, s, o, a) {
        "use strict";

        function l(L) {
            return L && typeof L == "object" && "default" in L ? L : {default: L}
        }

        function h(L) {
            if (L && L.__esModule) return L;
            var x = Object.create(null);
            return L && Object.keys(L).forEach(function (E) {
                if (E !== "default") {
                    var M = Object.getOwnPropertyDescriptor(L, E);
                    Object.defineProperty(x, E, M.get ? M : {
                        enumerable: !0, get: function () {
                            return L[E]
                        }
                    })
                }
            }), x.default = L, Object.freeze(x)
        }

        var c = l(n), u = l(t), d = l(e), f = l(i), g = l(r), m = l(s), p = l(o), _ = h(a), y = "gcd-container",
            C = "gcd-button-control", w = "gcd-input-query", T = "gcd-input-label", R = "gcd-input-search", A = {
                namespace: "ol-geocoder",
                spin: "gcd-pseudo-rotate",
                hidden: "gcd-hidden",
                address: "gcd-address",
                country: "gcd-country",
                city: "gcd-city",
                road: "gcd-road",
                olControl: "ol-control",
                glass: {
                    container: "gcd-gl-container",
                    control: "gcd-gl-control",
                    button: "gcd-gl-btn",
                    input: "gcd-gl-input",
                    expanded: "gcd-gl-expanded",
                    search: "gcd-gl-search",
                    result: "gcd-gl-result"
                },
                inputText: {
                    container: "gcd-txt-container",
                    control: "gcd-txt-control",
                    label: "gcd-txt-label",
                    input: "gcd-txt-input",
                    search: "gcd-txt-search",
                    icon: "gcd-txt-glass",
                    result: "gcd-txt-result"
                }
            }, b = {containerId: y, buttonControlId: C, inputQueryId: w, inputLabelId: T, inputSearchId: R, cssClasses: A};
        let O = Object.freeze({
                __proto__: null,
                containerId: y,
                buttonControlId: C,
                inputQueryId: w,
                inputLabelId: T,
                inputSearchId: R,
                cssClasses: A,
                default: b
            }), W = "addresschosen", Z = "nominatim", it = "reverse", j = "glass-button", mt = "text-input", Y = "osm",
            F = "mapquest", P = "photon", N = "bing", nt = "opencage", at = {
                provider: Y,
                label: "",
                placeholder: "Search for an address",
                featureStyle: null,
                targetType: j,
                lang: "en-US",
                limit: 5,
                keepOpen: !1,
                preventDefault: !1,
                preventPanning: !1,
                preventMarker: !1,
                defaultFlyResolution: 10,
                debug: !1
            };

        function At(L, x = "Assertion failed") {
            if (!L) throw typeof Error < "u" ? new Error(x) : x
        }

        function I(L) {
            let x = function () {
                if ("performance" in window == 0 && (window.performance = {}), "now" in window.performance == 0) {
                    let E = Date.now();
                    performance.timing && performance.timing.navigationStart && (E = performance.timing.navigationStart), window.performance.now = () => Date.now() - E
                }
                return window.performance.now()
            }().toString(36);
            return L ? L + x : x
        }

        function vt(L) {
            return /^\d+$/u.test(L)
        }

        function q(L, x, E) {
            if (Array.isArray(L)) return void L.forEach(Q => q(Q, x));
            let M = Array.isArray(x) ? x : x.split(/\s+/u), B = M.length;
            for (; B--;) pe(L, M[B]) || ri(L, M[B], E)
        }

        function st(L, x, E) {
            if (Array.isArray(L)) return void L.forEach(Q => st(Q, x, E));
            let M = Array.isArray(x) ? x : x.split(/\s+/u), B = M.length;
            for (; B--;) pe(L, M[B]) && ln(L, M[B], E)
        }

        function pe(L, x) {
            return L.classList ? L.classList.contains(x) : _e(x).test(L.className)
        }

        function Gt(L, x) {
            return L.replace(/\{\s*([\w-]+)\s*\}/gu, (E, M) => {
                let B = x[M] === void 0 ? "" : x[M];
                return String(B).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;")
            })
        }

        function ee(L, x) {
            let E;
            if (Array.isArray(L)) {
                if (E = document.createElement(L[0]), L[1].id && (E.id = L[1].id), L[1].classname && (E.className = L[1].classname), L[1].attr) {
                    let {attr: B} = L[1];
                    if (Array.isArray(B)) {
                        let Q = -1;
                        for (; ++Q < B.length;) E.setAttribute(B[Q].name, B[Q].value)
                    } else E.setAttribute(B.name, B.value)
                }
            } else E = document.createElement(L);
            E.innerHTML = x;
            let M = document.createDocumentFragment();
            for (; E.childNodes[0];) M.append(E.childNodes[0]);
            return E.append(M), E
        }

        function _e(L) {
            return new RegExp(`(^|\\s+) ${L} (\\s+|$)`, "u")
        }

        function ri(L, x, E) {
            L.classList ? L.classList.add(x) : L.className = `${L.className} ${x}`.trim(), E && vt(E) && window.setTimeout(() => ln(L, x), E)
        }

        function ln(L, x, E) {
            L.classList ? L.classList.remove(x) : L.className = L.className.replace(_e(x), " ").trim(), E && vt(E) && window.setTimeout(() => ri(L, x), E)
        }

        let tt = O.cssClasses;

        class Le {
            constructor(x) {
                this.options = x, this.els = this.createControl()
            }

            createControl() {
                let x, E, M;
                return this.options.targetType === mt ? (E = `${tt.namespace} ${tt.inputText.container}`, x = ee(["div", {
                    id: O.containerId,
                    classname: E
                }], Le.input), M = {
                    container: x,
                    control: x.querySelector(`.${tt.inputText.control}`),
                    label: x.querySelector(`.${tt.inputText.label}`),
                    input: x.querySelector(`.${tt.inputText.input}`),
                    search: x.querySelector(`.${tt.inputText.search}`),
                    result: x.querySelector(`.${tt.inputText.result}`)
                }, M.label.innerHTML = this.options.label) : (E = `${tt.namespace} ${tt.glass.container}`, x = ee(["div", {
                    id: O.containerId,
                    classname: E
                }], Le.glass), M = {
                    container: x,
                    control: x.querySelector(`.${tt.glass.control}`),
                    button: x.querySelector(`.${tt.glass.button}`),
                    input: x.querySelector(`.${tt.glass.input}`),
                    search: x.querySelector(`.${tt.glass.search}`),
                    result: x.querySelector(`.${tt.glass.result}`)
                }), M.input.placeholder = this.options.placeholder, M
            }
        }

        function Ye(L) {
            return new Promise((x, E) => {
                let M = function (Q, Wt) {
                    return Wt && typeof Wt == "object" && (Q += (/\?/u.test(Q) ? "&" : "?") + Pi(Wt)), Q
                }(L.url, L.data), B = {method: "GET", mode: "cors", credentials: "same-origin"};
                L.jsonp ? function (Q, Wt, Rt) {
                    let {head: be} = document, Kt = document.createElement("script"),
                        si = `f${Math.round(Math.random() * Date.now())}`;
                    Kt.setAttribute("src", `${Q + (Q.indexOf("?") > 0 ? "&" : "?") + Wt}=${si}`), window[si] = Pn => {
                        window[si] = void 0, setTimeout(() => be.removeChild(Kt), 0), Rt(Pn)
                    }, be.append(Kt)
                }(M, L.callbackName, x) : fetch(M, B).then(Q => Q.json()).then(x).catch(E)
            })
        }

        function Pi(L) {
            return Object.keys(L).reduce((x, E) => (x.push(typeof L[E] == "object" ? Pi(L[E]) : `${encodeURIComponent(E)}=${encodeURIComponent(L[E])}`), x), []).join("&")
        }

        Le.glass = `
  <div class="${tt.glass.control} ${tt.olControl}">
    <button type="button" id="${O.buttonControlId}" class="${tt.glass.button}"></button>
    <input type="text" id="${O.inputQueryId}" class="${tt.glass.input}" autocomplete="off" placeholder="Search ...">
    <a id="${O.inputSearchId}" class="${tt.glass.search} ${tt.hidden}"></a>
  </div>
  <ul class="${tt.glass.result}"></ul>
`, Le.input = `
  <div class="${tt.inputText.control}">
    <label type="button" id="${O.inputSearchId}" class="${tt.inputText.label}"></label>
    <input type="text" id="${O.inputQueryId}" class="${tt.inputText.input}" autocomplete="off" placeholder="Search ...">
    <span class="${tt.inputText.icon}"></span>
    <button type="button" id="${O.inputSearchId}" class="${tt.inputText.search} ${tt.hidden}"></button>
  </div>
  <ul class="${tt.inputText.result}"></ul>
`;

        class Ue {
            constructor() {
                this.settings = {
                    url: "https://photon.komoot.io/api/",
                    params: {q: "", limit: 10, lang: "en"},
                    langs: ["de", "it", "fr", "en"]
                }
            }

            getParameters(x) {
                return x.lang = x.lang.toLowerCase(), {
                    url: this.settings.url,
                    params: {
                        q: x.query,
                        limit: x.limit || this.settings.params.limit,
                        lang: this.settings.langs.includes(x.lang) ? x.lang : this.settings.params.lang
                    }
                }
            }

            handleResponse(x) {
                return x.features.length === 0 ? [] : x.features.map(E => ({
                    lon: E.geometry.coordinates[0],
                    lat: E.geometry.coordinates[1],
                    address: {
                        name: E.properties.name,
                        postcode: E.properties.postcode,
                        city: E.properties.city,
                        state: E.properties.state,
                        country: E.properties.country
                    },
                    original: {formatted: E.properties.name, details: E.properties}
                }))
            }
        }

        class bn {
            constructor(x) {
                this.settings = {
                    url: "https://nominatim.openstreetmap.org/search", ...x,
                    params: {
                        q: "",
                        format: "json",
                        addressdetails: 1,
                        limit: 10,
                        countrycodes: "",
                        viewbox: "",
                        "accept-language": "en-US"
                    }
                }
            }

            getParameters(x) {
                return {
                    url: this.settings.url,
                    params: {
                        q: x.query,
                        format: this.settings.params.format,
                        addressdetails: this.settings.params.addressdetails,
                        limit: x.limit || this.settings.params.limit,
                        countrycodes: x.countrycodes || this.settings.params.countrycodes,
                        viewbox: x.viewbox || this.settings.params.viewbox,
                        "accept-language": x.lang || this.settings.params["accept-language"]
                    }
                }
            }

            handleResponse(x) {
                return x.length === 0 ? [] : x.map(E => ({
                    lon: E.lon,
                    lat: E.lat,
                    bbox: E.boundingbox,
                    address: {
                        name: E.display_name,
                        road: E.address.road || "",
                        houseNumber: E.address.house_number || "",
                        postcode: E.address.postcode,
                        city: E.address.city || E.address.town,
                        state: E.address.state,
                        country: E.address.country
                    },
                    original: {formatted: E.display_name, details: E.address}
                }))
            }
        }

        class An {
            constructor() {
                this.settings = {
                    url: "https://open.mapquestapi.com/nominatim/v1/search.php",
                    params: {
                        q: "",
                        key: "",
                        format: "json",
                        addressdetails: 1,
                        limit: 10,
                        countrycodes: "",
                        "accept-language": "en-US"
                    }
                }
            }

            getParameters(x) {
                return {
                    url: this.settings.url,
                    params: {
                        q: x.query,
                        key: x.key,
                        format: "json",
                        addressdetails: 1,
                        limit: x.limit || this.settings.params.limit,
                        countrycodes: x.countrycodes || this.settings.params.countrycodes,
                        "accept-language": x.lang || this.settings.params["accept-language"]
                    }
                }
            }

            handleResponse(x) {
                return x.length === 0 ? [] : x.map(E => ({
                    lon: E.lon,
                    lat: E.lat,
                    address: {
                        name: E.address.neighbourhood || "",
                        road: E.address.road || "",
                        postcode: E.address.postcode,
                        city: E.address.city || E.address.town,
                        state: E.address.state,
                        country: E.address.country
                    },
                    original: {formatted: E.display_name, details: E.address}
                }))
            }
        }

        class Mn {
            constructor() {
                this.settings = {
                    url: "https://dev.virtualearth.net/REST/v1/Locations",
                    callbackName: "jsonp",
                    params: {query: "", key: "", includeNeighborhood: 0, maxResults: 10}
                }
            }

            getParameters(x) {
                return {
                    url: this.settings.url,
                    callbackName: this.settings.callbackName,
                    params: {
                        query: x.query,
                        key: x.key,
                        includeNeighborhood: x.includeNeighborhood || this.settings.params.includeNeighborhood,
                        maxResults: x.maxResults || this.settings.params.maxResults
                    }
                }
            }

            handleResponse(x) {
                let {resources: E} = x.resourceSets[0];
                return E.length === 0 ? [] : E.map(M => ({
                    lon: M.point.coordinates[1],
                    lat: M.point.coordinates[0],
                    address: {name: M.name},
                    original: {formatted: M.address.formattedAddress, details: M.address}
                }))
            }
        }

        class Oi {
            constructor() {
                this.settings = {
                    url: "https://api.opencagedata.com/geocode/v1/json?",
                    params: {q: "", key: "", limit: 10, countrycode: "", pretty: 1, no_annotations: 1}
                }
            }

            getParameters(x) {
                return {
                    url: this.settings.url,
                    params: {
                        q: x.query,
                        key: x.key,
                        limit: x.limit || this.settings.params.limit,
                        countrycode: x.countrycodes || this.settings.params.countrycodes
                    }
                }
            }

            handleResponse(x) {
                return x.results.length === 0 ? [] : x.results.map(E => ({
                    lon: E.geometry.lng,
                    lat: E.geometry.lat,
                    address: {
                        name: E.components.house_number || "",
                        road: E.components.road || "",
                        postcode: E.components.postcode,
                        city: E.components.city || E.components.town,
                        state: E.components.state,
                        country: E.components.country
                    },
                    original: {formatted: E.formatted, details: E.components}
                }))
            }
        }

        let Mt = O.cssClasses;

        class Bt {
            constructor(x, E) {
                this.Base = x, this.layerName = I("geocoder-layer-"), this.layer = new f.default({
                    name: this.layerName,
                    source: new g.default,
                    displayInLayerSwitcher: !1
                }), this.options = x.options, this.options.provider = typeof this.options.provider == "string" ? this.options.provider.toLowerCase() : this.options.provider, this.provider = this.newProvider(), this.els = E, this.lastQuery = "", this.container = this.els.container, this.registeredListeners = {mapClick: !1}, this.setListeners()
            }

            setListeners() {
                let x = E => {
                    E.stopPropagation(), pe(this.els.control, Mt.glass.expanded) ? this.collapse() : this.expand()
                };
                this.els.input.addEventListener("keypress", E => {
                    let M = E.target.value.trim();
                    (E.key ? E.key === "Enter" : E.which ? E.which === 13 : E.keyCode && E.keyCode === 13) && (E.preventDefault(), this.query(M))
                }, !1), this.els.input.addEventListener("click", E => E.stopPropagation(), !1), this.els.input.addEventListener("input", E => {
                    E.target.value.trim().length !== 0 ? st(this.els.search, Mt.hidden) : q(this.els.search, Mt.hidden)
                }, !1), this.els.search.addEventListener("click", () => {
                    this.els.input.focus(), this.query(this.els.input.value)
                }, !1), this.options.targetType === j && this.els.button.addEventListener("click", x, !1)
            }

            query(x) {
                this.provider || (this.provider = this.newProvider());
                let E = this.provider.getParameters({
                    query: x,
                    key: this.options.key,
                    lang: this.options.lang,
                    countrycodes: this.options.countrycodes,
                    viewbox: this.options.viewbox,
                    limit: this.options.limit
                });
                if (this.lastQuery === x && this.els.result.firstChild) return;
                this.lastQuery = x, this.clearResults(), q(this.els.search, Mt.spin);
                let M = {url: E.url, data: E.params};
                E.callbackName && (M.jsonp = !0, M.callbackName = E.callbackName), Ye(M).then(B => {
                    this.options.debug && console.info(B), st(this.els.search, Mt.spin);
                    let Q = this.provider.handleResponse(B);
                    Q && (this.createList(Q), this.listenMapClick())
                }).catch(() => {
                    st(this.els.search, Mt.spin);
                    let B = ee("li", "<h5>Error! No internet connection?</h5>");
                    this.els.result.append(B)
                })
            }

            createList(x) {
                let E = this.els.result;
                x.forEach(M => {
                    let B;
                    if (this.options.provider === Y ? B = `<span class="${Mt.road}">${M.address.name}</span>` : B = this.addressTemplate(M.address), x.length == 1) this.chosen(M, B, M.address, M.original); else {
                        let Q = ee("li", `<a href="#">${B}</a>`);
                        Q.addEventListener("click", Wt => {
                            Wt.preventDefault(), this.chosen(M, B, M.address, M.original)
                        }, !1), E.append(Q)
                    }
                })
            }

            chosen(x, E, M, B) {
                let Q = this.Base.getMap(), Wt = [Number.parseFloat(x.lon), Number.parseFloat(x.lat)],
                    Rt = Q.getView().getProjection(), be = _.transform(Wt, "EPSG:4326", Rt), {bbox: Kt} = x;
                Kt && (Kt = _.transformExtent([parseFloat(Kt[2]), parseFloat(Kt[0]), parseFloat(Kt[3]), parseFloat(Kt[1])], "EPSG:4326", Rt));
                let si = {formatted: E, details: M, original: B};
                if (this.options.keepOpen === !1 && this.clearResults(!0), this.options.preventDefault === !0 || this.options.preventMarker === !0) this.Base.dispatchEvent({
                    type: W,
                    address: si,
                    coordinate: be,
                    bbox: Kt,
                    place: x
                }); else {
                    let Pn = this.createFeature(be, si);
                    this.Base.dispatchEvent({type: W, address: si, feature: Pn, coordinate: be, bbox: Kt, place: x})
                }
                this.options.preventDefault !== !0 && this.options.preventPanning !== !0 && (Kt ? Q.getView().fit(Kt, {duration: 500}) : Q.getView().animate({
                    center: be,
                    resolution: this.options.defaultFlyResolution,
                    duration: 500
                }))
            }

            createFeature(x) {
                let E = new p.default(new m.default(x));
                return this.addLayer(), E.setStyle(this.options.featureStyle), E.setId(I("geocoder-ft-")), this.getSource().addFeature(E), E
            }

            addressTemplate(x) {
                let E = [];
                return x.name && E.push(['<span class="', Mt.road, '">{name}</span>'].join("")), (x.road || x.building || x.house_number) && E.push(['<span class="', Mt.road, '">{building} {road} {house_number}</span>'].join("")), (x.city || x.town || x.village) && E.push(['<span class="', Mt.city, '">{postcode} {city} {town} {village}</span>'].join("")), (x.state || x.country) && E.push(['<span class="', Mt.country, '">{state} {country}</span>'].join("")), Gt(E.join("<br>"), x)
            }

            newProvider() {
                switch (this.options.provider) {
                    case Y:
                        return new bn(this.options);
                    case F:
                        return new An;
                    case P:
                        return new Ue;
                    case N:
                        return new Mn;
                    case nt:
                        return new Oi;
                    default:
                        return this.options.provider
                }
            }

            expand() {
                st(this.els.input, Mt.spin), q(this.els.control, Mt.glass.expanded), window.setTimeout(() => this.els.input.focus(), 100), this.listenMapClick()
            }

            collapse() {
                this.els.input.value = "", this.els.input.blur(), q(this.els.search, Mt.hidden), st(this.els.control, Mt.glass.expanded), this.clearResults()
            }

            listenMapClick() {
                if (this.registeredListeners.mapClick) return;
                let x = this, E = this.Base.getMap().getTargetElement();
                this.registeredListeners.mapClick = !0, E.addEventListener("click", {
                    handleEvent(M) {
                        x.clearResults(!0), E.removeEventListener(M.type, this, !1), x.registeredListeners.mapClick = !1
                    }
                }, !1)
            }

            clearResults(x) {
                x && this.options.targetType === j ? this.collapse() : function (E) {
                    for (; E.firstChild;) E.firstChild.remove()
                }(this.els.result)
            }

            getSource() {
                return this.layer.getSource()
            }

            addLayer() {
                let x = !1, E = this.Base.getMap();
                E.getLayers().forEach(M => {
                    M === this.layer && (x = !0)
                }), x || E.addLayer(this.layer)
            }
        }

        class Xt extends c.default {
            constructor(x = Z, E) {
                At(typeof x == "string", "@param `type` should be string!"), At(x === Z || x === it, `@param 'type' should be '${Z}'
      or '${it}'!`);
                let M = {
                    ...at,
                    featureStyle: [new u.default({
                        image: new d.default({
                            scale: .7,
                            src: "//cdn.rawgit.com/jonataswalker/map-utils/master/images/marker.png"
                        })
                    })], ...E
                }, B, Q, Wt = new Le(M);
                if (x === Z && (B = Wt.els.container), super({element: B, ...M}), !(this instanceof Xt)) return new Xt;
                this.options = M, this.container = B, x === Z && (Q = new Bt(this, Wt.els), this.layer = Q.layer)
            }

            getLayer() {
                return this.layer
            }

            getSource() {
                return this.getLayer().getSource()
            }

            setProvider(x) {
                this.options.provider = x
            }

            setProviderKey(x) {
                this.options.key = x
            }
        }

        return Xt
    })
});
Fe();
zn();
br();
xs();
Ht();
wt();
De();
rt();
oa();
lr();
_i();
var Ja = class extends Dn {
    constructor(t) {
        super(), this.map_ = t
    }

    dispatchRenderEvent(t, e) {
        H()
    }

    calculateMatrices2D(t) {
        let e = t.viewState, i = t.coordinateToPixelTransform, r = t.pixelToCoordinateTransform;
        zt(i, t.size[0] / 2, t.size[1] / 2, 1 / e.resolution, -1 / e.resolution, -e.rotation, -e.center[0], -e.center[1]), Un(r, i)
    }

    forEachFeatureAtCoordinate(t, e, i, r, s, o, a, l) {
        let h, c = e.viewState;

        function u(w, T, R, A) {
            return s.call(o, T, w ? R : null, A)
        }

        let d = c.projection, f = er(t.slice(), d), g = [[0, 0]];
        if (d.canWrapX() && r) {
            let w = d.getExtent(), T = $(w);
            g.push([-T, 0], [T, 0])
        }
        let m = e.layerStatesArray, p = m.length, _ = [], y = [];
        for (let w = 0; w < g.length; w++) for (let T = p - 1; T >= 0; --T) {
            let R = m[T], A = R.layer;
            if (A.hasRenderer() && Ur(R, c) && a.call(l, A)) {
                let b = A.getRenderer(), O = A.getSource();
                if (b && O) {
                    let W = O.getWrapX() ? f : t, Z = u.bind(null, R.managed);
                    y[0] = W[0] + g[w][0], y[1] = W[1] + g[w][1], h = b.forEachFeatureAtCoordinate(y, e, i, Z, _)
                }
                if (h) return h
            }
        }
        if (_.length === 0) return;
        let C = 1 / _.length;
        return _.forEach((w, T) => w.distanceSq += T * C), _.sort((w, T) => w.distanceSq - T.distanceSq), _.some(w => h = w.callback(w.feature, w.layer, w.geometry)), h
    }

    hasFeatureAtCoordinate(t, e, i, r, s, o) {
        return this.forEachFeatureAtCoordinate(t, e, i, r, li, this, s, o) !== void 0
    }

    getMap() {
        return this.map_
    }

    renderFrame(t) {
        H()
    }

    flushDeclutterItems(t) {
    }

    scheduleExpireIconCache(t) {
        Hn.canExpireCache() && t.postRenderFunctions.push(Fm)
    }
};

function Fm(n, t) {
    Hn.expire()
}

var gd = Ja;
Fn();
tl();
$n();
cr();
Ti();
lr();
fe();
te();
var al = class extends gd {
    constructor(t) {
        super(t), this.fontChangeListenerKey_ = U(Ze, Ae.PROPERTYCHANGE, t.redrawText.bind(t)), this.element_ = document.createElement("div");
        let e = this.element_.style;
        e.position = "absolute", e.width = "100%", e.height = "100%", e.zIndex = "0", this.element_.className = Zi + " ol-layers";
        let i = t.getViewport();
        i.insertBefore(this.element_, i.firstChild || null), this.children_ = [], this.renderedVisible_ = !0, this.declutterLayers_ = []
    }

    dispatchRenderEvent(t, e) {
        let i = this.getMap();
        if (i.hasListener(t)) {
            let r = new ro(t, void 0, e);
            i.dispatchEvent(r)
        }
    }

    disposeInternal() {
        et(this.fontChangeListenerKey_), this.element_.parentNode.removeChild(this.element_), super.disposeInternal()
    }

    renderFrame(t) {
        if (!t) {
            this.renderedVisible_ && (this.element_.style.display = "none", this.renderedVisible_ = !1);
            return
        }
        this.calculateMatrices2D(t), this.dispatchRenderEvent(Jt.PRECOMPOSE, t);
        let e = t.layerStatesArray.sort(function (o, a) {
            return o.zIndex - a.zIndex
        }), i = t.viewState;
        this.children_.length = 0;
        let r = this.declutterLayers_;
        r.length = 0;
        let s = null;
        for (let o = 0, a = e.length; o < a; ++o) {
            let l = e[o];
            t.layerIndex = o;
            let h = l.layer, c = h.getSourceState();
            if (!Ur(l, i) || c != "ready" && c != "undefined") {
                h.unrender();
                continue
            }
            let u = h.render(t, s);
            u && (u !== s && (this.children_.push(u), s = u), "getDeclutter" in h && r.push(h))
        }
        this.flushDeclutterItems(t), _d(this.element_, this.children_), this.dispatchRenderEvent(Jt.POSTCOMPOSE, t), this.renderedVisible_ || (this.element_.style.display = "", this.renderedVisible_ = !0), this.scheduleExpireIconCache(t)
    }

    flushDeclutterItems(t) {
        let e = this.declutterLayers_;
        for (let i = e.length - 1; i >= 0; --i) e[i].renderDeclutter(t);
        e.length = 0
    }
}, wd = al;
pt();
lr();
ha();
zn();
br();
je();
pt();
Fn();
Zt();
Oe();
rt();
wt();
fe();
var Ne = class extends Ft {
    constructor(t, e) {
        super(t), this.layer = e
    }
}, ll = {LAYERS: "layers"}, hl = class n extends Gs {
    constructor(t) {
        t = t || {};
        let e = Object.assign({}, t);
        delete e.layers;
        let i = t.layers;
        super(e), this.on, this.once, this.un, this.layersListenerKeys_ = [], this.listenerKeys_ = {}, this.addChangeListener(ll.LAYERS, this.handleLayersChanged_), i ? Array.isArray(i) ? i = new $t(i.slice(), {unique: !0}) : z(typeof i.getArray == "function", "Expected `layers` to be an array or a `Collection`") : i = new $t(void 0, {unique: !0}), this.setLayers(i)
    }

    handleLayerChange_() {
        this.changed()
    }

    handleLayersChanged_() {
        this.layersListenerKeys_.forEach(et), this.layersListenerKeys_.length = 0;
        let t = this.getLayers();
        this.layersListenerKeys_.push(U(t, Dt.ADD, this.handleLayersAdd_, this), U(t, Dt.REMOVE, this.handleLayersRemove_, this));
        for (let i in this.listenerKeys_) this.listenerKeys_[i].forEach(et);
        Be(this.listenerKeys_);
        let e = t.getArray();
        for (let i = 0, r = e.length; i < r; i++) {
            let s = e[i];
            this.registerLayerListeners_(s), this.dispatchEvent(new Ne("addlayer", s))
        }
        this.changed()
    }

    registerLayerListeners_(t) {
        let e = [U(t, Ae.PROPERTYCHANGE, this.handleLayerChange_, this), U(t, D.CHANGE, this.handleLayerChange_, this)];
        t instanceof n && e.push(U(t, "addlayer", this.handleLayerGroupAdd_, this), U(t, "removelayer", this.handleLayerGroupRemove_, this)), this.listenerKeys_[K(t)] = e
    }

    handleLayerGroupAdd_(t) {
        this.dispatchEvent(new Ne("addlayer", t.layer))
    }

    handleLayerGroupRemove_(t) {
        this.dispatchEvent(new Ne("removelayer", t.layer))
    }

    handleLayersAdd_(t) {
        let e = t.element;
        this.registerLayerListeners_(e), this.dispatchEvent(new Ne("addlayer", e)), this.changed()
    }

    handleLayersRemove_(t) {
        let e = t.element, i = K(e);
        this.listenerKeys_[i].forEach(et), delete this.listenerKeys_[i], this.dispatchEvent(new Ne("removelayer", e)), this.changed()
    }

    getLayers() {
        return this.get(ll.LAYERS)
    }

    setLayers(t) {
        let e = this.getLayers();
        if (e) {
            let i = e.getArray();
            for (let r = 0, s = i.length; r < s; ++r) this.dispatchEvent(new Ne("removelayer", i[r]))
        }
        this.set(ll.LAYERS, t)
    }

    getLayersArray(t) {
        return t = t !== void 0 ? t : [], this.getLayers().forEach(function (e) {
            e.getLayersArray(t)
        }), t
    }

    getLayerStatesArray(t) {
        let e = t !== void 0 ? t : [], i = e.length;
        this.getLayers().forEach(function (o) {
            o.getLayerStatesArray(e)
        });
        let r = this.getLayerState(), s = r.zIndex;
        !t && r.zIndex === void 0 && (s = 0);
        for (let o = i, a = e.length; o < a; o++) {
            let l = e[o];
            l.opacity *= r.opacity, l.visible = l.visible && r.visible, l.maxResolution = Math.min(l.maxResolution, r.maxResolution), l.minResolution = Math.max(l.minResolution, r.minResolution), l.minZoom = Math.max(l.minZoom, r.minZoom), l.maxZoom = Math.min(l.maxZoom, r.maxZoom), r.extent !== void 0 && (l.extent !== void 0 ? l.extent = Xi(l.extent, r.extent) : l.extent = r.extent), l.zIndex === void 0 && (l.zIndex = s)
        }
        return e
    }

    getSourceState() {
        return "ready"
    }
}, Kr = hl;
je();
var cl = class extends Ft {
    constructor(t, e, i) {
        super(t), this.map = e, this.frameState = i !== void 0 ? i : null
    }
}, Hi = cl;
var ul = class extends Hi {
    constructor(t, e, i, r, s, o) {
        super(t, e, s), this.originalEvent = i, this.pixel_ = null, this.coordinate_ = null, this.dragging = r !== void 0 ? r : !1, this.activePointers = o
    }

    get pixel() {
        return this.pixel_ || (this.pixel_ = this.map.getEventPixel(this.originalEvent)), this.pixel_
    }

    set pixel(t) {
        this.pixel_ = t
    }

    get coordinate() {
        return this.coordinate_ || (this.coordinate_ = this.map.getCoordinateFromPixel(this.pixel)), this.coordinate_
    }

    set coordinate(t) {
        this.coordinate_ = t
    }

    preventDefault() {
        super.preventDefault(), "preventDefault" in this.originalEvent && this.originalEvent.preventDefault()
    }

    stopPropagation() {
        super.stopPropagation(), "stopPropagation" in this.originalEvent && this.originalEvent.stopPropagation()
    }
}, $e = ul;
pt();
pt();
var dt = {
    SINGLECLICK: "singleclick",
    CLICK: D.CLICK,
    DBLCLICK: D.DBLCLICK,
    POINTERDRAG: "pointerdrag",
    POINTERMOVE: "pointermove",
    POINTERDOWN: "pointerdown",
    POINTERUP: "pointerup",
    POINTEROVER: "pointerover",
    POINTEROUT: "pointerout",
    POINTERENTER: "pointerenter",
    POINTERLEAVE: "pointerleave",
    POINTERCANCEL: "pointercancel"
};
var $i = {
    POINTERMOVE: "pointermove",
    POINTERDOWN: "pointerdown",
    POINTERUP: "pointerup",
    POINTEROVER: "pointerover",
    POINTEROUT: "pointerout",
    POINTERENTER: "pointerenter",
    POINTERLEAVE: "pointerleave",
    POINTERCANCEL: "pointercancel"
};
Lr();
ci();
fe();
var dl = class extends ki {
    constructor(t, e) {
        super(t), this.map_ = t, this.clickTimeoutId_, this.emulateClicks_ = !1, this.dragging_ = !1, this.dragListenerKeys_ = [], this.moveTolerance_ = e === void 0 ? 1 : e, this.down_ = null;
        let i = this.map_.getViewport();
        this.activePointers_ = [], this.trackedTouches_ = {}, this.element_ = i, this.pointerdownListenerKey_ = U(i, $i.POINTERDOWN, this.handlePointerDown_, this), this.originalPointerMoveEvent_, this.relayedListenerKey_ = U(i, $i.POINTERMOVE, this.relayMoveEvent_, this), this.boundHandleTouchMove_ = this.handleTouchMove_.bind(this), this.element_.addEventListener(D.TOUCHMOVE, this.boundHandleTouchMove_, vs ? {passive: !1} : !1)
    }

    emulateClick_(t) {
        let e = new $e(dt.CLICK, this.map_, t);
        this.dispatchEvent(e), this.clickTimeoutId_ !== void 0 ? (clearTimeout(this.clickTimeoutId_), this.clickTimeoutId_ = void 0, e = new $e(dt.DBLCLICK, this.map_, t), this.dispatchEvent(e)) : this.clickTimeoutId_ = setTimeout(() => {
            this.clickTimeoutId_ = void 0;
            let i = new $e(dt.SINGLECLICK, this.map_, t);
            this.dispatchEvent(i)
        }, 250)
    }

    updateActivePointers_(t) {
        let e = t, i = e.pointerId;
        if (e.type == dt.POINTERUP || e.type == dt.POINTERCANCEL) {
            delete this.trackedTouches_[i];
            for (let r in this.trackedTouches_) if (this.trackedTouches_[r].target !== e.target) {
                delete this.trackedTouches_[r];
                break
            }
        } else (e.type == dt.POINTERDOWN || e.type == dt.POINTERMOVE) && (this.trackedTouches_[i] = e);
        this.activePointers_ = Object.values(this.trackedTouches_)
    }

    handlePointerUp_(t) {
        this.updateActivePointers_(t);
        let e = new $e(dt.POINTERUP, this.map_, t, void 0, void 0, this.activePointers_);
        this.dispatchEvent(e), this.emulateClicks_ && !e.defaultPrevented && !this.dragging_ && this.isMouseActionButton_(t) && this.emulateClick_(this.down_), this.activePointers_.length === 0 && (this.dragListenerKeys_.forEach(et), this.dragListenerKeys_.length = 0, this.dragging_ = !1, this.down_ = null)
    }

    isMouseActionButton_(t) {
        return t.button === 0
    }

    handlePointerDown_(t) {
        this.emulateClicks_ = this.activePointers_.length === 0, this.updateActivePointers_(t);
        let e = new $e(dt.POINTERDOWN, this.map_, t, void 0, void 0, this.activePointers_);
        if (this.dispatchEvent(e), this.down_ = new PointerEvent(t.type, t), Object.defineProperty(this.down_, "target", {
            writable: !1,
            value: t.target
        }), this.dragListenerKeys_.length === 0) {
            let i = this.map_.getOwnerDocument();
            this.dragListenerKeys_.push(U(i, dt.POINTERMOVE, this.handlePointerMove_, this), U(i, dt.POINTERUP, this.handlePointerUp_, this), U(this.element_, dt.POINTERCANCEL, this.handlePointerUp_, this)), this.element_.getRootNode && this.element_.getRootNode() !== i && this.dragListenerKeys_.push(U(this.element_.getRootNode(), dt.POINTERUP, this.handlePointerUp_, this))
        }
    }

    handlePointerMove_(t) {
        if (this.isMoving_(t)) {
            this.updateActivePointers_(t), this.dragging_ = !0;
            let e = new $e(dt.POINTERDRAG, this.map_, t, this.dragging_, void 0, this.activePointers_);
            this.dispatchEvent(e)
        }
    }

    relayMoveEvent_(t) {
        this.originalPointerMoveEvent_ = t;
        let e = !!(this.down_ && this.isMoving_(t));
        this.dispatchEvent(new $e(dt.POINTERMOVE, this.map_, t, e))
    }

    handleTouchMove_(t) {
        let e = this.originalPointerMoveEvent_;
        (!e || e.defaultPrevented) && (typeof t.cancelable != "boolean" || t.cancelable === !0) && t.preventDefault()
    }

    isMoving_(t) {
        return this.dragging_ || Math.abs(t.clientX - this.down_.clientX) > this.moveTolerance_ || Math.abs(t.clientY - this.down_.clientY) > this.moveTolerance_
    }

    disposeInternal() {
        this.relayedListenerKey_ && (et(this.relayedListenerKey_), this.relayedListenerKey_ = null), this.element_.removeEventListener(D.TOUCHMOVE, this.boundHandleTouchMove_), this.pointerdownListenerKey_ && (et(this.pointerdownListenerKey_), this.pointerdownListenerKey_ = null), this.dragListenerKeys_.forEach(et), this.dragListenerKeys_.length = 0, this.element_ = null, super.disposeInternal()
    }
}, Td = dl;
fl();
var Ut = {LAYERGROUP: "layergroup", SIZE: "size", TARGET: "target", VIEW: "view"};
Fn();
$n();
pt();
Zt();
Oe();
var Vr = 1 / 0, gl = class {
    constructor(t, e) {
        this.priorityFunction_ = t, this.keyFunction_ = e, this.elements_ = [], this.priorities_ = [], this.queuedElements_ = {}
    }

    clear() {
        this.elements_.length = 0, this.priorities_.length = 0, Be(this.queuedElements_)
    }

    dequeue() {
        let t = this.elements_, e = this.priorities_, i = t[0];
        t.length == 1 ? (t.length = 0, e.length = 0) : (t[0] = t.pop(), e[0] = e.pop(), this.siftUp_(0));
        let r = this.keyFunction_(i);
        return delete this.queuedElements_[r], i
    }

    enqueue(t) {
        z(!(this.keyFunction_(t) in this.queuedElements_), "Tried to enqueue an `element` that was already added to the queue");
        let e = this.priorityFunction_(t);
        return e != Vr ? (this.elements_.push(t), this.priorities_.push(e), this.queuedElements_[this.keyFunction_(t)] = !0, this.siftDown_(0, this.elements_.length - 1), !0) : !1
    }

    getCount() {
        return this.elements_.length
    }

    getLeftChildIndex_(t) {
        return t * 2 + 1
    }

    getRightChildIndex_(t) {
        return t * 2 + 2
    }

    getParentIndex_(t) {
        return t - 1 >> 1
    }

    heapify_() {
        let t;
        for (t = (this.elements_.length >> 1) - 1; t >= 0; t--) this.siftUp_(t)
    }

    isEmpty() {
        return this.elements_.length === 0
    }

    isKeyQueued(t) {
        return t in this.queuedElements_
    }

    isQueued(t) {
        return this.isKeyQueued(this.keyFunction_(t))
    }

    siftUp_(t) {
        let e = this.elements_, i = this.priorities_, r = e.length, s = e[t], o = i[t], a = t;
        for (; t < r >> 1;) {
            let l = this.getLeftChildIndex_(t), h = this.getRightChildIndex_(t), c = h < r && i[h] < i[l] ? h : l;
            e[t] = e[c], i[t] = i[c], t = c
        }
        e[t] = s, i[t] = o, this.siftDown_(a, t)
    }

    siftDown_(t, e) {
        let i = this.elements_, r = this.priorities_, s = i[e], o = r[e];
        for (; e > t;) {
            let a = this.getParentIndex_(e);
            if (r[a] > o) i[e] = i[a], r[e] = r[a], e = a; else break
        }
        i[e] = s, r[e] = o
    }

    reprioritize() {
        let t = this.priorityFunction_, e = this.elements_, i = this.priorities_, r = 0, s = e.length, o, a, l;
        for (a = 0; a < s; ++a) o = e[a], l = t(o), l == Vr ? delete this.queuedElements_[this.keyFunction_(o)] : (i[r] = l, e[r++] = o);
        e.length = r, i.length = r, this.heapify_()
    }
}, vd = gl;
var k = {IDLE: 0, LOADING: 1, LOADED: 2, ERROR: 3, EMPTY: 4};
var ml = class extends vd {
    constructor(t, e) {
        super(function (i) {
            return t.apply(null, i)
        }, function (i) {
            return i[0].getKey()
        }), this.boundHandleTileChange_ = this.handleTileChange.bind(this), this.tileChangeCallback_ = e, this.tilesLoading_ = 0, this.tilesLoadingKeys_ = {}
    }

    enqueue(t) {
        let e = super.enqueue(t);
        return e && t[0].addEventListener(D.CHANGE, this.boundHandleTileChange_), e
    }

    getTilesLoading() {
        return this.tilesLoading_
    }

    handleTileChange(t) {
        let e = t.target, i = e.getState();
        if (i === k.LOADED || i === k.ERROR || i === k.EMPTY) {
            i !== k.ERROR && e.removeEventListener(D.CHANGE, this.boundHandleTileChange_);
            let r = e.getKey();
            r in this.tilesLoadingKeys_ && (delete this.tilesLoadingKeys_[r], --this.tilesLoading_), this.tileChangeCallback_()
        }
    }

    loadMoreTiles(t, e) {
        let i = 0, r, s, o;
        for (; this.tilesLoading_ < t && i < e && this.getCount() > 0;) s = this.dequeue()[0], o = s.getKey(), r = s.getState(), r === k.IDLE && !(o in this.tilesLoadingKeys_) && (this.tilesLoadingKeys_[o] = !0, ++this.tilesLoading_, ++i, s.load())
    }
}, Rd = ml;

function Sd(n, t, e, i, r) {
    if (!n || !(e in n.wantedTiles)) return Vr;
    if (!n.wantedTiles[e][t.getKey()]) return Vr;
    let s = n.viewState.center, o = i[0] - s[0], a = i[1] - s[1];
    return 65536 * Math.log(r) + Math.sqrt(o * o + a * a) / r
}

no();
Xs();
ci();
Ht();
De();
Zt();
rt();
dr();
pt();
cr();
Ct();
te();
var _l = class extends vi {
    constructor(t) {
        t = t || {}, super({
            element: document.createElement("div"),
            render: t.render,
            target: t.target
        }), this.ulElement_ = document.createElement("ul"), this.collapsed_ = t.collapsed !== void 0 ? t.collapsed : !0, this.userCollapsed_ = this.collapsed_, this.overrideCollapsible_ = t.collapsible !== void 0, this.collapsible_ = t.collapsible !== void 0 ? t.collapsible : !0, this.collapsible_ || (this.collapsed_ = !1);
        let e = t.className !== void 0 ? t.className : "ol-attribution",
            i = t.tipLabel !== void 0 ? t.tipLabel : "Attributions",
            r = t.expandClassName !== void 0 ? t.expandClassName : e + "-expand",
            s = t.collapseLabel !== void 0 ? t.collapseLabel : "\u203A",
            o = t.collapseClassName !== void 0 ? t.collapseClassName : e + "-collapse";
        typeof s == "string" ? (this.collapseLabel_ = document.createElement("span"), this.collapseLabel_.textContent = s, this.collapseLabel_.className = o) : this.collapseLabel_ = s;
        let a = t.label !== void 0 ? t.label : "i";
        typeof a == "string" ? (this.label_ = document.createElement("span"), this.label_.textContent = a, this.label_.className = r) : this.label_ = a;
        let l = this.collapsible_ && !this.collapsed_ ? this.collapseLabel_ : this.label_;
        this.toggleButton_ = document.createElement("button"), this.toggleButton_.setAttribute("type", "button"), this.toggleButton_.setAttribute("aria-expanded", String(!this.collapsed_)), this.toggleButton_.title = i, this.toggleButton_.appendChild(l), this.toggleButton_.addEventListener(D.CLICK, this.handleClick_.bind(this), !1);
        let h = e + " " + Zi + " " + hr + (this.collapsed_ && this.collapsible_ ? " " + el : "") + (this.collapsible_ ? "" : " ol-uncollapsible"),
            c = this.element;
        c.className = h, c.appendChild(this.toggleButton_), c.appendChild(this.ulElement_), this.renderedAttributions_ = [], this.renderedVisible_ = !0
    }

    collectSourceAttributions_(t) {
        let e = Array.from(new Set(this.getMap().getAllLayers().flatMap(r => r.getAttributions(t)))),
            i = !this.getMap().getAllLayers().some(r => r.getSource() && r.getSource().getAttributionsCollapsible() === !1);
        return this.overrideCollapsible_ || this.setCollapsible(i), e
    }

    updateElement_(t) {
        if (!t) {
            this.renderedVisible_ && (this.element.style.display = "none", this.renderedVisible_ = !1);
            return
        }
        let e = this.collectSourceAttributions_(t), i = e.length > 0;
        if (this.renderedVisible_ != i && (this.element.style.display = i ? "" : "none", this.renderedVisible_ = i), !Vt(e, this.renderedAttributions_)) {
            pd(this.ulElement_);
            for (let r = 0, s = e.length; r < s; ++r) {
                let o = document.createElement("li");
                o.innerHTML = e[r], this.ulElement_.appendChild(o)
            }
            this.renderedAttributions_ = e
        }
    }

    handleClick_(t) {
        t.preventDefault(), this.handleToggle_(), this.userCollapsed_ = this.collapsed_
    }

    handleToggle_() {
        this.element.classList.toggle(el), this.collapsed_ ? nl(this.collapseLabel_, this.label_) : nl(this.label_, this.collapseLabel_), this.collapsed_ = !this.collapsed_, this.toggleButton_.setAttribute("aria-expanded", String(!this.collapsed_))
    }

    getCollapsible() {
        return this.collapsible_
    }

    setCollapsible(t) {
        this.collapsible_ !== t && (this.collapsible_ = t, this.element.classList.toggle("ol-uncollapsible"), this.userCollapsed_ && this.handleToggle_())
    }

    setCollapsed(t) {
        this.userCollapsed_ = t, !(!this.collapsible_ || this.collapsed_ === t) && this.handleToggle_()
    }

    getCollapsed() {
        return this.collapsed_
    }

    render(t) {
        this.updateElement_(t.frameState)
    }
}, Ld = _l;
zn();
dr();
pt();
cr();
Ui();
var yl = class extends vi {
    constructor(t) {
        t = t || {}, super({element: document.createElement("div"), render: t.render, target: t.target});
        let e = t.className !== void 0 ? t.className : "ol-rotate", i = t.label !== void 0 ? t.label : "\u21E7",
            r = t.compassClassName !== void 0 ? t.compassClassName : "ol-compass";
        this.label_ = null, typeof i == "string" ? (this.label_ = document.createElement("span"), this.label_.className = r, this.label_.textContent = i) : (this.label_ = i, this.label_.classList.add(r));
        let s = t.tipLabel ? t.tipLabel : "Reset rotation", o = document.createElement("button");
        o.className = e + "-reset", o.setAttribute("type", "button"), o.title = s, o.appendChild(this.label_), o.addEventListener(D.CLICK, this.handleClick_.bind(this), !1);
        let a = e + " " + Zi + " " + hr, l = this.element;
        l.className = a, l.appendChild(o), this.callResetNorth_ = t.resetNorth ? t.resetNorth : void 0, this.duration_ = t.duration !== void 0 ? t.duration : 250, this.autoHide_ = t.autoHide !== void 0 ? t.autoHide : !0, this.rotation_ = void 0, this.autoHide_ && this.element.classList.add(jr)
    }

    handleClick_(t) {
        t.preventDefault(), this.callResetNorth_ !== void 0 ? this.callResetNorth_() : this.resetNorth_()
    }

    resetNorth_() {
        let e = this.getMap().getView();
        if (!e) return;
        let i = e.getRotation();
        i !== void 0 && (this.duration_ > 0 && i % (2 * Math.PI) !== 0 ? e.animate({
            rotation: 0,
            duration: this.duration_,
            easing: Re
        }) : e.setRotation(0))
    }

    render(t) {
        let e = t.frameState;
        if (!e) return;
        let i = e.viewState.rotation;
        if (i != this.rotation_) {
            let r = "rotate(" + i + "rad)";
            if (this.autoHide_) {
                let s = this.element.classList.contains(jr);
                !s && i === 0 ? this.element.classList.add(jr) : s && i !== 0 && this.element.classList.remove(jr)
            }
            this.label_.style.transform = r
        }
        this.rotation_ = i
    }
}, bd = yl;
dr();
pt();
cr();
Ui();
var xl = class extends vi {
    constructor(t) {
        t = t || {}, super({element: document.createElement("div"), target: t.target});
        let e = t.className !== void 0 ? t.className : "ol-zoom", i = t.delta !== void 0 ? t.delta : 1,
            r = t.zoomInClassName !== void 0 ? t.zoomInClassName : e + "-in",
            s = t.zoomOutClassName !== void 0 ? t.zoomOutClassName : e + "-out",
            o = t.zoomInLabel !== void 0 ? t.zoomInLabel : "+",
            a = t.zoomOutLabel !== void 0 ? t.zoomOutLabel : "\u2013",
            l = t.zoomInTipLabel !== void 0 ? t.zoomInTipLabel : "Zoom in",
            h = t.zoomOutTipLabel !== void 0 ? t.zoomOutTipLabel : "Zoom out", c = document.createElement("button");
        c.className = r, c.setAttribute("type", "button"), c.title = l, c.appendChild(typeof o == "string" ? document.createTextNode(o) : o), c.addEventListener(D.CLICK, this.handleClick_.bind(this, i), !1);
        let u = document.createElement("button");
        u.className = s, u.setAttribute("type", "button"), u.title = h, u.appendChild(typeof a == "string" ? document.createTextNode(a) : a), u.addEventListener(D.CLICK, this.handleClick_.bind(this, -i), !1);
        let d = e + " " + Zi + " " + hr, f = this.element;
        f.className = d, f.appendChild(c), f.appendChild(u), this.duration_ = t.duration !== void 0 ? t.duration : 250
    }

    handleClick_(t, e) {
        e.preventDefault(), this.zoomByDelta_(t)
    }

    zoomByDelta_(t) {
        let i = this.getMap().getView();
        if (!i) return;
        let r = i.getZoom();
        if (r !== void 0) {
            let s = i.getConstrainedZoom(r + t);
            this.duration_ > 0 ? (i.getAnimating() && i.cancelAnimations(), i.animate({
                zoom: s,
                duration: this.duration_,
                easing: Re
            })) : i.setZoom(s)
        }
    }
}, Ad = xl;

function Zr(n) {
    n = n || {};
    let t = new $t;
    return (n.zoom !== void 0 ? n.zoom : !0) && t.push(new Ad(n.zoomOptions)), (n.rotate !== void 0 ? n.rotate : !0) && t.push(new bd(n.rotateOptions)), (n.attribution !== void 0 ? n.attribution : !0) && t.push(new Ld(n.attributionOptions)), t
}

zn();
Fe();
var El = {ACTIVE: "active"};
Ui();
var Cl = class extends St {
    constructor(t) {
        super(), this.on, this.once, this.un, t && t.handleEvent && (this.handleEvent = t.handleEvent), this.map_ = null, this.setActive(!0)
    }

    getActive() {
        return this.get(El.ACTIVE)
    }

    getMap() {
        return this.map_
    }

    handleEvent(t) {
        return !0
    }

    setActive(t) {
        this.set(El.ACTIVE, t)
    }

    setMap(t) {
        this.map_ = t
    }
};

function Md(n, t, e) {
    let i = n.getCenterInternal();
    if (i) {
        let r = [i[0] + t[0], i[1] + t[1]];
        n.animateInternal({duration: e !== void 0 ? e : 250, easing: Xu, center: n.getConstrainedCenter(r)})
    }
}

function fr(n, t, e, i) {
    let r = n.getZoom();
    if (r === void 0) return;
    let s = n.getConstrainedZoom(r + t), o = n.getResolutionForZoom(s);
    n.getAnimating() && n.cancelAnimations(), n.animate({
        resolution: o,
        anchor: e,
        duration: i !== void 0 ? i : 250,
        easing: Re
    })
}

var Qe = Cl;
var wl = class extends Qe {
    constructor(t) {
        super(), t = t || {}, this.delta_ = t.delta ? t.delta : 1, this.duration_ = t.duration !== void 0 ? t.duration : 250
    }

    handleEvent(t) {
        let e = !1;
        if (t.type == dt.DBLCLICK) {
            let i = t.originalEvent, r = t.map, s = t.coordinate, o = i.shiftKey ? -this.delta_ : this.delta_,
                a = r.getView();
            fr(a, o, s, this.duration_), i.preventDefault(), e = !0
        }
        return !e
    }
}, Pd = wl;
var Tl = class extends Qe {
    constructor(t) {
        t = t || {}, super(t), t.handleDownEvent && (this.handleDownEvent = t.handleDownEvent), t.handleDragEvent && (this.handleDragEvent = t.handleDragEvent), t.handleMoveEvent && (this.handleMoveEvent = t.handleMoveEvent), t.handleUpEvent && (this.handleUpEvent = t.handleUpEvent), t.stopDown && (this.stopDown = t.stopDown), this.handlingDownUpSequence = !1, this.targetPointers = []
    }

    getPointerCount() {
        return this.targetPointers.length
    }

    handleDownEvent(t) {
        return !1
    }

    handleDragEvent(t) {
    }

    handleEvent(t) {
        if (!t.originalEvent) return !0;
        let e = !1;
        if (this.updateTrackedPointers_(t), this.handlingDownUpSequence) {
            if (t.type == dt.POINTERDRAG) this.handleDragEvent(t), t.originalEvent.preventDefault(); else if (t.type == dt.POINTERUP) {
                let i = this.handleUpEvent(t);
                this.handlingDownUpSequence = i && this.targetPointers.length > 0
            }
        } else if (t.type == dt.POINTERDOWN) {
            let i = this.handleDownEvent(t);
            this.handlingDownUpSequence = i, e = this.stopDown(i)
        } else t.type == dt.POINTERMOVE && this.handleMoveEvent(t);
        return !e
    }

    handleMoveEvent(t) {
    }

    handleUpEvent(t) {
        return !1
    }

    stopDown(t) {
        return t
    }

    updateTrackedPointers_(t) {
        t.activePointers && (this.targetPointers = t.activePointers)
    }
};

function gr(n) {
    let t = n.length, e = 0, i = 0;
    for (let r = 0; r < t; r++) e += n[r].clientX, i += n[r].clientY;
    return {clientX: e / t, clientY: i / t}
}

var ti = Tl;
Ht();
Ht();
ci();
Zt();

function qr(n) {
    let t = arguments;
    return function (e) {
        let i = !0;
        for (let r = 0, s = t.length; r < s && (i = i && t[r](e), !!i); ++r) ;
        return i
    }
}

var Od = function (n) {
    let t = n.originalEvent;
    return t.altKey && !(t.metaKey || t.ctrlKey) && t.shiftKey
}, Gm = function (n) {
    let t = n.map.getTargetElement(), e = n.map.getOwnerDocument().activeElement;
    return t.contains(e)
}, ao = function (n) {
    return n.map.getTargetElement().hasAttribute("tabindex") ? Gm(n) : !0
}, Fd = li;
var lo = function (n) {
    let t = n.originalEvent;
    return t.button == 0 && !(Oc && Ko && t.ctrlKey)
};
var ho = function (n) {
    let t = n.originalEvent;
    return !t.altKey && !(t.metaKey || t.ctrlKey) && !t.shiftKey
};
var Dd = function (n) {
    let t = n.originalEvent;
    return Ko ? t.metaKey : t.ctrlKey
}, kd = function (n) {
    let t = n.originalEvent;
    return !t.altKey && !(t.metaKey || t.ctrlKey) && t.shiftKey
}, co = function (n) {
    let t = n.originalEvent, e = t.target.tagName;
    return e !== "INPUT" && e !== "SELECT" && e !== "TEXTAREA" && !t.target.isContentEditable
}, uo = function (n) {
    let t = n.originalEvent;
    return z(t !== void 0, "mapBrowserEvent must originate from a pointer event"), t.pointerType == "mouse"
};
var Nd = function (n) {
    let t = n.originalEvent;
    return z(t !== void 0, "mapBrowserEvent must originate from a pointer event"), t.isPrimary && t.button === 0
};
Ui();
_i();
var vl = class extends ti {
    constructor(t) {
        super({stopDown: hi}), t = t || {}, this.kinetic_ = t.kinetic, this.lastCentroid = null, this.lastPointersCount_, this.panning_ = !1;
        let e = t.condition ? t.condition : qr(ho, Nd);
        this.condition_ = t.onFocusOnly ? qr(ao, e) : e, this.noKinetic_ = !1
    }

    handleDragEvent(t) {
        let e = t.map;
        this.panning_ || (this.panning_ = !0, e.getView().beginInteraction());
        let i = this.targetPointers, r = e.getEventPixel(gr(i));
        if (i.length == this.lastPointersCount_) {
            if (this.kinetic_ && this.kinetic_.update(r[0], r[1]), this.lastCentroid) {
                let s = [this.lastCentroid[0] - r[0], r[1] - this.lastCentroid[1]], a = t.map.getView();
                Cu(s, a.getResolution()), tr(s, a.getRotation()), a.adjustCenterInternal(s)
            }
        } else this.kinetic_ && this.kinetic_.begin();
        this.lastCentroid = r, this.lastPointersCount_ = i.length, t.originalEvent.preventDefault()
    }

    handleUpEvent(t) {
        let e = t.map, i = e.getView();
        if (this.targetPointers.length === 0) {
            if (!this.noKinetic_ && this.kinetic_ && this.kinetic_.end()) {
                let r = this.kinetic_.getDistance(), s = this.kinetic_.getAngle(), o = i.getCenterInternal(),
                    a = e.getPixelFromCoordinateInternal(o),
                    l = e.getCoordinateFromPixelInternal([a[0] - r * Math.cos(s), a[1] - r * Math.sin(s)]);
                i.animateInternal({center: i.getConstrainedCenter(l), duration: 500, easing: Re})
            }
            return this.panning_ && (this.panning_ = !1, i.endInteraction()), !1
        }
        return this.kinetic_ && this.kinetic_.begin(), this.lastCentroid = null, !0
    }

    handleDownEvent(t) {
        if (this.targetPointers.length > 0 && this.condition_(t)) {
            let i = t.map.getView();
            return this.lastCentroid = null, i.getAnimating() && i.cancelAnimations(), this.kinetic_ && this.kinetic_.begin(), this.noKinetic_ = this.targetPointers.length > 1, !0
        }
        return !1
    }
}, Gd = vl;
Ht();
Vs();
var Rl = class extends ti {
    constructor(t) {
        t = t || {}, super({stopDown: hi}), this.condition_ = t.condition ? t.condition : Od, this.lastAngle_ = void 0, this.duration_ = t.duration !== void 0 ? t.duration : 250
    }

    handleDragEvent(t) {
        if (!uo(t)) return;
        let e = t.map, i = e.getView();
        if (i.getConstraints().rotation === rr) return;
        let r = e.getSize(), s = t.pixel, o = Math.atan2(r[1] / 2 - s[1], s[0] - r[0] / 2);
        if (this.lastAngle_ !== void 0) {
            let a = o - this.lastAngle_;
            i.adjustRotationInternal(-a)
        }
        this.lastAngle_ = o
    }

    handleUpEvent(t) {
        return uo(t) ? (t.map.getView().endInteraction(this.duration_), !1) : !0
    }

    handleDownEvent(t) {
        return uo(t) && lo(t) && this.condition_(t) ? (t.map.getView().beginInteraction(), this.lastAngle_ = void 0, !0) : !1
    }
}, Xd = Rl;
je();
xs();
Va();
var Sl = class extends Dn {
    constructor(t) {
        super(), this.geometry_ = null, this.element_ = document.createElement("div"), this.element_.style.position = "absolute", this.element_.style.pointerEvents = "auto", this.element_.className = "ol-box " + t, this.map_ = null, this.startPixel_ = null, this.endPixel_ = null
    }

    disposeInternal() {
        this.setMap(null)
    }

    render_() {
        let t = this.startPixel_, e = this.endPixel_, i = "px", r = this.element_.style;
        r.left = Math.min(t[0], e[0]) + i, r.top = Math.min(t[1], e[1]) + i, r.width = Math.abs(e[0] - t[0]) + i, r.height = Math.abs(e[1] - t[1]) + i
    }

    setMap(t) {
        if (this.map_) {
            this.map_.getOverlayContainer().removeChild(this.element_);
            let e = this.element_.style;
            e.left = "inherit", e.top = "inherit", e.width = "inherit", e.height = "inherit"
        }
        this.map_ = t, this.map_ && this.map_.getOverlayContainer().appendChild(this.element_)
    }

    setPixels(t, e) {
        this.startPixel_ = t, this.endPixel_ = e, this.createOrUpdateGeometry(), this.render_()
    }

    createOrUpdateGeometry() {
        let t = this.startPixel_, e = this.endPixel_,
            r = [t, [t[0], e[1]], e, [e[0], t[1]]].map(this.map_.getCoordinateFromPixelInternal, this.map_);
        r[4] = r[0].slice(), this.geometry_ ? this.geometry_.setCoordinates([r]) : this.geometry_ = new dd([r])
    }

    getGeometry() {
        return this.geometry_
    }
}, Wd = Sl;
var fo = {BOXSTART: "boxstart", BOXDRAG: "boxdrag", BOXEND: "boxend", BOXCANCEL: "boxcancel"}, Hr = class extends Ft {
    constructor(t, e, i) {
        super(t), this.coordinate = e, this.mapBrowserEvent = i
    }
}, Il = class extends ti {
    constructor(t) {
        super(), this.on, this.once, this.un, t = t || {}, this.box_ = new Wd(t.className || "ol-dragbox"), this.minArea_ = t.minArea !== void 0 ? t.minArea : 64, t.onBoxEnd && (this.onBoxEnd = t.onBoxEnd), this.startPixel_ = null, this.condition_ = t.condition ? t.condition : lo, this.boxEndCondition_ = t.boxEndCondition ? t.boxEndCondition : this.defaultBoxEndCondition
    }

    defaultBoxEndCondition(t, e, i) {
        let r = i[0] - e[0], s = i[1] - e[1];
        return r * r + s * s >= this.minArea_
    }

    getGeometry() {
        return this.box_.getGeometry()
    }

    handleDragEvent(t) {
        this.box_.setPixels(this.startPixel_, t.pixel), this.dispatchEvent(new Hr(fo.BOXDRAG, t.coordinate, t))
    }

    handleUpEvent(t) {
        this.box_.setMap(null);
        let e = this.boxEndCondition_(t, this.startPixel_, t.pixel);
        return e && this.onBoxEnd(t), this.dispatchEvent(new Hr(e ? fo.BOXEND : fo.BOXCANCEL, t.coordinate, t)), !1
    }

    handleDownEvent(t) {
        return this.condition_(t) ? (this.startPixel_ = t.pixel, this.box_.setMap(t.map), this.box_.setPixels(this.startPixel_, this.startPixel_), this.dispatchEvent(new Hr(fo.BOXSTART, t.coordinate, t)), !0) : !1
    }

    onBoxEnd(t) {
    }
}, zd = Il;
Ui();
var Ll = class extends zd {
    constructor(t) {
        t = t || {};
        let e = t.condition ? t.condition : kd;
        super({
            condition: e,
            className: t.className || "ol-dragzoom",
            minArea: t.minArea
        }), this.duration_ = t.duration !== void 0 ? t.duration : 200, this.out_ = t.out !== void 0 ? t.out : !1
    }

    onBoxEnd(t) {
        let i = this.getMap().getView(), r = this.getGeometry();
        if (this.out_) {
            let s = i.rotatedExtentForGeometry(r), o = i.getResolutionForExtentInternal(s), a = i.getResolution() / o;
            r = r.clone(), r.scale(a * a)
        }
        i.fitInternal(r, {duration: this.duration_, easing: Re})
    }
}, Yd = Ll;
pt();
var Ji = {LEFT: "ArrowLeft", UP: "ArrowUp", RIGHT: "ArrowRight", DOWN: "ArrowDown"};
_i();
var bl = class extends Qe {
    constructor(t) {
        super(), t = t || {}, this.defaultCondition_ = function (e) {
            return ho(e) && co(e)
        }, this.condition_ = t.condition !== void 0 ? t.condition : this.defaultCondition_, this.duration_ = t.duration !== void 0 ? t.duration : 100, this.pixelDelta_ = t.pixelDelta !== void 0 ? t.pixelDelta : 128
    }

    handleEvent(t) {
        let e = !1;
        if (t.type == D.KEYDOWN) {
            let i = t.originalEvent, r = i.key;
            if (this.condition_(t) && (r == Ji.DOWN || r == Ji.LEFT || r == Ji.RIGHT || r == Ji.UP)) {
                let o = t.map.getView(), a = o.getResolution() * this.pixelDelta_, l = 0, h = 0;
                r == Ji.DOWN ? h = -a : r == Ji.LEFT ? l = -a : r == Ji.RIGHT ? l = a : h = a;
                let c = [l, h];
                tr(c, o.getRotation()), Md(o, c, this.duration_), i.preventDefault(), e = !0
            }
        }
        return !e
    }
}, Ud = bl;
pt();
var Al = class extends Qe {
    constructor(t) {
        super(), t = t || {}, this.condition_ = t.condition ? t.condition : function (e) {
            return !Dd(e) && co(e)
        }, this.delta_ = t.delta ? t.delta : 1, this.duration_ = t.duration !== void 0 ? t.duration : 100
    }

    handleEvent(t) {
        let e = !1;
        if (t.type == D.KEYDOWN || t.type == D.KEYPRESS) {
            let i = t.originalEvent, r = i.key;
            if (this.condition_(t) && (r === "+" || r === "-")) {
                let s = t.map, o = r === "+" ? this.delta_ : -this.delta_, a = s.getView();
                fr(a, o, void 0, this.duration_), i.preventDefault(), e = !0
            }
        }
        return !e
    }
}, jd = Al;
var Ml = class {
    constructor(t, e, i) {
        this.decay_ = t, this.minVelocity_ = e, this.delay_ = i, this.points_ = [], this.angle_ = 0, this.initialVelocity_ = 0
    }

    begin() {
        this.points_.length = 0, this.angle_ = 0, this.initialVelocity_ = 0
    }

    update(t, e) {
        this.points_.push(t, e, Date.now())
    }

    end() {
        if (this.points_.length < 6) return !1;
        let t = Date.now() - this.delay_, e = this.points_.length - 3;
        if (this.points_[e + 2] < t) return !1;
        let i = e - 3;
        for (; i > 0 && this.points_[i + 2] > t;) i -= 3;
        let r = this.points_[e + 2] - this.points_[i + 2];
        if (r < 1e3 / 60) return !1;
        let s = this.points_[e] - this.points_[i], o = this.points_[e + 1] - this.points_[i + 1];
        return this.angle_ = Math.atan2(o, s), this.initialVelocity_ = Math.sqrt(s * s + o * o) / r, this.initialVelocity_ > this.minVelocity_
    }

    getDistance() {
        return (this.minVelocity_ - this.initialVelocity_) / this.decay_
    }

    getAngle() {
        return this.angle_
    }
}, Bd = Ml;
pt();
ci();
xt();
var Pl = class extends Qe {
    constructor(t) {
        t = t || {}, super(t), this.totalDelta_ = 0, this.lastDelta_ = 0, this.maxDelta_ = t.maxDelta !== void 0 ? t.maxDelta : 1, this.duration_ = t.duration !== void 0 ? t.duration : 250, this.timeout_ = t.timeout !== void 0 ? t.timeout : 80, this.useAnchor_ = t.useAnchor !== void 0 ? t.useAnchor : !0, this.constrainResolution_ = t.constrainResolution !== void 0 ? t.constrainResolution : !1;
        let e = t.condition ? t.condition : Fd;
        this.condition_ = t.onFocusOnly ? qr(ao, e) : e, this.lastAnchor_ = null, this.startTime_ = void 0, this.timeoutId_, this.mode_ = void 0, this.trackpadEventGap_ = 400, this.trackpadTimeoutId_, this.deltaPerZoom_ = 300
    }

    endInteraction_() {
        this.trackpadTimeoutId_ = void 0;
        let t = this.getMap();
        if (!t) return;
        t.getView().endInteraction(void 0, this.lastDelta_ ? this.lastDelta_ > 0 ? 1 : -1 : 0, this.lastAnchor_)
    }

    handleEvent(t) {
        if (!this.condition_(t) || t.type !== D.WHEEL) return !0;
        let i = t.map, r = t.originalEvent;
        r.preventDefault(), this.useAnchor_ && (this.lastAnchor_ = t.coordinate);
        let s;
        if (t.type == D.WHEEL && (s = r.deltaY, Pc && r.deltaMode === WheelEvent.DOM_DELTA_PIXEL && (s /= Ts), r.deltaMode === WheelEvent.DOM_DELTA_LINE && (s *= 40)), s === 0) return !1;
        this.lastDelta_ = s;
        let o = Date.now();
        this.startTime_ === void 0 && (this.startTime_ = o), (!this.mode_ || o - this.startTime_ > this.trackpadEventGap_) && (this.mode_ = Math.abs(s) < 4 ? "trackpad" : "wheel");
        let a = i.getView();
        if (this.mode_ === "trackpad" && !(a.getConstrainResolution() || this.constrainResolution_)) return this.trackpadTimeoutId_ ? clearTimeout(this.trackpadTimeoutId_) : (a.getAnimating() && a.cancelAnimations(), a.beginInteraction()), this.trackpadTimeoutId_ = setTimeout(this.endInteraction_.bind(this), this.timeout_), a.adjustZoom(-s / this.deltaPerZoom_, this.lastAnchor_), this.startTime_ = o, !1;
        this.totalDelta_ += s;
        let l = Math.max(this.timeout_ - (o - this.startTime_), 0);
        return clearTimeout(this.timeoutId_), this.timeoutId_ = setTimeout(this.handleWheelZoom_.bind(this, i), l), !1
    }

    handleWheelZoom_(t) {
        let e = t.getView();
        e.getAnimating() && e.cancelAnimations();
        let i = -ot(this.totalDelta_, -this.maxDelta_ * this.deltaPerZoom_, this.maxDelta_ * this.deltaPerZoom_) / this.deltaPerZoom_;
        (e.getConstrainResolution() || this.constrainResolution_) && (i = i ? i > 0 ? 1 : -1 : 0), fr(e, i, this.lastAnchor_, this.duration_), this.mode_ = void 0, this.totalDelta_ = 0, this.lastAnchor_ = null, this.startTime_ = void 0, this.timeoutId_ = void 0
    }

    setMouseAnchor(t) {
        this.useAnchor_ = t, t || (this.lastAnchor_ = null)
    }
}, Kd = Pl;
Ht();
Vs();
var Ol = class extends ti {
    constructor(t) {
        t = t || {};
        let e = t;
        e.stopDown || (e.stopDown = hi), super(e), this.anchor_ = null, this.lastAngle_ = void 0, this.rotating_ = !1, this.rotationDelta_ = 0, this.threshold_ = t.threshold !== void 0 ? t.threshold : .3, this.duration_ = t.duration !== void 0 ? t.duration : 250
    }

    handleDragEvent(t) {
        let e = 0, i = this.targetPointers[0], r = this.targetPointers[1],
            s = Math.atan2(r.clientY - i.clientY, r.clientX - i.clientX);
        if (this.lastAngle_ !== void 0) {
            let l = s - this.lastAngle_;
            this.rotationDelta_ += l, !this.rotating_ && Math.abs(this.rotationDelta_) > this.threshold_ && (this.rotating_ = !0), e = l
        }
        this.lastAngle_ = s;
        let o = t.map, a = o.getView();
        a.getConstraints().rotation !== rr && (this.anchor_ = o.getCoordinateFromPixelInternal(o.getEventPixel(gr(this.targetPointers))), this.rotating_ && (o.render(), a.adjustRotationInternal(e, this.anchor_)))
    }

    handleUpEvent(t) {
        return this.targetPointers.length < 2 ? (t.map.getView().endInteraction(this.duration_), !1) : !0
    }

    handleDownEvent(t) {
        if (this.targetPointers.length >= 2) {
            let e = t.map;
            return this.anchor_ = null, this.lastAngle_ = void 0, this.rotating_ = !1, this.rotationDelta_ = 0, this.handlingDownUpSequence || e.getView().beginInteraction(), !0
        }
        return !1
    }
}, Vd = Ol;
Ht();
var Fl = class extends ti {
    constructor(t) {
        t = t || {};
        let e = t;
        e.stopDown || (e.stopDown = hi), super(e), this.anchor_ = null, this.duration_ = t.duration !== void 0 ? t.duration : 400, this.lastDistance_ = void 0, this.lastScaleDelta_ = 1
    }

    handleDragEvent(t) {
        let e = 1, i = this.targetPointers[0], r = this.targetPointers[1], s = i.clientX - r.clientX,
            o = i.clientY - r.clientY, a = Math.sqrt(s * s + o * o);
        this.lastDistance_ !== void 0 && (e = this.lastDistance_ / a), this.lastDistance_ = a;
        let l = t.map, h = l.getView();
        e != 1 && (this.lastScaleDelta_ = e), this.anchor_ = l.getCoordinateFromPixelInternal(l.getEventPixel(gr(this.targetPointers))), l.render(), h.adjustResolutionInternal(e, this.anchor_)
    }

    handleUpEvent(t) {
        if (this.targetPointers.length < 2) {
            let i = t.map.getView(), r = this.lastScaleDelta_ > 1 ? 1 : -1;
            return i.endInteraction(this.duration_, r), !1
        }
        return !0
    }

    handleDownEvent(t) {
        if (this.targetPointers.length >= 2) {
            let e = t.map;
            return this.anchor_ = null, this.lastDistance_ = void 0, this.lastScaleDelta_ = 1, this.handlingDownUpSequence || e.getView().beginInteraction(), !0
        }
        return !1
    }
}, Zd = Fl;

function qd(n) {
    n = n || {};
    let t = new $t, e = new Bd(-.005, .05, 100);
    return (n.altShiftDragRotate !== void 0 ? n.altShiftDragRotate : !0) && t.push(new Xd), (n.doubleClickZoom !== void 0 ? n.doubleClickZoom : !0) && t.push(new Pd({
        delta: n.zoomDelta,
        duration: n.zoomDuration
    })), (n.dragPan !== void 0 ? n.dragPan : !0) && t.push(new Gd({
        onFocusOnly: n.onFocusOnly,
        kinetic: e
    })), (n.pinchRotate !== void 0 ? n.pinchRotate : !0) && t.push(new Vd), (n.pinchZoom !== void 0 ? n.pinchZoom : !0) && t.push(new Zd({duration: n.zoomDuration})), (n.keyboard !== void 0 ? n.keyboard : !0) && (t.push(new Ud), t.push(new jd({
        delta: n.zoomDelta,
        duration: n.zoomDuration
    }))), (n.mouseWheelZoom !== void 0 ? n.mouseWheelZoom : !0) && t.push(new Kd({
        onFocusOnly: n.onFocusOnly,
        duration: n.zoomDuration
    })), (n.shiftDragZoom !== void 0 ? n.shiftDragZoom : !0) && t.push(new Yd({duration: n.zoomDuration})), t
}

Ct();
Yt();
wt();
Ri();
fe();
te();
pa();

function $d(n) {
    if (n instanceof xn) {
        n.setMapInternal(null);
        return
    }
    n instanceof Kr && n.getLayers().forEach($d)
}

function Jd(n, t) {
    if (n instanceof xn) {
        n.setMapInternal(t);
        return
    }
    if (n instanceof Kr) {
        let e = n.getLayers().getArray();
        for (let i = 0, r = e.length; i < r; ++i) Jd(e[i], t)
    }
}

var kl = class extends St {
    constructor(t) {
        super(), t = t || {}, this.on, this.once, this.un;
        let e = Xm(t);
        this.renderComplete_, this.loaded_ = !0, this.boundHandleBrowserEvent_ = this.handleBrowserEvent.bind(this), this.maxTilesLoading_ = t.maxTilesLoading !== void 0 ? t.maxTilesLoading : 16, this.pixelRatio_ = t.pixelRatio !== void 0 ? t.pixelRatio : Ts, this.postRenderTimeoutHandle_, this.animationDelayKey_, this.animationDelay_ = this.animationDelay_.bind(this), this.coordinateToPixelTransform_ = kt(), this.pixelToCoordinateTransform_ = kt(), this.frameIndex_ = 0, this.frameState_ = null, this.previousExtent_ = null, this.viewPropertyListenerKey_ = null, this.viewChangeListenerKey_ = null, this.layerGroupPropertyListenerKeys_ = null, this.viewport_ = document.createElement("div"), this.viewport_.className = "ol-viewport" + ("ontouchstart" in window ? " ol-touch" : ""), this.viewport_.style.position = "relative", this.viewport_.style.overflow = "hidden", this.viewport_.style.width = "100%", this.viewport_.style.height = "100%", this.overlayContainer_ = document.createElement("div"), this.overlayContainer_.style.position = "absolute", this.overlayContainer_.style.zIndex = "0", this.overlayContainer_.style.width = "100%", this.overlayContainer_.style.height = "100%", this.overlayContainer_.style.pointerEvents = "none", this.overlayContainer_.className = "ol-overlaycontainer", this.viewport_.appendChild(this.overlayContainer_), this.overlayContainerStopEvent_ = document.createElement("div"), this.overlayContainerStopEvent_.style.position = "absolute", this.overlayContainerStopEvent_.style.zIndex = "0", this.overlayContainerStopEvent_.style.width = "100%", this.overlayContainerStopEvent_.style.height = "100%", this.overlayContainerStopEvent_.style.pointerEvents = "none", this.overlayContainerStopEvent_.className = "ol-overlaycontainer-stopevent", this.viewport_.appendChild(this.overlayContainerStopEvent_), this.mapBrowserEventHandler_ = null, this.moveTolerance_ = t.moveTolerance, this.keyboardEventTarget_ = e.keyboardEventTarget, this.targetChangeHandlerKeys_ = null, this.targetElement_ = null, this.resizeObserver_ = new ResizeObserver(() => this.updateSize()), this.controls = e.controls || Zr(), this.interactions = e.interactions || qd({onFocusOnly: !0}), this.overlays_ = e.overlays, this.overlayIdIndex_ = {}, this.renderer_ = null, this.postRenderFunctions_ = [], this.tileQueue_ = new Rd(this.getTilePriority.bind(this), this.handleTileChange_.bind(this)), this.addChangeListener(Ut.LAYERGROUP, this.handleLayerGroupChanged_), this.addChangeListener(Ut.VIEW, this.handleViewChanged_), this.addChangeListener(Ut.SIZE, this.handleSizeChanged_), this.addChangeListener(Ut.TARGET, this.handleTargetChanged_), this.setProperties(e.values);
        let i = this;
        t.view && !(t.view instanceof me) && t.view.then(function (r) {
            i.setView(new me(r))
        }), this.controls.addEventListener(Dt.ADD, r => {
            r.element.setMap(this)
        }), this.controls.addEventListener(Dt.REMOVE, r => {
            r.element.setMap(null)
        }), this.interactions.addEventListener(Dt.ADD, r => {
            r.element.setMap(this)
        }), this.interactions.addEventListener(Dt.REMOVE, r => {
            r.element.setMap(null)
        }), this.overlays_.addEventListener(Dt.ADD, r => {
            this.addOverlayInternal_(r.element)
        }), this.overlays_.addEventListener(Dt.REMOVE, r => {
            let s = r.element.getId();
            s !== void 0 && delete this.overlayIdIndex_[s.toString()], r.element.setMap(null)
        }), this.controls.forEach(r => {
            r.setMap(this)
        }), this.interactions.forEach(r => {
            r.setMap(this)
        }), this.overlays_.forEach(this.addOverlayInternal_.bind(this))
    }

    addControl(t) {
        this.getControls().push(t)
    }

    addInteraction(t) {
        this.getInteractions().push(t)
    }

    addLayer(t) {
        this.getLayerGroup().getLayers().push(t)
    }

    handleLayerAdd_(t) {
        Jd(t.layer, this)
    }

    addOverlay(t) {
        this.getOverlays().push(t)
    }

    addOverlayInternal_(t) {
        let e = t.getId();
        e !== void 0 && (this.overlayIdIndex_[e.toString()] = t), t.setMap(this)
    }

    disposeInternal() {
        this.controls.clear(), this.interactions.clear(), this.overlays_.clear(), this.resizeObserver_.disconnect(), this.setTarget(null), super.disposeInternal()
    }

    forEachFeatureAtPixel(t, e, i) {
        if (!this.frameState_ || !this.renderer_) return;
        let r = this.getCoordinateFromPixelInternal(t);
        i = i !== void 0 ? i : {};
        let s = i.hitTolerance !== void 0 ? i.hitTolerance : 0, o = i.layerFilter !== void 0 ? i.layerFilter : li,
            a = i.checkWrapped !== !1;
        return this.renderer_.forEachFeatureAtCoordinate(r, this.frameState_, s, a, e, null, o, null)
    }

    getFeaturesAtPixel(t, e) {
        let i = [];
        return this.forEachFeatureAtPixel(t, function (r) {
            i.push(r)
        }, e), i
    }

    getAllLayers() {
        let t = [];

        function e(i) {
            i.forEach(function (r) {
                r instanceof Kr ? e(r.getLayers()) : t.push(r)
            })
        }

        return e(this.getLayers()), t
    }

    hasFeatureAtPixel(t, e) {
        if (!this.frameState_ || !this.renderer_) return !1;
        let i = this.getCoordinateFromPixelInternal(t);
        e = e !== void 0 ? e : {};
        let r = e.layerFilter !== void 0 ? e.layerFilter : li, s = e.hitTolerance !== void 0 ? e.hitTolerance : 0,
            o = e.checkWrapped !== !1;
        return this.renderer_.hasFeatureAtCoordinate(i, this.frameState_, s, o, r, null)
    }

    getEventCoordinate(t) {
        return this.getCoordinateFromPixel(this.getEventPixel(t))
    }

    getEventCoordinateInternal(t) {
        return this.getCoordinateFromPixelInternal(this.getEventPixel(t))
    }

    getEventPixel(t) {
        let i = this.viewport_.getBoundingClientRect(), r = this.getSize(), s = i.width / r[0], o = i.height / r[1],
            a = "changedTouches" in t ? t.changedTouches[0] : t;
        return [(a.clientX - i.left) / s, (a.clientY - i.top) / o]
    }

    getTarget() {
        return this.get(Ut.TARGET)
    }

    getTargetElement() {
        return this.targetElement_
    }

    getCoordinateFromPixel(t) {
        return nr(this.getCoordinateFromPixelInternal(t), this.getView().getProjection())
    }

    getCoordinateFromPixelInternal(t) {
        let e = this.frameState_;
        return e ? _t(e.pixelToCoordinateTransform, t.slice()) : null
    }

    getControls() {
        return this.controls
    }

    getOverlays() {
        return this.overlays_
    }

    getOverlayById(t) {
        let e = this.overlayIdIndex_[t.toString()];
        return e !== void 0 ? e : null
    }

    getInteractions() {
        return this.interactions
    }

    getLayerGroup() {
        return this.get(Ut.LAYERGROUP)
    }

    setLayers(t) {
        let e = this.getLayerGroup();
        if (t instanceof $t) {
            e.setLayers(t);
            return
        }
        let i = e.getLayers();
        i.clear(), i.extend(t)
    }

    getLayers() {
        return this.getLayerGroup().getLayers()
    }

    getLoadingOrNotReady() {
        let t = this.getLayerGroup().getLayerStatesArray();
        for (let e = 0, i = t.length; e < i; ++e) {
            let r = t[e];
            if (!r.visible) continue;
            let s = r.layer.getRenderer();
            if (s && !s.ready) return !0;
            let o = r.layer.getSource();
            if (o && o.loading) return !0
        }
        return !1
    }

    getPixelFromCoordinate(t) {
        let e = Te(t, this.getView().getProjection());
        return this.getPixelFromCoordinateInternal(e)
    }

    getPixelFromCoordinateInternal(t) {
        let e = this.frameState_;
        return e ? _t(e.coordinateToPixelTransform, t.slice(0, 2)) : null
    }

    getRenderer() {
        return this.renderer_
    }

    getSize() {
        return this.get(Ut.SIZE)
    }

    getView() {
        return this.get(Ut.VIEW)
    }

    getViewport() {
        return this.viewport_
    }

    getOverlayContainer() {
        return this.overlayContainer_
    }

    getOverlayContainerStopEvent() {
        return this.overlayContainerStopEvent_
    }

    getOwnerDocument() {
        let t = this.getTargetElement();
        return t ? t.ownerDocument : document
    }

    getTilePriority(t, e, i, r) {
        return Sd(this.frameState_, t, e, i, r)
    }

    handleBrowserEvent(t, e) {
        e = e || t.type;
        let i = new $e(e, this, t);
        this.handleMapBrowserEvent(i)
    }

    handleMapBrowserEvent(t) {
        if (!this.frameState_) return;
        let e = t.originalEvent, i = e.type;
        if (i === $i.POINTERDOWN || i === D.WHEEL || i === D.KEYDOWN) {
            let r = this.getOwnerDocument(), s = this.viewport_.getRootNode ? this.viewport_.getRootNode() : r,
                o = e.target;
            if (this.overlayContainerStopEvent_.contains(o) || !(s === r ? r.documentElement : s).contains(o)) return
        }
        if (t.frameState = this.frameState_, this.dispatchEvent(t) !== !1) {
            let r = this.getInteractions().getArray().slice();
            for (let s = r.length - 1; s >= 0; s--) {
                let o = r[s];
                if (o.getMap() !== this || !o.getActive() || !this.getTargetElement()) continue;
                if (!o.handleEvent(t) || t.propagationStopped) break
            }
        }
    }

    handlePostRender() {
        let t = this.frameState_, e = this.tileQueue_;
        if (!e.isEmpty()) {
            let r = this.maxTilesLoading_, s = r;
            if (t) {
                let o = t.viewHints;
                if (o[Pt.ANIMATING] || o[Pt.INTERACTING]) {
                    let a = Date.now() - t.time > 8;
                    r = a ? 0 : 8, s = a ? 0 : 2
                }
            }
            e.getTilesLoading() < r && (e.reprioritize(), e.loadMoreTiles(r, s))
        }
        t && this.renderer_ && !t.animate && (this.renderComplete_ === !0 ? (this.hasListener(Jt.RENDERCOMPLETE) && this.renderer_.dispatchRenderEvent(Jt.RENDERCOMPLETE, t), this.loaded_ === !1 && (this.loaded_ = !0, this.dispatchEvent(new Hi(Je.LOADEND, this, t)))) : this.loaded_ === !0 && (this.loaded_ = !1, this.dispatchEvent(new Hi(Je.LOADSTART, this, t))));
        let i = this.postRenderFunctions_;
        for (let r = 0, s = i.length; r < s; ++r) i[r](this, t);
        i.length = 0
    }

    handleSizeChanged_() {
        this.getView() && !this.getView().getAnimating() && this.getView().resolveConstraints(0), this.render()
    }

    handleTargetChanged_() {
        if (this.mapBrowserEventHandler_) {
            for (let i = 0, r = this.targetChangeHandlerKeys_.length; i < r; ++i) et(this.targetChangeHandlerKeys_[i]);
            this.targetChangeHandlerKeys_ = null, this.viewport_.removeEventListener(D.CONTEXTMENU, this.boundHandleBrowserEvent_), this.viewport_.removeEventListener(D.WHEEL, this.boundHandleBrowserEvent_), this.mapBrowserEventHandler_.dispose(), this.mapBrowserEventHandler_ = null, Br(this.viewport_)
        }
        if (this.targetElement_) {
            this.resizeObserver_.unobserve(this.targetElement_);
            let i = this.targetElement_.getRootNode();
            i instanceof ShadowRoot && this.resizeObserver_.unobserve(i.host), this.setSize(void 0)
        }
        let t = this.getTarget(), e = typeof t == "string" ? document.getElementById(t) : t;
        if (this.targetElement_ = e, !e) this.renderer_ && (clearTimeout(this.postRenderTimeoutHandle_), this.postRenderTimeoutHandle_ = void 0, this.postRenderFunctions_.length = 0, this.renderer_.dispose(), this.renderer_ = null), this.animationDelayKey_ && (cancelAnimationFrame(this.animationDelayKey_), this.animationDelayKey_ = void 0); else {
            e.appendChild(this.viewport_), this.renderer_ || (this.renderer_ = new wd(this)), this.mapBrowserEventHandler_ = new Td(this, this.moveTolerance_);
            for (let s in dt) this.mapBrowserEventHandler_.addEventListener(dt[s], this.handleMapBrowserEvent.bind(this));
            this.viewport_.addEventListener(D.CONTEXTMENU, this.boundHandleBrowserEvent_, !1), this.viewport_.addEventListener(D.WHEEL, this.boundHandleBrowserEvent_, vs ? {passive: !1} : !1);
            let i = this.keyboardEventTarget_ ? this.keyboardEventTarget_ : e;
            this.targetChangeHandlerKeys_ = [U(i, D.KEYDOWN, this.handleBrowserEvent, this), U(i, D.KEYPRESS, this.handleBrowserEvent, this)];
            let r = e.getRootNode();
            r instanceof ShadowRoot && this.resizeObserver_.observe(r.host), this.resizeObserver_.observe(e)
        }
        this.updateSize()
    }

    handleTileChange_() {
        this.render()
    }

    handleViewPropertyChanged_() {
        this.render()
    }

    handleViewChanged_() {
        this.viewPropertyListenerKey_ && (et(this.viewPropertyListenerKey_), this.viewPropertyListenerKey_ = null), this.viewChangeListenerKey_ && (et(this.viewChangeListenerKey_), this.viewChangeListenerKey_ = null);
        let t = this.getView();
        t && (this.updateViewportSize_(this.getSize()), this.viewPropertyListenerKey_ = U(t, Ae.PROPERTYCHANGE, this.handleViewPropertyChanged_, this), this.viewChangeListenerKey_ = U(t, D.CHANGE, this.handleViewPropertyChanged_, this), t.resolveConstraints(0)), this.render()
    }

    handleLayerGroupChanged_() {
        this.layerGroupPropertyListenerKeys_ && (this.layerGroupPropertyListenerKeys_.forEach(et), this.layerGroupPropertyListenerKeys_ = null);
        let t = this.getLayerGroup();
        t && (this.handleLayerAdd_(new Ne("addlayer", t)), this.layerGroupPropertyListenerKeys_ = [U(t, Ae.PROPERTYCHANGE, this.render, this), U(t, D.CHANGE, this.render, this), U(t, "addlayer", this.handleLayerAdd_, this), U(t, "removelayer", this.handleLayerRemove_, this)]), this.render()
    }

    isRendered() {
        return !!this.frameState_
    }

    animationDelay_() {
        this.animationDelayKey_ = void 0, this.renderFrame_(Date.now())
    }

    renderSync() {
        this.animationDelayKey_ && cancelAnimationFrame(this.animationDelayKey_), this.animationDelay_()
    }

    redrawText() {
        let t = this.getLayerGroup().getLayerStatesArray();
        for (let e = 0, i = t.length; e < i; ++e) {
            let r = t[e].layer;
            r.hasRenderer() && r.getRenderer().handleFontsChanged()
        }
    }

    render() {
        this.renderer_ && this.animationDelayKey_ === void 0 && (this.animationDelayKey_ = requestAnimationFrame(this.animationDelay_))
    }

    flushDeclutterItems() {
        let t = this.frameState_;
        t && this.renderer_.flushDeclutterItems(t)
    }

    removeControl(t) {
        return this.getControls().remove(t)
    }

    removeInteraction(t) {
        return this.getInteractions().remove(t)
    }

    removeLayer(t) {
        return this.getLayerGroup().getLayers().remove(t)
    }

    handleLayerRemove_(t) {
        $d(t.layer)
    }

    removeOverlay(t) {
        return this.getOverlays().remove(t)
    }

    renderFrame_(t) {
        let e = this.getSize(), i = this.getView(), r = this.frameState_, s = null;
        if (e !== void 0 && Dl(e) && i && i.isDef()) {
            let o = i.getHints(this.frameState_ ? this.frameState_.viewHints : void 0), a = i.getState();
            if (s = {
                animate: !1,
                coordinateToPixelTransform: this.coordinateToPixelTransform_,
                declutterTree: null,
                extent: Mr(a.center, a.resolution, a.rotation, e),
                index: this.frameIndex_++,
                layerIndex: 0,
                layerStatesArray: this.getLayerGroup().getLayerStatesArray(),
                pixelRatio: this.pixelRatio_,
                pixelToCoordinateTransform: this.pixelToCoordinateTransform_,
                postRenderFunctions: [],
                size: e,
                tileQueue: this.tileQueue_,
                time: t,
                usedTiles: {},
                viewState: a,
                viewHints: o,
                wantedTiles: {},
                mapId: K(this),
                renderTargets: {}
            }, a.nextCenter && a.nextResolution) {
                let l = isNaN(a.nextRotation) ? a.rotation : a.nextRotation;
                s.nextExtent = Mr(a.nextCenter, a.nextResolution, l, e)
            }
        }
        this.frameState_ = s, this.renderer_.renderFrame(s), s && (s.animate && this.render(), Array.prototype.push.apply(this.postRenderFunctions_, s.postRenderFunctions), r && (!this.previousExtent_ || !Wi(this.previousExtent_) && !di(s.extent, this.previousExtent_)) && (this.dispatchEvent(new Hi(Je.MOVESTART, this, r)), this.previousExtent_ = hn(this.previousExtent_)), this.previousExtent_ && !s.viewHints[Pt.ANIMATING] && !s.viewHints[Pt.INTERACTING] && !di(s.extent, this.previousExtent_) && (this.dispatchEvent(new Hi(Je.MOVEEND, this, s)), Is(s.extent, this.previousExtent_))), this.dispatchEvent(new Hi(Je.POSTRENDER, this, s)), this.renderComplete_ = this.hasListener(Je.LOADSTART) || this.hasListener(Je.LOADEND) || this.hasListener(Jt.RENDERCOMPLETE) ? !this.tileQueue_.getTilesLoading() && !this.tileQueue_.getCount() && !this.getLoadingOrNotReady() : void 0, this.postRenderTimeoutHandle_ || (this.postRenderTimeoutHandle_ = setTimeout(() => {
            this.postRenderTimeoutHandle_ = void 0, this.handlePostRender()
        }, 0))
    }

    setLayerGroup(t) {
        let e = this.getLayerGroup();
        e && this.handleLayerRemove_(new Ne("removelayer", e)), this.set(Ut.LAYERGROUP, t)
    }

    setSize(t) {
        this.set(Ut.SIZE, t)
    }

    setTarget(t) {
        this.set(Ut.TARGET, t)
    }

    setView(t) {
        if (!t || t instanceof me) {
            this.set(Ut.VIEW, t);
            return
        }
        this.set(Ut.VIEW, new me);
        let e = this;
        t.then(function (i) {
            e.setView(new me(i))
        })
    }

    updateSize() {
        let t = this.getTargetElement(), e;
        if (t) {
            let r = getComputedStyle(t),
                s = t.offsetWidth - parseFloat(r.borderLeftWidth) - parseFloat(r.paddingLeft) - parseFloat(r.paddingRight) - parseFloat(r.borderRightWidth),
                o = t.offsetHeight - parseFloat(r.borderTopWidth) - parseFloat(r.paddingTop) - parseFloat(r.paddingBottom) - parseFloat(r.borderBottomWidth);
            !isNaN(s) && !isNaN(o) && (e = [s, o], !Dl(e) && (t.offsetWidth || t.offsetHeight || t.getClientRects().length) && Us("No map visible because the map container's width or height are 0."))
        }
        let i = this.getSize();
        e && (!i || !Vt(e, i)) && (this.setSize(e), this.updateViewportSize_(e))
    }

    updateViewportSize_(t) {
        let e = this.getView();
        e && e.setViewportSize(t)
    }
};

function Xm(n) {
    let t = null;
    n.keyboardEventTarget !== void 0 && (t = typeof n.keyboardEventTarget == "string" ? document.getElementById(n.keyboardEventTarget) : n.keyboardEventTarget);
    let e = {}, i = n.layers && typeof n.layers.getLayers == "function" ? n.layers : new Kr({layers: n.layers});
    e[Ut.LAYERGROUP] = i, e[Ut.TARGET] = n.target, e[Ut.VIEW] = n.view instanceof me ? n.view : new me;
    let r;
    n.controls !== void 0 && (Array.isArray(n.controls) ? r = new $t(n.controls.slice()) : (z(typeof n.controls.getArray == "function", "Expected `controls` to be an array or an `ol/Collection.js`"), r = n.controls));
    let s;
    n.interactions !== void 0 && (Array.isArray(n.interactions) ? s = new $t(n.interactions.slice()) : (z(typeof n.interactions.getArray == "function", "Expected `interactions` to be an array or an `ol/Collection.js`"), s = n.interactions));
    let o;
    return n.overlays !== void 0 ? Array.isArray(n.overlays) ? o = new $t(n.overlays.slice()) : (z(typeof n.overlays.getArray == "function", "Expected `overlays` to be an array or an `ol/Collection.js`"), o = n.overlays) : o = new $t, {
        controls: r,
        interactions: s,
        keyboardEventTarget: t,
        overlays: o,
        values: e
    }
}

var Qd = kl;
dr();
Yt();
fe();
_i();
var Nl = "projection", tf = "coordinateFormat", Gl = class extends vi {
    constructor(t) {
        t = t || {};
        let e = document.createElement("div");
        e.className = t.className !== void 0 ? t.className : "ol-mouse-position", super({
            element: e,
            render: t.render,
            target: t.target
        }), this.on, this.once, this.un, this.addChangeListener(Nl, this.handleProjectionChanged_), t.coordinateFormat && this.setCoordinateFormat(t.coordinateFormat), t.projection && this.setProjection(t.projection), this.renderOnMouseOut_ = t.placeholder !== void 0, this.placeholder_ = this.renderOnMouseOut_ ? t.placeholder : "&#160;", this.renderedHTML_ = e.innerHTML, this.mapProjection_ = null, this.transform_ = null, this.wrapX_ = t.wrapX !== !1
    }

    handleProjectionChanged_() {
        this.transform_ = null
    }

    getCoordinateFormat() {
        return this.get(tf)
    }

    getProjection() {
        return this.get(Nl)
    }

    handleMouseMove(t) {
        let e = this.getMap();
        this.updateHTML_(e.getEventPixel(t))
    }

    handleMouseOut(t) {
        this.updateHTML_(null)
    }

    setMap(t) {
        if (super.setMap(t), t) {
            let e = t.getViewport();
            this.listenerKeys.push(U(e, $i.POINTERMOVE, this.handleMouseMove, this)), this.renderOnMouseOut_ && this.listenerKeys.push(U(e, $i.POINTEROUT, this.handleMouseOut, this)), this.updateHTML_(null)
        }
    }

    setCoordinateFormat(t) {
        this.set(tf, t)
    }

    setProjection(t) {
        this.set(Nl, ft(t))
    }

    updateHTML_(t) {
        let e = this.placeholder_;
        if (t && this.mapProjection_) {
            if (!this.transform_) {
                let s = this.getProjection();
                s ? this.transform_ = Ve(this.mapProjection_, s) : this.transform_ = Nr
            }
            let r = this.getMap().getCoordinateFromPixelInternal(t);
            if (r) {
                let s = _n();
                if (s && (this.transform_ = Ve(this.mapProjection_, s)), this.transform_(r, r), this.wrapX_) {
                    let a = s || this.getProjection() || this.mapProjection_;
                    er(r, a)
                }
                let o = this.getCoordinateFormat();
                o ? e = o(r) : e = r.toString()
            }
        }
        (!this.renderedHTML_ || e !== this.renderedHTML_) && (this.element.innerHTML = e, this.renderedHTML_ = e)
    }

    render(t) {
        let e = t.frameState;
        e ? this.mapProjection_ != e.viewState.projection && (this.mapProjection_ = e.viewState.projection, this.transform_ = null) : this.mapProjection_ = null
    }
}, ef = Gl;
pt();
Lr();
pt();
wt();
Ui();
var Xl = class extends ki {
    constructor(t, e, i) {
        super(), i = i || {}, this.tileCoord = t, this.state = e, this.interimTile = null, this.key = "", this.transition_ = i.transition === void 0 ? 250 : i.transition, this.transitionStarts_ = {}, this.interpolate = !!i.interpolate
    }

    changed() {
        this.dispatchEvent(D.CHANGE)
    }

    release() {
        this.state === k.ERROR && this.setState(k.EMPTY)
    }

    getKey() {
        return this.key + "/" + this.tileCoord
    }

    getInterimTile() {
        let t = this.interimTile;
        if (!t) return this;
        do {
            if (t.getState() == k.LOADED) return this.transition_ = 0, t;
            t = t.interimTile
        } while (t);
        return this
    }

    refreshInterimChain() {
        let t = this.interimTile;
        if (!t) return;
        let e = this;
        do {
            if (t.getState() == k.LOADED) {
                t.interimTile = null;
                break
            }
            t.getState() == k.LOADING ? e = t : t.getState() == k.IDLE ? e.interimTile = t.interimTile : e = t, t = e.interimTile
        } while (t)
    }

    getTileCoord() {
        return this.tileCoord
    }

    getState() {
        return this.state
    }

    setState(t) {
        if (this.state !== k.ERROR && this.state > t) throw new Error("Tile load sequence violation");
        this.state = t, this.changed()
    }

    load() {
        H()
    }

    getAlpha(t, e) {
        if (!this.transition_) return 1;
        let i = this.transitionStarts_[t];
        if (!i) i = e, this.transitionStarts_[t] = i; else if (i === -1) return 1;
        let r = e - i + 1e3 / 60;
        return r >= this.transition_ ? 1 : Ia(r / this.transition_)
    }

    inTransition(t) {
        return this.transition_ ? this.transitionStarts_[t] !== -1 : !1
    }

    endTransition(t) {
        this.transition_ && (this.transitionStarts_[t] = -1)
    }
}, go = Xl;
te();
Wl();
var zl = class extends go {
    constructor(t, e, i, r, s, o) {
        super(t, e, o), this.crossOrigin_ = r, this.src_ = i, this.key = i, this.image_ = new Image, r !== null && (this.image_.crossOrigin = r), this.unlisten_ = null, this.tileLoadFunction_ = s
    }

    getImage() {
        return this.image_
    }

    setImage(t) {
        this.image_ = t, this.state = k.LOADED, this.unlistenImage_(), this.changed()
    }

    handleImageError_() {
        this.state = k.ERROR, this.unlistenImage_(), this.image_ = zm(), this.changed()
    }

    handleImageLoad_() {
        let t = this.image_;
        t.naturalWidth && t.naturalHeight ? this.state = k.LOADED : this.state = k.EMPTY, this.unlistenImage_(), this.changed()
    }

    load() {
        this.state == k.ERROR && (this.state = k.IDLE, this.image_ = new Image, this.crossOrigin_ !== null && (this.image_.crossOrigin = this.crossOrigin_)), this.state == k.IDLE && (this.state = k.LOADING, this.changed(), this.tileLoadFunction_(this, this.src_), this.unlisten_ = nf(this.image_, this.handleImageLoad_.bind(this), this.handleImageError_.bind(this)))
    }

    unlistenImage_() {
        this.unlisten_ && (this.unlisten_(), this.unlisten_ = null)
    }
};

function zm() {
    let n = gt(1, 1);
    return n.fillStyle = "rgba(0,0,0,0)", n.fillRect(0, 0, 1, 1), n.canvas
}

var mo = zl;
pt();
rt();
Yt();
xt();
var Ym = 10, sf = .25, Yl = class {
    constructor(t, e, i, r, s, o) {
        this.sourceProj_ = t, this.targetProj_ = e;
        let a = {}, l = Yi(this.targetProj_, this.sourceProj_);
        this.transformInv_ = function (y) {
            let C = y[0] + "/" + y[1];
            return a[C] || (a[C] = l(y)), a[C]
        }, this.maxSourceExtent_ = r, this.errorThresholdSquared_ = s * s, this.triangles_ = [], this.wrapsXInSource_ = !1, this.canWrapXInSource_ = this.sourceProj_.canWrapX() && !!r && !!this.sourceProj_.getExtent() && $(r) >= $(this.sourceProj_.getExtent()), this.sourceWorldWidth_ = this.sourceProj_.getExtent() ? $(this.sourceProj_.getExtent()) : null, this.targetWorldWidth_ = this.targetProj_.getExtent() ? $(this.targetProj_.getExtent()) : null;
        let h = Ce(i), c = Zn(i), u = Vn(i), d = Kn(i), f = this.transformInv_(h), g = this.transformInv_(c),
            m = this.transformInv_(u), p = this.transformInv_(d),
            _ = Ym + (o ? Math.max(0, Math.ceil(Math.log2(Ar(i) / (o * o * 256 * 256)))) : 0);
        if (this.addQuad_(h, c, u, d, f, g, m, p, _), this.wrapsXInSource_) {
            let y = 1 / 0;
            this.triangles_.forEach(function (C, w, T) {
                y = Math.min(y, C.source[0][0], C.source[1][0], C.source[2][0])
            }), this.triangles_.forEach(C => {
                if (Math.max(C.source[0][0], C.source[1][0], C.source[2][0]) - y > this.sourceWorldWidth_ / 2) {
                    let w = [[C.source[0][0], C.source[0][1]], [C.source[1][0], C.source[1][1]], [C.source[2][0], C.source[2][1]]];
                    w[0][0] - y > this.sourceWorldWidth_ / 2 && (w[0][0] -= this.sourceWorldWidth_), w[1][0] - y > this.sourceWorldWidth_ / 2 && (w[1][0] -= this.sourceWorldWidth_), w[2][0] - y > this.sourceWorldWidth_ / 2 && (w[2][0] -= this.sourceWorldWidth_);
                    let T = Math.min(w[0][0], w[1][0], w[2][0]);
                    Math.max(w[0][0], w[1][0], w[2][0]) - T < this.sourceWorldWidth_ / 2 && (C.source = w)
                }
            })
        }
        a = {}
    }

    addTriangle_(t, e, i, r, s, o) {
        this.triangles_.push({source: [r, s, o], target: [t, e, i]})
    }

    addQuad_(t, e, i, r, s, o, a, l, h) {
        let c = qo([s, o, a, l]), u = this.sourceWorldWidth_ ? $(c) / this.sourceWorldWidth_ : null,
            d = this.sourceWorldWidth_, f = this.sourceProj_.canWrapX() && u > .5 && u < 1, g = !1;
        if (h > 0) {
            if (this.targetProj_.isGlobal() && this.targetWorldWidth_) {
                let p = qo([t, e, i, r]);
                g = $(p) / this.targetWorldWidth_ > sf || g
            }
            !f && this.sourceProj_.isGlobal() && u && (g = u > sf || g)
        }
        if (!g && this.maxSourceExtent_ && isFinite(c[0]) && isFinite(c[1]) && isFinite(c[2]) && isFinite(c[3]) && !yt(c, this.maxSourceExtent_)) return;
        let m = 0;
        if (!g && (!isFinite(s[0]) || !isFinite(s[1]) || !isFinite(o[0]) || !isFinite(o[1]) || !isFinite(a[0]) || !isFinite(a[1]) || !isFinite(l[0]) || !isFinite(l[1]))) {
            if (h > 0) g = !0; else if (m = (!isFinite(s[0]) || !isFinite(s[1]) ? 8 : 0) + (!isFinite(o[0]) || !isFinite(o[1]) ? 4 : 0) + (!isFinite(a[0]) || !isFinite(a[1]) ? 2 : 0) + (!isFinite(l[0]) || !isFinite(l[1]) ? 1 : 0), m != 1 && m != 2 && m != 4 && m != 8) return
        }
        if (h > 0) {
            if (!g) {
                let p = [(t[0] + i[0]) / 2, (t[1] + i[1]) / 2], _ = this.transformInv_(p), y;
                f ? y = (ke(s[0], d) + ke(a[0], d)) / 2 - ke(_[0], d) : y = (s[0] + a[0]) / 2 - _[0];
                let C = (s[1] + a[1]) / 2 - _[1];
                g = y * y + C * C > this.errorThresholdSquared_
            }
            if (g) {
                if (Math.abs(t[0] - i[0]) <= Math.abs(t[1] - i[1])) {
                    let p = [(e[0] + i[0]) / 2, (e[1] + i[1]) / 2], _ = this.transformInv_(p),
                        y = [(r[0] + t[0]) / 2, (r[1] + t[1]) / 2], C = this.transformInv_(y);
                    this.addQuad_(t, e, p, y, s, o, _, C, h - 1), this.addQuad_(y, p, i, r, C, _, a, l, h - 1)
                } else {
                    let p = [(t[0] + e[0]) / 2, (t[1] + e[1]) / 2], _ = this.transformInv_(p),
                        y = [(i[0] + r[0]) / 2, (i[1] + r[1]) / 2], C = this.transformInv_(y);
                    this.addQuad_(t, p, y, r, s, _, C, l, h - 1), this.addQuad_(p, e, i, y, _, o, a, C, h - 1)
                }
                return
            }
        }
        if (f) {
            if (!this.canWrapXInSource_) return;
            this.wrapsXInSource_ = !0
        }
        m & 11 || this.addTriangle_(t, i, r, s, a, l), m & 14 || this.addTriangle_(t, i, e, s, a, o), m && (m & 13 || this.addTriangle_(e, r, t, o, l, s), m & 7 || this.addTriangle_(e, r, i, o, l, a))
    }

    calculateSourceExtent() {
        let t = Tt();
        return this.triangles_.forEach(function (e, i, r) {
            let s = e.source;
            cn(t, s[0]), cn(t, s[1]), cn(t, s[2])
        }), t
    }

    getTriangles() {
        return this.triangles_
    }
}, of = Yl;
rt();
te();
Yt();
xt();
var Ul, wn = [];

function af(n, t, e, i, r) {
    n.beginPath(), n.moveTo(0, 0), n.lineTo(t, e), n.lineTo(i, r), n.closePath(), n.save(), n.clip(), n.fillRect(0, 0, Math.max(t, i) + 1, Math.max(e, r)), n.restore()
}

function jl(n, t) {
    return Math.abs(n[t * 4] - 210) > 2 || Math.abs(n[t * 4 + 3] - .75 * 255) > 2
}

function Um() {
    if (Ul === void 0) {
        let n = gt(6, 6, wn);
        n.globalCompositeOperation = "lighter", n.fillStyle = "rgba(210, 0, 0, 0.75)", af(n, 4, 5, 4, 0), af(n, 4, 5, 0, 5);
        let t = n.getImageData(0, 0, 3, 3).data;
        Ul = jl(t, 0) || jl(t, 4) || jl(t, 8), En(n), wn.push(n.canvas)
    }
    return Ul
}

function lf(n, t, e, i) {
    let r = pn(e, t, n), s = Ks(t, i, e), o = t.getMetersPerUnit();
    o !== void 0 && (s *= o);
    let a = n.getMetersPerUnit();
    a !== void 0 && (s /= a);
    let l = n.getExtent();
    if (!l || Gi(l, r)) {
        let h = Ks(n, s, r) / s;
        isFinite(h) && h > 0 && (s /= h)
    }
    return s
}

function hf(n, t, e, i) {
    let r = Ee(e), s = lf(n, t, r, i);
    return (!isFinite(s) || s <= 0) && As(e, function (o) {
        return s = lf(n, t, o, i), isFinite(s) && s > 0
    }), s
}

function cf(n, t, e, i, r, s, o, a, l, h, c, u, d) {
    let f = gt(Math.round(e * n), Math.round(e * t), wn);
    if (u || (f.imageSmoothingEnabled = !1), l.length === 0) return f.canvas;
    f.scale(e, e);

    function g(y) {
        return Math.round(y * e) / e
    }

    f.globalCompositeOperation = "lighter";
    let m = Tt();
    l.forEach(function (y, C, w) {
        Nc(m, y.extent)
    });
    let p;
    if (!d || l.length !== 1 || h !== 0) {
        let y = $(m), C = Lt(m);
        p = gt(Math.round(e * y / i), Math.round(e * C / i), wn), u || (p.imageSmoothingEnabled = !1);
        let w = e / i;
        l.forEach(function (T, R, A) {
            let b = T.extent[0] - m[0], O = -(T.extent[3] - m[3]), W = $(T.extent), Z = Lt(T.extent);
            T.image.width > 0 && T.image.height > 0 && p.drawImage(T.image, h, h, T.image.width - 2 * h, T.image.height - 2 * h, b * w, O * w, W * w, Z * w)
        })
    }
    let _ = Ce(o);
    return a.getTriangles().forEach(function (y, C, w) {
        let T = y.source, R = y.target, A = T[0][0], b = T[0][1], O = T[1][0], W = T[1][1], Z = T[2][0], it = T[2][1],
            j = g((R[0][0] - _[0]) / s), mt = g(-(R[0][1] - _[1]) / s), Y = g((R[1][0] - _[0]) / s),
            F = g(-(R[1][1] - _[1]) / s), P = g((R[2][0] - _[0]) / s), N = g(-(R[2][1] - _[1]) / s), nt = A, at = b;
        A = 0, b = 0, O -= nt, W -= at, Z -= nt, it -= at;
        let At = [[O, W, 0, 0, Y - j], [Z, it, 0, 0, P - j], [0, 0, O, W, F - mt], [0, 0, Z, it, N - mt]], I = eu(At);
        if (!I) return;
        if (f.save(), f.beginPath(), Um() || !u) {
            f.moveTo(Y, F);
            let q = 4, st = j - Y, pe = mt - F;
            for (let Gt = 0; Gt < q; Gt++) f.lineTo(Y + g((Gt + 1) * st / q), F + g(Gt * pe / (q - 1))), Gt != q - 1 && f.lineTo(Y + g((Gt + 1) * st / q), F + g((Gt + 1) * pe / (q - 1)));
            f.lineTo(P, N)
        } else f.moveTo(Y, F), f.lineTo(j, mt), f.lineTo(P, N);
        f.clip(), f.transform(I[0], I[2], I[1], I[3], j, mt), f.translate(m[0] - nt, m[3] - at);
        let vt;
        if (p) vt = p.canvas, f.scale(i / e, -i / e); else {
            let q = l[0], st = q.extent;
            vt = q.image, f.scale($(st) / vt.width, -Lt(st) / vt.height)
        }
        f.drawImage(vt, 0, 0), f.restore()
    }), p && (En(p), wn.push(p.canvas)), c && (f.save(), f.globalCompositeOperation = "source-over", f.strokeStyle = "black", f.lineWidth = 1, a.getTriangles().forEach(function (y, C, w) {
        let T = y.target, R = (T[0][0] - _[0]) / s, A = -(T[0][1] - _[1]) / s, b = (T[1][0] - _[0]) / s,
            O = -(T[1][1] - _[1]) / s, W = (T[2][0] - _[0]) / s, Z = -(T[2][1] - _[1]) / s;
        f.beginPath(), f.moveTo(b, O), f.lineTo(R, A), f.lineTo(W, Z), f.closePath(), f.stroke()
    }), f.restore()), f.canvas
}

xt();
rt();
fe();
te();
var Bl = class extends go {
    constructor(t, e, i, r, s, o, a, l, h, c, u, d) {
        super(s, k.IDLE, d), this.renderEdges_ = u !== void 0 ? u : !1, this.pixelRatio_ = a, this.gutter_ = l, this.canvas_ = null, this.sourceTileGrid_ = e, this.targetTileGrid_ = r, this.wrappedTileCoord_ = o || s, this.sourceTiles_ = [], this.sourcesListenerKeys_ = null, this.sourceZ_ = 0;
        let f = r.getTileCoordExtent(this.wrappedTileCoord_), g = this.targetTileGrid_.getExtent(),
            m = this.sourceTileGrid_.getExtent(), p = g ? Xi(f, g) : f;
        if (Ar(p) === 0) {
            this.state = k.EMPTY;
            return
        }
        let _ = t.getExtent();
        _ && (m ? m = Xi(m, _) : m = _);
        let y = r.getResolution(this.wrappedTileCoord_[0]), C = hf(t, i, p, y);
        if (!isFinite(C) || C <= 0) {
            this.state = k.EMPTY;
            return
        }
        let w = c !== void 0 ? c : .5;
        if (this.triangulation_ = new of(t, i, p, m, C * w, y), this.triangulation_.getTriangles().length === 0) {
            this.state = k.EMPTY;
            return
        }
        this.sourceZ_ = e.getZForResolution(C);
        let T = this.triangulation_.calculateSourceExtent();
        if (m && (t.canWrapX() ? (T[1] = ot(T[1], m[1], m[3]), T[3] = ot(T[3], m[1], m[3])) : T = Xi(T, m)), !Ar(T)) this.state = k.EMPTY; else {
            let R = e.getTileRangeForExtentAndZ(T, this.sourceZ_);
            for (let A = R.minX; A <= R.maxX; A++) for (let b = R.minY; b <= R.maxY; b++) {
                let O = h(this.sourceZ_, A, b, a);
                O && this.sourceTiles_.push(O)
            }
            this.sourceTiles_.length === 0 && (this.state = k.EMPTY)
        }
    }

    getImage() {
        return this.canvas_
    }

    reproject_() {
        let t = [];
        if (this.sourceTiles_.forEach(e => {
            e && e.getState() == k.LOADED && t.push({
                extent: this.sourceTileGrid_.getTileCoordExtent(e.tileCoord),
                image: e.getImage()
            })
        }), this.sourceTiles_.length = 0, t.length === 0) this.state = k.ERROR; else {
            let e = this.wrappedTileCoord_[0], i = this.targetTileGrid_.getTileSize(e),
                r = typeof i == "number" ? i : i[0], s = typeof i == "number" ? i : i[1],
                o = this.targetTileGrid_.getResolution(e), a = this.sourceTileGrid_.getResolution(this.sourceZ_),
                l = this.targetTileGrid_.getTileCoordExtent(this.wrappedTileCoord_);
            this.canvas_ = cf(r, s, this.pixelRatio_, a, this.sourceTileGrid_.getExtent(), o, l, this.triangulation_, t, this.gutter_, this.renderEdges_, this.interpolate), this.state = k.LOADED
        }
        this.changed()
    }

    load() {
        if (this.state == k.IDLE) {
            this.state = k.LOADING, this.changed();
            let t = 0;
            this.sourcesListenerKeys_ = [], this.sourceTiles_.forEach(e => {
                let i = e.getState();
                if (i == k.IDLE || i == k.LOADING) {
                    t++;
                    let r = U(e, D.CHANGE, function (s) {
                        let o = e.getState();
                        (o == k.LOADED || o == k.ERROR || o == k.EMPTY) && (et(r), t--, t === 0 && (this.unlistenSources_(), this.reproject_()))
                    }, this);
                    this.sourcesListenerKeys_.push(r)
                }
            }), t === 0 ? setTimeout(this.reproject_.bind(this), 0) : this.sourceTiles_.forEach(function (e, i, r) {
                e.getState() == k.IDLE && e.load()
            })
        }
    }

    unlistenSources_() {
        this.sourcesListenerKeys_.forEach(et), this.sourcesListenerKeys_ = null
    }

    release() {
        this.canvas_ && (En(this.canvas_.getContext("2d")), wn.push(this.canvas_), this.canvas_ = null), super.release()
    }
}, $r = Bl;
Zt();
var Kl = class {
    constructor(t) {
        this.highWaterMark = t !== void 0 ? t : 2048, this.count_ = 0, this.entries_ = {}, this.oldest_ = null, this.newest_ = null
    }

    canExpireCache() {
        return this.highWaterMark > 0 && this.getCount() > this.highWaterMark
    }

    expireCache(t) {
        for (; this.canExpireCache();) this.pop()
    }

    clear() {
        this.count_ = 0, this.entries_ = {}, this.oldest_ = null, this.newest_ = null
    }

    containsKey(t) {
        return this.entries_.hasOwnProperty(t)
    }

    forEach(t) {
        let e = this.oldest_;
        for (; e;) t(e.value_, e.key_, this), e = e.newer
    }

    get(t, e) {
        let i = this.entries_[t];
        return z(i !== void 0, "Tried to get a value for a key that does not exist in the cache"), i === this.newest_ || (i === this.oldest_ ? (this.oldest_ = this.oldest_.newer, this.oldest_.older = null) : (i.newer.older = i.older, i.older.newer = i.newer), i.newer = null, i.older = this.newest_, this.newest_.newer = i, this.newest_ = i), i.value_
    }

    remove(t) {
        let e = this.entries_[t];
        return z(e !== void 0, "Tried to get a value for a key that does not exist in the cache"), e === this.newest_ ? (this.newest_ = e.older, this.newest_ && (this.newest_.newer = null)) : e === this.oldest_ ? (this.oldest_ = e.newer, this.oldest_ && (this.oldest_.older = null)) : (e.newer.older = e.older, e.older.newer = e.newer), delete this.entries_[t], --this.count_, e.value_
    }

    getCount() {
        return this.count_
    }

    getKeys() {
        let t = new Array(this.count_), e = 0, i;
        for (i = this.newest_; i; i = i.older) t[e++] = i.key_;
        return t
    }

    getValues() {
        let t = new Array(this.count_), e = 0, i;
        for (i = this.newest_; i; i = i.older) t[e++] = i.value_;
        return t
    }

    peekLast() {
        return this.oldest_.value_
    }

    peekLastKey() {
        return this.oldest_.key_
    }

    peekFirstKey() {
        return this.newest_.key_
    }

    peek(t) {
        return this.entries_[t]?.value_
    }

    pop() {
        let t = this.oldest_;
        return delete this.entries_[t.key_], t.newer && (t.newer.older = null), this.oldest_ = t.newer, this.oldest_ || (this.newest_ = null), --this.count_, t.value_
    }

    replace(t, e) {
        this.get(t), this.entries_[t].value_ = e
    }

    set(t, e) {
        z(!(t in this.entries_), "Tried to set a value for a key that is used already");
        let i = {key_: t, newer: null, older: this.newest_, value_: e};
        this.newest_ ? this.newest_.newer = i : this.oldest_ = i, this.newest_ = i, this.entries_[t] = i, ++this.count_
    }

    setSize(t) {
        this.highWaterMark = t
    }
}, uf = Kl;

function Vl(n, t, e, i) {
    return i !== void 0 ? (i[0] = n, i[1] = t, i[2] = e, i) : [n, t, e]
}

function Tn(n, t, e) {
    return n + "/" + t + "/" + e
}

function po(n) {
    return Tn(n[0], n[1], n[2])
}

function df(n) {
    return n.split("/").map(Number)
}

function ff(n) {
    return (n[1] << n[0]) + n[2]
}

function gf(n, t) {
    let e = n[0], i = n[1], r = n[2];
    if (t.getMinZoom() > e || e > t.getMaxZoom()) return !1;
    let s = t.getFullTileRange(e);
    return s ? s.containsXY(i, r) : !0
}

var Zl = class extends uf {
    clear() {
        for (; this.getCount() > 0;) this.pop().release();
        super.clear()
    }

    expireCache(t) {
        for (; this.canExpireCache() && !(this.peekLast().getKey() in t);) this.pop().release()
    }

    pruneExceptNewestZ() {
        if (this.getCount() === 0) return;
        let t = this.peekFirstKey(), i = df(t)[0];
        this.forEach(r => {
            r.tileCoord[0] !== i && (this.remove(po(r.tileCoord)), r.release())
        })
    }
}, _o = Zl;
var yo = {TILELOADSTART: "tileloadstart", TILELOADEND: "tileloadend", TILELOADERROR: "tileloaderror"};
je();
Hl();
wt();
Zt();
Yt();
var Eo = class {
    constructor(t, e, i, r) {
        this.minX = t, this.maxX = e, this.minY = i, this.maxY = r
    }

    contains(t) {
        return this.containsXY(t[1], t[2])
    }

    containsTileRange(t) {
        return this.minX <= t.minX && t.maxX <= this.maxX && this.minY <= t.minY && t.maxY <= this.maxY
    }

    containsXY(t, e) {
        return this.minX <= t && t <= this.maxX && this.minY <= e && e <= this.maxY
    }

    equals(t) {
        return this.minX == t.minX && this.minY == t.minY && this.maxX == t.maxX && this.maxY == t.maxY
    }

    extend(t) {
        t.minX < this.minX && (this.minX = t.minX), t.maxX > this.maxX && (this.maxX = t.maxX), t.minY < this.minY && (this.minY = t.minY), t.maxY > this.maxY && (this.maxY = t.maxY)
    }

    getHeight() {
        return this.maxY - this.minY + 1
    }

    getSize() {
        return [this.getWidth(), this.getHeight()]
    }

    getWidth() {
        return this.maxX - this.minX + 1
    }

    intersects(t) {
        return this.minX <= t.maxX && this.maxX >= t.minX && this.minY <= t.maxY && this.maxY >= t.minY
    }
};

function vn(n, t, e, i, r) {
    return r !== void 0 ? (r.minX = n, r.maxX = t, r.minY = e, r.maxY = i, r) : new Eo(n, t, e, i)
}

var Co = Eo;
Zt();
xt();
rt();
Ya();
Ct();
Ri();
var pr = [0, 0, 0], Qi = 5, $l = class {
    constructor(t) {
        this.minZoom = t.minZoom !== void 0 ? t.minZoom : 0, this.resolutions_ = t.resolutions, z(Ac(this.resolutions_, (r, s) => s - r, !0), "`resolutions` must be sorted in descending order");
        let e;
        if (!t.origins) {
            for (let r = 0, s = this.resolutions_.length - 1; r < s; ++r) if (!e) e = this.resolutions_[r] / this.resolutions_[r + 1]; else if (this.resolutions_[r] / this.resolutions_[r + 1] !== e) {
                e = void 0;
                break
            }
        }
        this.zoomFactor_ = e, this.maxZoom = this.resolutions_.length - 1, this.origin_ = t.origin !== void 0 ? t.origin : null, this.origins_ = null, t.origins !== void 0 && (this.origins_ = t.origins, z(this.origins_.length == this.resolutions_.length, "Number of `origins` and `resolutions` must be equal"));
        let i = t.extent;
        i !== void 0 && !this.origin_ && !this.origins_ && (this.origin_ = Ce(i)), z(!this.origin_ && this.origins_ || this.origin_ && !this.origins_, "Either `origin` or `origins` must be configured, never both"), this.tileSizes_ = null, t.tileSizes !== void 0 && (this.tileSizes_ = t.tileSizes, z(this.tileSizes_.length == this.resolutions_.length, "Number of `tileSizes` and `resolutions` must be equal")), this.tileSize_ = t.tileSize !== void 0 ? t.tileSize : this.tileSizes_ ? null : 256, z(!this.tileSize_ && this.tileSizes_ || this.tileSize_ && !this.tileSizes_, "Either `tileSize` or `tileSizes` must be configured, never both"), this.extent_ = i !== void 0 ? i : null, this.fullTileRanges_ = null, this.tmpSize_ = [0, 0], this.tmpExtent_ = [0, 0, 0, 0], t.sizes !== void 0 ? this.fullTileRanges_ = t.sizes.map((r, s) => {
            let o = new Co(Math.min(0, r[0]), Math.max(r[0] - 1, -1), Math.min(0, r[1]), Math.max(r[1] - 1, -1));
            if (i) {
                let a = this.getTileRangeForExtentAndZ(i, s);
                o.minX = Math.max(a.minX, o.minX), o.maxX = Math.min(a.maxX, o.maxX), o.minY = Math.max(a.minY, o.minY), o.maxY = Math.min(a.maxY, o.maxY)
            }
            return o
        }) : i && this.calculateTileRanges_(i)
    }

    forEachTileCoord(t, e, i) {
        let r = this.getTileRangeForExtentAndZ(t, e);
        for (let s = r.minX, o = r.maxX; s <= o; ++s) for (let a = r.minY, l = r.maxY; a <= l; ++a) i([e, s, a])
    }

    forEachTileCoordParentTileRange(t, e, i, r) {
        let s, o, a, l = null, h = t[0] - 1;
        for (this.zoomFactor_ === 2 ? (o = t[1], a = t[2]) : l = this.getTileCoordExtent(t, r); h >= this.minZoom;) {
            if (o !== void 0 && a !== void 0 ? (o = Math.floor(o / 2), a = Math.floor(a / 2), s = vn(o, o, a, a, i)) : s = this.getTileRangeForExtentAndZ(l, h, i), e(h, s)) return !0;
            --h
        }
        return !1
    }

    getExtent() {
        return this.extent_
    }

    getMaxZoom() {
        return this.maxZoom
    }

    getMinZoom() {
        return this.minZoom
    }

    getOrigin(t) {
        return this.origin_ ? this.origin_ : this.origins_[t]
    }

    getResolution(t) {
        return this.resolutions_[t]
    }

    getResolutions() {
        return this.resolutions_
    }

    getTileCoordChildTileRange(t, e, i) {
        if (t[0] < this.maxZoom) {
            if (this.zoomFactor_ === 2) {
                let s = t[1] * 2, o = t[2] * 2;
                return vn(s, s + 1, o, o + 1, e)
            }
            let r = this.getTileCoordExtent(t, i || this.tmpExtent_);
            return this.getTileRangeForExtentAndZ(r, t[0] + 1, e)
        }
        return null
    }

    getTileRangeForTileCoordAndZ(t, e, i) {
        if (e > this.maxZoom || e < this.minZoom) return null;
        let r = t[0], s = t[1], o = t[2];
        if (e === r) return vn(s, o, s, o, i);
        if (this.zoomFactor_) {
            let l = Math.pow(this.zoomFactor_, e - r), h = Math.floor(s * l), c = Math.floor(o * l);
            if (e < r) return vn(h, h, c, c, i);
            let u = Math.floor(l * (s + 1)) - 1, d = Math.floor(l * (o + 1)) - 1;
            return vn(h, u, c, d, i)
        }
        let a = this.getTileCoordExtent(t, this.tmpExtent_);
        return this.getTileRangeForExtentAndZ(a, e, i)
    }

    getTileRangeForExtentAndZ(t, e, i) {
        this.getTileCoordForXYAndZ_(t[0], t[3], e, !1, pr);
        let r = pr[1], s = pr[2];
        this.getTileCoordForXYAndZ_(t[2], t[1], e, !0, pr);
        let o = pr[1], a = pr[2];
        return vn(r, o, s, a, i)
    }

    getTileCoordCenter(t) {
        let e = this.getOrigin(t[0]), i = this.getResolution(t[0]), r = bt(this.getTileSize(t[0]), this.tmpSize_);
        return [e[0] + (t[1] + .5) * r[0] * i, e[1] - (t[2] + .5) * r[1] * i]
    }

    getTileCoordExtent(t, e) {
        let i = this.getOrigin(t[0]), r = this.getResolution(t[0]), s = bt(this.getTileSize(t[0]), this.tmpSize_),
            o = i[0] + t[1] * s[0] * r, a = i[1] - (t[2] + 1) * s[1] * r, l = o + s[0] * r, h = a + s[1] * r;
        return ge(o, a, l, h, e)
    }

    getTileCoordForCoordAndResolution(t, e, i) {
        return this.getTileCoordForXYAndResolution_(t[0], t[1], e, !1, i)
    }

    getTileCoordForXYAndResolution_(t, e, i, r, s) {
        let o = this.getZForResolution(i), a = i / this.getResolution(o), l = this.getOrigin(o),
            h = bt(this.getTileSize(o), this.tmpSize_), c = a * (t - l[0]) / i / h[0], u = a * (l[1] - e) / i / h[1];
        return r ? (c = Fr(c, Qi) - 1, u = Fr(u, Qi) - 1) : (c = Or(c, Qi), u = Or(u, Qi)), Vl(o, c, u, s)
    }

    getTileCoordForXYAndZ_(t, e, i, r, s) {
        let o = this.getOrigin(i), a = this.getResolution(i), l = bt(this.getTileSize(i), this.tmpSize_),
            h = (t - o[0]) / a / l[0], c = (o[1] - e) / a / l[1];
        return r ? (h = Fr(h, Qi) - 1, c = Fr(c, Qi) - 1) : (h = Or(h, Qi), c = Or(c, Qi)), Vl(i, h, c, s)
    }

    getTileCoordForCoordAndZ(t, e, i) {
        return this.getTileCoordForXYAndZ_(t[0], t[1], e, !1, i)
    }

    getTileCoordResolution(t) {
        return this.resolutions_[t[0]]
    }

    getTileSize(t) {
        return this.tileSize_ ? this.tileSize_ : this.tileSizes_[t]
    }

    getFullTileRange(t) {
        return this.fullTileRanges_ ? this.fullTileRanges_[t] : this.extent_ ? this.getTileRangeForExtentAndZ(this.extent_, t) : null
    }

    getZForResolution(t, e) {
        let i = kn(this.resolutions_, t, e || 0);
        return ot(i, this.minZoom, this.maxZoom)
    }

    tileCoordIntersectsViewport(t, e) {
        return za(e, 0, e.length, 2, this.getTileCoordExtent(t))
    }

    calculateTileRanges_(t) {
        let e = this.resolutions_.length, i = new Array(e);
        for (let r = this.minZoom; r < e; ++r) i[r] = this.getTileRangeForExtentAndZ(t, r);
        this.fullTileRanges_ = i
    }
}, Jl = $l;
Yt();
rt();
Ri();

function wo(n) {
    let t = n.getDefaultTileGrid();
    return t || (t = Bm(n), n.setDefaultTileGrid(t)), t
}

function pf(n, t, e) {
    let i = t[0], r = n.getTileCoordCenter(t), s = To(e);
    if (!Gi(s, r)) {
        let o = $(s), a = Math.ceil((s[0] - r[0]) / o);
        return r[0] += o * a, n.getTileCoordForCoordAndZ(r, i)
    }
    return t
}

function jm(n, t, e, i) {
    i = i !== void 0 ? i : "top-left";
    let r = yf(n, t, e);
    return new Jl({extent: n, origin: Gc(n, i), resolutions: r, tileSize: e})
}

function _f(n) {
    let t = n || {}, e = t.extent || ft("EPSG:3857").getExtent(), i = {
        extent: e,
        minZoom: t.minZoom,
        tileSize: t.tileSize,
        resolutions: yf(e, t.maxZoom, t.tileSize, t.maxResolution)
    };
    return new Jl(i)
}

function yf(n, t, e, i) {
    t = t !== void 0 ? t : 42, e = bt(e !== void 0 ? e : 256);
    let r = Lt(n), s = $(n);
    i = i > 0 ? i : Math.max(s / e[0], r / e[1]);
    let o = t + 1, a = new Array(o);
    for (let l = 0; l < o; ++l) a[l] = i / Math.pow(2, l);
    return a
}

function Bm(n, t, e, i) {
    let r = To(n);
    return jm(r, t, e, i)
}

function To(n) {
    n = ft(n);
    let t = n.getExtent();
    if (!t) {
        let e = 180 * Ke.degrees / n.getMetersPerUnit();
        t = ge(-e, -e, e, e)
    }
    return t
}

Ri();
var Ql = class extends xo {
    constructor(t) {
        super({
            attributions: t.attributions,
            attributionsCollapsible: t.attributionsCollapsible,
            projection: t.projection,
            state: t.state,
            wrapX: t.wrapX,
            interpolate: t.interpolate
        }), this.on, this.once, this.un, this.opaque_ = t.opaque !== void 0 ? t.opaque : !1, this.tilePixelRatio_ = t.tilePixelRatio !== void 0 ? t.tilePixelRatio : 1, this.tileGrid = t.tileGrid !== void 0 ? t.tileGrid : null;
        let e = [256, 256];
        this.tileGrid && bt(this.tileGrid.getTileSize(this.tileGrid.getMinZoom()), e), this.tileCache = new _o(t.cacheSize || 0), this.tmpSize = [0, 0], this.key_ = t.key || "", this.tileOptions = {
            transition: t.transition,
            interpolate: t.interpolate
        }, this.zDirection = t.zDirection ? t.zDirection : 0
    }

    canExpireCache() {
        return this.tileCache.canExpireCache()
    }

    expireCache(t, e) {
        let i = this.getTileCacheForProjection(t);
        i && i.expireCache(e)
    }

    forEachLoadedTile(t, e, i, r) {
        let s = this.getTileCacheForProjection(t);
        if (!s) return !1;
        let o = !0, a, l, h;
        for (let c = i.minX; c <= i.maxX; ++c) for (let u = i.minY; u <= i.maxY; ++u) l = Tn(e, c, u), h = !1, s.containsKey(l) && (a = s.get(l), h = a.getState() === k.LOADED, h && (h = r(a) !== !1)), h || (o = !1);
        return o
    }

    getGutterForProjection(t) {
        return 0
    }

    getKey() {
        return this.key_
    }

    setKey(t) {
        this.key_ !== t && (this.key_ = t, this.changed())
    }

    getOpaque(t) {
        return this.opaque_
    }

    getResolutions(t) {
        let e = t ? this.getTileGridForProjection(t) : this.tileGrid;
        return e ? e.getResolutions() : null
    }

    getTile(t, e, i, r, s) {
        return H()
    }

    getTileGrid() {
        return this.tileGrid
    }

    getTileGridForProjection(t) {
        return this.tileGrid ? this.tileGrid : wo(t)
    }

    getTileCacheForProjection(t) {
        let e = this.getProjection();
        return z(e === null || yi(e, t), "A VectorTile source can only be rendered if it has a projection compatible with the view projection."), this.tileCache
    }

    getTilePixelRatio(t) {
        return this.tilePixelRatio_
    }

    getTilePixelSize(t, e, i) {
        let r = this.getTileGridForProjection(i), s = this.getTilePixelRatio(e), o = bt(r.getTileSize(t), this.tmpSize);
        return s == 1 ? o : Hd(o, s, this.tmpSize)
    }

    getTileCoordForTileUrlFunction(t, e) {
        e = e !== void 0 ? e : this.getProjection();
        let i = this.getTileGridForProjection(e);
        return this.getWrapX() && e.isGlobal() && (t = pf(i, t, e)), gf(t, i) ? t : null
    }

    clear() {
        this.tileCache.clear()
    }

    refresh() {
        this.clear(), super.refresh()
    }

    updateCacheSize(t, e) {
        let i = this.getTileCacheForProjection(e);
        t > i.highWaterMark && (i.highWaterMark = t)
    }

    useTile(t, e, i, r) {
    }
}, vo = class extends Ft {
    constructor(t, e) {
        super(t), this.tile = e
    }
}, xf = Ql;
xt();

function Km(n, t) {
    let e = /\{z\}/g, i = /\{x\}/g, r = /\{y\}/g, s = /\{-y\}/g;
    return function (o, a, l) {
        if (o) return n.replace(e, o[0].toString()).replace(i, o[1].toString()).replace(r, o[2].toString()).replace(s, function () {
            let h = o[0], c = t.getFullTileRange(h);
            if (!c) throw new Error("The {-y} placeholder requires a tile grid with extent");
            return (c.getHeight() - o[2] - 1).toString()
        })
    }
}

function Ef(n, t) {
    let e = n.length, i = new Array(e);
    for (let r = 0; r < e; ++r) i[r] = Km(n[r], t);
    return Vm(i)
}

function Vm(n) {
    return n.length === 1 ? n[0] : function (t, e, i) {
        if (!t) return;
        let r = ff(t), s = ke(r, n.length);
        return n[s](t, e, i)
    }
}

function Cf(n) {
    let t = [], e = /\{([a-z])-([a-z])\}/.exec(n);
    if (e) {
        let i = e[1].charCodeAt(0), r = e[2].charCodeAt(0), s;
        for (s = i; s <= r; ++s) t.push(n.replace(e[0], String.fromCharCode(s)));
        return t
    }
    if (e = /\{(\d+)-(\d+)\}/.exec(n), e) {
        let i = parseInt(e[2], 10);
        for (let r = parseInt(e[1], 10); r <= i; r++) t.push(n.replace(e[0], r.toString()));
        return t
    }
    return t.push(n), t
}

wt();
var th = class n extends xf {
    constructor(t) {
        super({
            attributions: t.attributions,
            cacheSize: t.cacheSize,
            opaque: t.opaque,
            projection: t.projection,
            state: t.state,
            tileGrid: t.tileGrid,
            tilePixelRatio: t.tilePixelRatio,
            wrapX: t.wrapX,
            transition: t.transition,
            interpolate: t.interpolate,
            key: t.key,
            attributionsCollapsible: t.attributionsCollapsible,
            zDirection: t.zDirection
        }), this.generateTileUrlFunction_ = this.tileUrlFunction === n.prototype.tileUrlFunction, this.tileLoadFunction = t.tileLoadFunction, t.tileUrlFunction && (this.tileUrlFunction = t.tileUrlFunction), this.urls = null, t.urls ? this.setUrls(t.urls) : t.url && this.setUrl(t.url), this.tileLoadingKeys_ = {}
    }

    getTileLoadFunction() {
        return this.tileLoadFunction
    }

    getTileUrlFunction() {
        return Object.getPrototypeOf(this).tileUrlFunction === this.tileUrlFunction ? this.tileUrlFunction.bind(this) : this.tileUrlFunction
    }

    getUrls() {
        return this.urls
    }

    handleTileChange(t) {
        let e = t.target, i = K(e), r = e.getState(), s;
        r == k.LOADING ? (this.tileLoadingKeys_[i] = !0, s = yo.TILELOADSTART) : i in this.tileLoadingKeys_ && (delete this.tileLoadingKeys_[i], s = r == k.ERROR ? yo.TILELOADERROR : r == k.LOADED ? yo.TILELOADEND : void 0), s != null && this.dispatchEvent(new vo(s, e))
    }

    setTileLoadFunction(t) {
        this.tileCache.clear(), this.tileLoadFunction = t, this.changed()
    }

    setTileUrlFunction(t, e) {
        this.tileUrlFunction = t, this.tileCache.pruneExceptNewestZ(), typeof e < "u" ? this.setKey(e) : this.changed()
    }

    setUrl(t) {
        let e = Cf(t);
        this.urls = e, this.setUrls(e)
    }

    setUrls(t) {
        this.urls = t;
        let e = t.join(`
`);
        this.generateTileUrlFunction_ ? this.setTileUrlFunction(Ef(t, this.tileGrid), e) : this.setKey(e)
    }

    tileUrlFunction(t, e, i) {
    }

    useTile(t, e, i) {
        let r = Tn(t, e, i);
        this.tileCache.containsKey(r) && this.tileCache.get(r)
    }
}, wf = th;
Yt();
wt();
var eh = class extends wf {
    constructor(t) {
        super({
            attributions: t.attributions,
            cacheSize: t.cacheSize,
            opaque: t.opaque,
            projection: t.projection,
            state: t.state,
            tileGrid: t.tileGrid,
            tileLoadFunction: t.tileLoadFunction ? t.tileLoadFunction : Zm,
            tilePixelRatio: t.tilePixelRatio,
            tileUrlFunction: t.tileUrlFunction,
            url: t.url,
            urls: t.urls,
            wrapX: t.wrapX,
            transition: t.transition,
            interpolate: t.interpolate !== void 0 ? t.interpolate : !0,
            key: t.key,
            attributionsCollapsible: t.attributionsCollapsible,
            zDirection: t.zDirection
        }), this.crossOrigin = t.crossOrigin !== void 0 ? t.crossOrigin : null, this.tileClass = t.tileClass !== void 0 ? t.tileClass : mo, this.tileCacheForProjection = {}, this.tileGridForProjection = {}, this.reprojectionErrorThreshold_ = t.reprojectionErrorThreshold, this.renderReprojectionEdges_ = !1
    }

    canExpireCache() {
        if (this.tileCache.canExpireCache()) return !0;
        for (let t in this.tileCacheForProjection) if (this.tileCacheForProjection[t].canExpireCache()) return !0;
        return !1
    }

    expireCache(t, e) {
        let i = this.getTileCacheForProjection(t);
        this.tileCache.expireCache(this.tileCache == i ? e : {});
        for (let r in this.tileCacheForProjection) {
            let s = this.tileCacheForProjection[r];
            s.expireCache(s == i ? e : {})
        }
    }

    getGutterForProjection(t) {
        return this.getProjection() && t && !yi(this.getProjection(), t) ? 0 : this.getGutter()
    }

    getGutter() {
        return 0
    }

    getKey() {
        let t = super.getKey();
        return this.getInterpolate() || (t += ":disable-interpolation"), t
    }

    getOpaque(t) {
        return this.getProjection() && t && !yi(this.getProjection(), t) ? !1 : super.getOpaque(t)
    }

    getTileGridForProjection(t) {
        let e = this.getProjection();
        if (this.tileGrid && (!e || yi(e, t))) return this.tileGrid;
        let i = K(t);
        return i in this.tileGridForProjection || (this.tileGridForProjection[i] = wo(t)), this.tileGridForProjection[i]
    }

    getTileCacheForProjection(t) {
        let e = this.getProjection();
        if (!e || yi(e, t)) return this.tileCache;
        let i = K(t);
        return i in this.tileCacheForProjection || (this.tileCacheForProjection[i] = new _o(this.tileCache.highWaterMark)), this.tileCacheForProjection[i]
    }

    createTile_(t, e, i, r, s, o) {
        let a = [t, e, i], l = this.getTileCoordForTileUrlFunction(a, s),
            h = l ? this.tileUrlFunction(l, r, s) : void 0,
            c = new this.tileClass(a, h !== void 0 ? k.IDLE : k.EMPTY, h !== void 0 ? h : "", this.crossOrigin, this.tileLoadFunction, this.tileOptions);
        return c.key = o, c.addEventListener(D.CHANGE, this.handleTileChange.bind(this)), c
    }

    getTile(t, e, i, r, s) {
        let o = this.getProjection();
        if (!o || !s || yi(o, s)) return this.getTileInternal(t, e, i, r, o || s);
        let a = this.getTileCacheForProjection(s), l = [t, e, i], h, c = po(l);
        a.containsKey(c) && (h = a.get(c));
        let u = this.getKey();
        if (h && h.key == u) return h;
        let d = this.getTileGridForProjection(o), f = this.getTileGridForProjection(s),
            g = this.getTileCoordForTileUrlFunction(l, s),
            m = new $r(o, d, s, f, l, g, this.getTilePixelRatio(r), this.getGutter(), (p, _, y, C) => this.getTileInternal(p, _, y, C, o), this.reprojectionErrorThreshold_, this.renderReprojectionEdges_, this.tileOptions);
        return m.key = u, h ? (m.interimTile = h, m.refreshInterimChain(), a.replace(c, m)) : a.set(c, m), m
    }

    getTileInternal(t, e, i, r, s) {
        let o = null, a = Tn(t, e, i), l = this.getKey();
        if (!this.tileCache.containsKey(a)) o = this.createTile_(t, e, i, r, s, l), this.tileCache.set(a, o); else if (o = this.tileCache.get(a), o.key != l) {
            let h = o;
            o = this.createTile_(t, e, i, r, s, l), h.getState() == k.IDLE ? o.interimTile = h.interimTile : o.interimTile = h, o.refreshInterimChain(), this.tileCache.replace(a, o)
        }
        return o
    }

    setRenderReprojectionEdges(t) {
        if (this.renderReprojectionEdges_ != t) {
            this.renderReprojectionEdges_ = t;
            for (let e in this.tileCacheForProjection) this.tileCacheForProjection[e].clear();
            this.changed()
        }
    }

    setTileGridForProjection(t, e) {
        let i = ft(t);
        if (i) {
            let r = K(i);
            r in this.tileGridForProjection || (this.tileGridForProjection[r] = e)
        }
    }

    clear() {
        super.clear();
        for (let t in this.tileCacheForProjection) this.tileCacheForProjection[t].clear()
    }
};

function Zm(n, t) {
    n.getImage().src = t
}

var Tf = eh;
var ih = class extends Tf {
    constructor(t) {
        t = t || {};
        let e = t.projection !== void 0 ? t.projection : "EPSG:3857", i = t.tileGrid !== void 0 ? t.tileGrid : _f({
            extent: To(e),
            maxResolution: t.maxResolution,
            maxZoom: t.maxZoom,
            minZoom: t.minZoom,
            tileSize: t.tileSize
        });
        super({
            attributions: t.attributions,
            cacheSize: t.cacheSize,
            crossOrigin: t.crossOrigin,
            interpolate: t.interpolate,
            opaque: t.opaque,
            projection: e,
            reprojectionErrorThreshold: t.reprojectionErrorThreshold,
            tileGrid: i,
            tileLoadFunction: t.tileLoadFunction,
            tilePixelRatio: t.tilePixelRatio,
            tileUrlFunction: t.tileUrlFunction,
            url: t.url,
            urls: t.urls,
            wrapX: t.wrapX !== void 0 ? t.wrapX : !0,
            transition: t.transition,
            attributionsCollapsible: t.attributionsCollapsible,
            zDirection: t.zDirection
        }), this.gutter_ = t.gutter !== void 0 ? t.gutter : 0
    }

    getGutter() {
        return this.gutter_
    }
}, vf = ih;
var qm = '&#169; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors.',
    nh = class extends vf {
        constructor(t) {
            t = t || {};
            let e;
            t.attributions !== void 0 ? e = t.attributions : e = [qm];
            let i = t.crossOrigin !== void 0 ? t.crossOrigin : "anonymous",
                r = t.url !== void 0 ? t.url : "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
            super({
                attributions: e,
                attributionsCollapsible: !1,
                cacheSize: t.cacheSize,
                crossOrigin: i,
                interpolate: t.interpolate,
                maxZoom: t.maxZoom !== void 0 ? t.maxZoom : 19,
                opaque: t.opaque !== void 0 ? t.opaque : !0,
                reprojectionErrorThreshold: t.reprojectionErrorThreshold,
                tileLoadFunction: t.tileLoadFunction,
                transition: t.transition,
                url: r,
                wrapX: t.wrapX,
                zDirection: t.zDirection
            })
        }
    }, Rf = nh;
lr();
var Jr = {PRELOAD: "preload", USE_INTERIM_TILES_ON_ERROR: "useInterimTilesOnError"};
var rh = class extends xn {
    constructor(t) {
        t = t || {};
        let e = Object.assign({}, t);
        delete e.preload, delete e.useInterimTilesOnError, super(e), this.on, this.once, this.un, this.setPreload(t.preload !== void 0 ? t.preload : 0), this.setUseInterimTilesOnError(t.useInterimTilesOnError !== void 0 ? t.useInterimTilesOnError : !0)
    }

    getPreload() {
        return this.get(Jr.PRELOAD)
    }

    setPreload(t) {
        this.set(Jr.PRELOAD, t)
    }

    getUseInterimTilesOnError() {
        return this.get(Jr.USE_INTERIM_TILES_ON_ERROR)
    }

    setUseInterimTilesOnError(t) {
        this.set(Jr.USE_INTERIM_TILES_ON_ERROR, t)
    }

    getData(t) {
        return super.getData(t)
    }
}, Sf = rh;
lh();
De();
Ct();
rt();
Yt();
wt();
Ri();
var hh = class extends Ro {
    constructor(t) {
        super(t), this.extentChanged = !0, this.renderedExtent_ = null, this.renderedPixelRatio, this.renderedProjection = null, this.renderedRevision, this.renderedTiles = [], this.newTiles_ = !1, this.tmpExtent = Tt(), this.tmpTileRange_ = new Co(0, 0, 0, 0)
    }

    isDrawableTile(t) {
        let e = this.getLayer(), i = t.getState(), r = e.getUseInterimTilesOnError();
        return i == k.LOADED || i == k.EMPTY || i == k.ERROR && !r
    }

    getTile(t, e, i, r) {
        let s = r.pixelRatio, o = r.viewState.projection, a = this.getLayer(), h = a.getSource().getTile(t, e, i, s, o);
        return h.getState() == k.ERROR && a.getUseInterimTilesOnError() && a.getPreload() > 0 && (this.newTiles_ = !0), this.isDrawableTile(h) || (h = h.getInterimTile()), h
    }

    getData(t) {
        let e = this.frameState;
        if (!e) return null;
        let i = this.getLayer(), r = _t(e.pixelToCoordinateTransform, t.slice()), s = i.getExtent();
        if (s && !Gi(s, r)) return null;
        let o = e.pixelRatio, a = e.viewState.projection, l = e.viewState, h = i.getRenderSource(),
            c = h.getTileGridForProjection(l.projection), u = h.getTilePixelRatio(e.pixelRatio);
        for (let d = c.getZForResolution(l.resolution); d >= c.getMinZoom(); --d) {
            let f = c.getTileCoordForCoordAndZ(r, d), g = h.getTile(d, f[1], f[2], o, a);
            if (!(g instanceof mo || g instanceof $r) || g instanceof $r && g.getState() === k.EMPTY) return null;
            if (g.getState() !== k.LOADED) continue;
            let m = c.getOrigin(d), p = bt(c.getTileSize(d)), _ = c.getResolution(d),
                y = Math.floor(u * ((r[0] - m[0]) / _ - f[1] * p[0])),
                C = Math.floor(u * ((m[1] - r[1]) / _ - f[2] * p[1])),
                w = Math.round(u * h.getGutterForProjection(l.projection));
            return this.getImageData(g.getImage(), y + w, C + w)
        }
        return null
    }

    loadedTileCallback(t, e, i) {
        return this.isDrawableTile(i) ? super.loadedTileCallback(t, e, i) : !1
    }

    prepareFrame(t) {
        return !!this.getLayer().getSource()
    }

    renderFrame(t, e) {
        let i = t.layerStatesArray[t.layerIndex], r = t.viewState, s = r.projection, o = r.resolution, a = r.center,
            l = r.rotation, h = t.pixelRatio, c = this.getLayer(), u = c.getSource(), d = u.getRevision(),
            f = u.getTileGridForProjection(s), g = f.getZForResolution(o, u.zDirection), m = f.getResolution(g),
            p = t.extent, _ = t.viewState.resolution, y = u.getTilePixelRatio(h), C = Math.round($(p) / _ * h),
            w = Math.round(Lt(p) / _ * h), T = i.extent && ve(i.extent, s);
        T && (p = Xi(p, ve(i.extent, s)));
        let R = m * C / 2 / y, A = m * w / 2 / y, b = [a[0] - R, a[1] - A, a[0] + R, a[1] + A],
            O = f.getTileRangeForExtentAndZ(p, g), W = {};
        W[g] = {};
        let Z = this.createLoadedTileFinder(u, s, W), it = this.tmpExtent, j = this.tmpTileRange_;
        this.newTiles_ = !1;
        let mt = l ? Ms(r.center, _, l, t.size) : void 0;
        for (let vt = O.minX; vt <= O.maxX; ++vt) for (let q = O.minY; q <= O.maxY; ++q) {
            if (l && !f.tileCoordIntersectsViewport([g, vt, q], mt)) continue;
            let st = this.getTile(g, vt, q, t);
            if (this.isDrawableTile(st)) {
                let ee = K(this);
                if (st.getState() == k.LOADED) {
                    W[g][st.tileCoord.toString()] = st;
                    let _e = st.inTransition(ee);
                    _e && i.opacity !== 1 && (st.endTransition(ee), _e = !1), !this.newTiles_ && (_e || !this.renderedTiles.includes(st)) && (this.newTiles_ = !0)
                }
                if (st.getAlpha(ee, t.time) === 1) continue
            }
            let pe = f.getTileCoordChildTileRange(st.tileCoord, j, it), Gt = !1;
            pe && (Gt = Z(g + 1, pe)), Gt || f.forEachTileCoordParentTileRange(st.tileCoord, Z, j, it)
        }
        let Y = m / o * h / y;
        zt(this.pixelTransform, t.size[0] / 2, t.size[1] / 2, 1 / h, 1 / h, l, -C / 2, -w / 2);
        let F = Rs(this.pixelTransform);
        this.useContainer(e, F, this.getBackground(t));
        let P = this.context, N = P.canvas;
        Un(this.inversePixelTransform, this.pixelTransform), zt(this.tempTransform, C / 2, w / 2, Y, Y, 0, -C / 2, -w / 2), N.width != C || N.height != w ? (N.width = C, N.height = w) : this.containerReused || P.clearRect(0, 0, C, w), T && this.clipUnrotated(P, t, T), u.getInterpolate() || (P.imageSmoothingEnabled = !1), this.preRender(P, t), this.renderedTiles.length = 0;
        let nt = Object.keys(W).map(Number);
        nt.sort(de);
        let at, At, I;
        i.opacity === 1 && (!this.containerReused || u.getOpaque(t.viewState.projection)) ? nt = nt.reverse() : (at = [], At = []);
        for (let vt = nt.length - 1; vt >= 0; --vt) {
            let q = nt[vt], st = u.getTilePixelSize(q, h, s), Gt = f.getResolution(q) / m, ee = st[0] * Gt * Y,
                _e = st[1] * Gt * Y, ri = f.getTileCoordForCoordAndZ(Ce(b), q), ln = f.getTileCoordExtent(ri),
                tt = _t(this.tempTransform, [y * (ln[0] - b[0]) / m, y * (b[3] - ln[3]) / m]),
                Le = y * u.getGutterForProjection(s), Ye = W[q];
            for (let Pi in Ye) {
                let Ue = Ye[Pi], bn = Ue.tileCoord, An = ri[1] - bn[1], Mn = Math.round(tt[0] - (An - 1) * ee),
                    Oi = ri[2] - bn[2], Mt = Math.round(tt[1] - (Oi - 1) * _e), Bt = Math.round(tt[0] - An * ee),
                    Xt = Math.round(tt[1] - Oi * _e), L = Mn - Bt, x = Mt - Xt, E = g === q,
                    M = E && Ue.getAlpha(K(this), t.time) !== 1, B = !1;
                if (!M) if (at) {
                    I = [Bt, Xt, Bt + L, Xt, Bt + L, Xt + x, Bt, Xt + x];
                    for (let Q = 0, Wt = at.length; Q < Wt; ++Q) if (g !== q && q < At[Q]) {
                        let Rt = at[Q];
                        yt([Bt, Xt, Bt + L, Xt + x], [Rt[0], Rt[3], Rt[4], Rt[7]]) && (B || (P.save(), B = !0), P.beginPath(), P.moveTo(I[0], I[1]), P.lineTo(I[2], I[3]), P.lineTo(I[4], I[5]), P.lineTo(I[6], I[7]), P.moveTo(Rt[6], Rt[7]), P.lineTo(Rt[4], Rt[5]), P.lineTo(Rt[2], Rt[3]), P.lineTo(Rt[0], Rt[1]), P.clip())
                    }
                    at.push(I), At.push(q)
                } else P.clearRect(Bt, Xt, L, x);
                this.drawTileImage(Ue, t, Bt, Xt, L, x, Le, E), at && !M ? (B && P.restore(), this.renderedTiles.unshift(Ue)) : this.renderedTiles.push(Ue), this.updateUsedTiles(t.usedTiles, u, Ue)
            }
        }
        return this.renderedRevision = d, this.renderedResolution = m, this.extentChanged = !this.renderedExtent_ || !di(this.renderedExtent_, b), this.renderedExtent_ = b, this.renderedPixelRatio = h, this.renderedProjection = s, this.manageTilePyramid(t, u, f, h, s, p, g, c.getPreload()), this.scheduleExpireCache(t, u), this.postRender(P, t), i.extent && P.restore(), P.imageSmoothingEnabled = !0, F !== N.style.transform && (N.style.transform = F), this.container
    }

    drawTileImage(t, e, i, r, s, o, a, l) {
        let h = this.getTileImage(t);
        if (!h) return;
        let c = K(this), u = e.layerStatesArray[e.layerIndex], d = u.opacity * (l ? t.getAlpha(c, e.time) : 1),
            f = d !== this.context.globalAlpha;
        f && (this.context.save(), this.context.globalAlpha = d), this.context.drawImage(h, a, a, h.width - 2 * a, h.height - 2 * a, i, r, s, o), f && this.context.restore(), d !== u.opacity ? e.animate = !0 : l && t.endTransition(c)
    }

    getImage() {
        let t = this.context;
        return t ? t.canvas : null
    }

    getTileImage(t) {
        return t.getImage()
    }

    scheduleExpireCache(t, e) {
        if (e.canExpireCache()) {
            let i = function (r, s, o) {
                let a = K(r);
                a in o.usedTiles && r.expireCache(o.viewState.projection, o.usedTiles[a])
            }.bind(null, e);
            t.postRenderFunctions.push(i)
        }
    }

    updateUsedTiles(t, e, i) {
        let r = K(e);
        r in t || (t[r] = {}), t[r][i.getKey()] = !0
    }

    manageTilePyramid(t, e, i, r, s, o, a, l, h) {
        let c = K(e);
        c in t.wantedTiles || (t.wantedTiles[c] = {});
        let u = t.wantedTiles[c], d = t.tileQueue, f = i.getMinZoom(), g = t.viewState.rotation,
            m = g ? Ms(t.viewState.center, t.viewState.resolution, g, t.size) : void 0, p = 0, _, y, C, w, T, R;
        for (R = f; R <= a; ++R) for (y = i.getTileRangeForExtentAndZ(o, R, y), C = i.getResolution(R), w = y.minX; w <= y.maxX; ++w) for (T = y.minY; T <= y.maxY; ++T) g && !i.tileCoordIntersectsViewport([R, w, T], m) || (a - R <= l ? (++p, _ = e.getTile(R, w, T, r, s), _.getState() == k.IDLE && (u[_.getKey()] = !0, d.isKeyQueued(_.getKey()) || d.enqueue([_, c, i.getTileCoordCenter(_.tileCoord), C])), h !== void 0 && h(_)) : e.useTile(R, w, T, s));
        e.updateCacheSize(p, s)
    }
}, bf = hh;
var ch = class extends Sf {
    constructor(t) {
        super(t)
    }

    createRenderer() {
        return new bf(this)
    }
}, Af = ch;
no();
_i();
dh();
Yt();
_c();
uc();
Yg();
var $g = Ic(Hg(), 1);
oc();
var Ec = class {
    constructor(t, e) {
        this.view = t;
        this.projection = e
    }

    onChange(t) {
        this.view.on("change", () => {
            let [e, i] = this.getCoordinates();
            t(e, i)
        })
    }

    getCoordinates() {
        return this.view.getCenter()
    }

    setCoordinates(t, e) {
        this.view.setCenter(ir([t, e], this.projection))
    }
};

function e_(n, t = 0, e = 0, i = 10) {
    let r = "EPSG:4326", s = new ef({
            coordinateFormat: Eu(4),
            projection: r,
            className: `mouse-position-${n}`,
            target: document.getElementById(`OSMap-${n}`)
        }), o = new So({projection: r, geometry: new ar(ir([t, e], r))}), a = new pc({features: [o]}),
        l = new cc({source: a}), h = new Af({source: new Rf}), c = document.getElementById(`OSMap-${n}`),
        u = new me({projection: r, center: ir([t, e], r), zoom: i}),
        d = new Qd({controls: Zr().extend([s]), layers: [h, l], target: c, view: u}), f = new $g.default("nominatim", {
            provider: "osm",
            lang: "ru-RU",
            placeholder: "\u041F\u043E\u0438\u0441\u043A...",
            limit: 5,
            keepOpen: !0
        });
    d.addControl(f), f.on("addresschosen", function (m) {
        console.log(m);
        let p = m.feature, _ = m.coordinate;
        p.setStyle(new ei({
            image: new nn({
                color: "rgba(0, 0, 0, 0)",
                crossOrigin: "anonymous",
                src: "https://openlayers.org/en/latest/examples/data/dot.png",
                scale: .01
            })
        })), u.setCenter(ir([_[0], _[1]], r))
    });

    function g() {
        let [m, p] = d.getView().getCenter();
        o.getGeometry().setCoordinates([m, p])
    }

    return d.on("movestart", g), d.on("moveend", g), c.classList.add("map-done"), new Ec(u, r)
}

window.traineratwot = {};
window.traineratwot.GetPointMap = e_;
/*! Bundled license information:

ol-geocoder/dist/ol-geocoder.js:
  (*!
   * ol-geocoder - v4.3.1
   * A geocoder extension compatible with OpenLayers v6.x, v7.x & v8.x
   * https://github.com/Dominique92/ol-geocoder
   * Built: 15/09/2023 16:57:41
   *)
*/
